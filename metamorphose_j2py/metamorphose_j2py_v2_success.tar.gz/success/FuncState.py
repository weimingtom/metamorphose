#!/usr/bin/env python
""" generated source for module FuncState """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/FuncState.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Used to model a function during compilation.  Code generation uses
#  * this structure extensively.  Most of the PUC-Rio functions from
#  * lcode.c have moved into this class, alongwith a few functions from
#  * lparser.c
#  
class FuncState(object):
    """ generated source for class FuncState """
    #  See NO_JUMP in lcode.h. 
    NO_JUMP = -1

    #  Proto object for this function. 
    f = None

    # 
    #    * Table to find (and reuse) elements in <var>f.k</var>.  Maps from
    #    * Object (a constant Lua value) to an index into <var>f.k</var>.
    #    
    h = Hashtable()

    #  Enclosing function. 
    prev = None

    #  Lexical state. 
    ls = None

    #  Lua state. 
    L = None

    #  chain of current blocks 
    bl = None

    #  = null;
    #  next position to code. 
    pc = int()

    #  = 0;
    #  pc of last jump target. 
    lasttarget = -1

    #  List of pending jumps to <var>pc</var>. 
    jpc = NO_JUMP

    #  First free register. 
    freereg = int()

    #  = 0;
    #  number of elements in <var>k</var>. 
    nk = int()

    #  = 0;
    #  number of elements in <var>p</var>. 
    np = int()

    #  = 0;
    #  number of elements in <var>locvars</var>. 
    nlocvars = int()

    #  = 0;
    #  number of active local variables. 
    nactvar = int()

    #  = 0;
    #  upvalues as 8-bit k and 8-bit info 
    upvalues = [None] * Lua.MAXUPVALUES

    #  declared-variable stack. 
    actvar = [None] * Lua.MAXVARS

    # 
    #    * Constructor.  Much of this is taken from <code>open_func</code> in
    #    * <code>lparser.c</code>.
    #    
    def __init__(self, ls):
        """ generated source for method __init__ """
        self.f = Proto(ls.source, 2)
        #  default value for maxstacksize=2
        self.L = ls.L
        self.ls = ls
        #     prev = ls.linkfs(this);

    #  Equivalent to <code>close_func</code> from <code>lparser.c</code>. 
    def close(self):
        """ generated source for method close """
        self.f.closeCode(self.pc)
        self.f.closeLineinfo(self.pc)
        self.f.closeK(self.nk)
        self.f.closeP(self.np)
        self.f.closeLocvars(self.nlocvars)
        self.f.closeUpvalues()
        checks = self.L.gCheckcode(self.f)
        # # assert checks
        # # assert bl == null

    #  Equivalent to getlocvar from lparser.c.
    #    * Accesses <code>LocVar</code>s of the {@link Proto}.
    #    
    def getlocvar(self, idx):
        """ generated source for method getlocvar """
        return self.f.locvars[self.actvar[idx]]

    #  Functions from lcode.c
    #  Equivalent to luaK_checkstack. 
    def kCheckstack(self, n):
        """ generated source for method kCheckstack """
        newstack = self.freereg + n
        if newstack > self.f.maxstacksize():
            if newstack >= Lua.MAXSTACK:
                self.ls.xSyntaxerror("function or expression too complex")
            self.f.setMaxstacksize(newstack)

    #  Equivalent to luaK_code. 
    def kCode(self, i, line):
        """ generated source for method kCode """
        dischargejpc()
        #  Put new instruction in code array.
        self.f.codeAppend(self.L, self.pc, i, line)
        return self.pc += 1

    #  Equivalent to luaK_codeABC. 
    def kCodeABC(self, o, a, b, c):
        """ generated source for method kCodeABC """
        #  assert getOpMode(o) == iABC;
        #  assert getBMode(o) != OP_ARG_N || b == 0;
        #  assert getCMode(o) != OP_ARG_N || c == 0;
        return self.kCode(Lua.CREATE_ABC(o, a, b, c), self.ls.lastline())

    #  Equivalent to luaK_codeABx. 
    def kCodeABx(self, o, a, bc):
        """ generated source for method kCodeABx """
        #  assert getOpMode(o) == iABx || getOpMode(o) == iAsBx);
        #  assert getCMode(o) == OP_ARG_N);
        return self.kCode(Lua.CREATE_ABx(o, a, bc), self.ls.lastline())

    #  Equivalent to luaK_codeAsBx. 
    def kCodeAsBx(self, o, a, bc):
        """ generated source for method kCodeAsBx """
        return self.kCodeABx(o, a, bc + Lua.MAXARG_sBx)

    #  Equivalent to luaK_dischargevars. 
    def kDischargevars(self, e):
        """ generated source for method kDischargevars """
        if e.kind() == Expdesc.VLOCAL:
            e.setKind(Expdesc.VNONRELOC)
        elif e.kind() == Expdesc.VUPVAL:
            e.reloc(self.kCodeABC(Lua.OP_GETUPVAL, 0, e.info, 0))
        elif e.kind() == Expdesc.VGLOBAL:
            e.reloc(self.kCodeABx(Lua.OP_GETGLOBAL, 0, e.info))
        elif e.kind() == Expdesc.VINDEXED:
            self.freereg(e.aux())
            self.freereg(e.info())
            e.reloc(self.kCodeABC(Lua.OP_GETTABLE, 0, e.info, e.aux))
        elif e.kind() == Expdesc.VVARARG:
            pass
        elif e.kind() == Expdesc.VCALL:
            kSetoneret(e)
        else:
        #  there is one value available (somewhere)

    #  Equivalent to luaK_exp2anyreg. 
    def kExp2anyreg(self, e):
        """ generated source for method kExp2anyreg """
        self.kDischargevars(e)
        if e.k == Expdesc.VNONRELOC:
            if not e.hasjumps():
                return e.info
            if e.info >= self.nactvar:
                #  reg is not a local?
                exp2reg(e, e.info)
                #  put value on it
                return e.info
        kExp2nextreg(e)
        #  default
        return e.info

    #  Equivalent to luaK_exp2nextreg. 
    def kExp2nextreg(self, e):
        """ generated source for method kExp2nextreg """
        self.kDischargevars(e)
        freeexp(e)
        kReserveregs(1)
        exp2reg(e, self.freereg - 1)

    #  Equivalent to luaK_fixline. 
    def kFixline(self, line):
        """ generated source for method kFixline """
        self.f.setLineinfo(self.pc - 1, line)

    #  Equivalent to luaK_infix. 
    def kInfix(self, op, v):
        """ generated source for method kInfix """
        if op == Syntax.OPR_AND:
            kGoiftrue(v)
        elif op == Syntax.OPR_OR:
            kGoiffalse(v)
        elif op == Syntax.OPR_CONCAT:
            self.kExp2nextreg(v)
            #  operand must be on the `stack' 
        else:
            if not isnumeral(v):
                kExp2RK(v)

    def isnumeral(self, e):
        """ generated source for method isnumeral """
        return e.k == Expdesc.VKNUM and e.t == self.NO_JUMP and e.f == self.NO_JUMP

    #  Equivalent to luaK_nil. 
    def kNil(self, from_, n):
        """ generated source for method kNil """
        previous = int()
        if self.pc > self.lasttarget:
            #  no jumps to current position? 
            if self.pc == 0:
                #  function start? 
                return
            #  positions are already clean 
            previous = self.pc - 1
            instr = self.f.code_[previous]
            if Lua.OPCODE(instr) == Lua.OP_LOADNIL:
                pfrom = Lua.ARGA(instr)
                pto = Lua.ARGB(instr)
                if pfrom <= from_ and from_ <= pto + 1:
                    #  can connect both? 
                    if from_ + n - 1 > pto:
                        self.f.code_[previous] = Lua.SETARG_B(instr, from_ + n - 1)
                    return
        self.kCodeABC(Lua.OP_LOADNIL, from_, from_ + n - 1, 0)

    #  Equivalent to luaK_numberK. 
    def kNumberK(self, r):
        """ generated source for method kNumberK """
        return addk(Lua.valueOfNumber(r))

    #  Equivalent to luaK_posfix. 
    def kPosfix(self, op, e1, e2):
        """ generated source for method kPosfix """
        if op == Syntax.OPR_AND:
            #  list must be closed 
            # # assert e1.t == NO_JUMP
            self.kDischargevars(e2)
            e2.f = kConcat(e2.f, e1.f)
            e1.init(e2)
        elif op == Syntax.OPR_OR:
            #  list must be closed 
            # # assert e1.f == NO_JUMP
            self.kDischargevars(e2)
            e2.t = kConcat(e2.t, e1.t)
            e1.init(e2)
        elif op == Syntax.OPR_CONCAT:
            kExp2val(e2)
            if e2.k == Expdesc.VRELOCABLE and Lua.OPCODE(getcode(e2)) == Lua.OP_CONCAT:
                # # assert e1.info == Lua.ARGB(getcode(e2))-1
                freeexp(e1)
                setcode(e2, Lua.SETARG_B(getcode(e2), e1.info))
                e1.k = e2.k
                e1.info = e2.info
            else:
                self.kExp2nextreg(e2)
                #  operand must be on the 'stack' 
                codearith(Lua.OP_CONCAT, e1, e2)
        elif op == Syntax.OPR_ADD:
            codearith(Lua.OP_ADD, e1, e2)
        elif op == Syntax.OPR_SUB:
            codearith(Lua.OP_SUB, e1, e2)
        elif op == Syntax.OPR_MUL:
            codearith(Lua.OP_MUL, e1, e2)
        elif op == Syntax.OPR_DIV:
            codearith(Lua.OP_DIV, e1, e2)
        elif op == Syntax.OPR_MOD:
            codearith(Lua.OP_MOD, e1, e2)
        elif op == Syntax.OPR_POW:
            codearith(Lua.OP_POW, e1, e2)
        elif op == Syntax.OPR_EQ:
            codecomp(Lua.OP_EQ, True, e1, e2)
        elif op == Syntax.OPR_NE:
            codecomp(Lua.OP_EQ, False, e1, e2)
        elif op == Syntax.OPR_LT:
            codecomp(Lua.OP_LT, True, e1, e2)
        elif op == Syntax.OPR_LE:
            codecomp(Lua.OP_LE, True, e1, e2)
        elif op == Syntax.OPR_GT:
            codecomp(Lua.OP_LT, False, e1, e2)
        elif op == Syntax.OPR_GE:
            codecomp(Lua.OP_LE, False, e1, e2)
        else:
            pass
        # # assert false

    #  Equivalent to luaK_prefix. 
    def kPrefix(self, op, e):
        """ generated source for method kPrefix """
        e2 = Expdesc(Expdesc.VKNUM, 0)
        if op == Syntax.OPR_MINUS:
            if e.kind() == Expdesc.VK:
                self.kExp2anyreg(e)
            codearith(Lua.OP_UNM, e, e2)
        elif op == Syntax.OPR_NOT:
            codenot(e)
        elif op == Syntax.OPR_LEN:
            self.kExp2anyreg(e)
            codearith(Lua.OP_LEN, e, e2)
        else:
            raise IllegalArgumentException()

    #  Equivalent to luaK_reserveregs. 
    def kReserveregs(self, n):
        """ generated source for method kReserveregs """
        self.kCheckstack(n)
        self.freereg += n

    #  Equivalent to luaK_ret. 
    def kRet(self, first, nret):
        """ generated source for method kRet """
        self.kCodeABC(Lua.OP_RETURN, first, nret + 1, 0)

    #  Equivalent to luaK_setmultret (in lcode.h). 
    def kSetmultret(self, e):
        """ generated source for method kSetmultret """
        kSetreturns(e, Lua.MULTRET)

    #  Equivalent to luaK_setoneret. 
    def kSetoneret(self, e):
        """ generated source for method kSetoneret """
        if e.kind() == Expdesc.VCALL:
            #  expression is an open function call?
            e.nonreloc(Lua.ARGA(getcode(e)))
        elif e.kind() == Expdesc.VVARARG:
            setargb(e, 2)
            e.setKind(Expdesc.VRELOCABLE)

    #  Equivalent to luaK_setreturns. 
    def kSetreturns(self, e, nresults):
        """ generated source for method kSetreturns """
        if e.kind() == Expdesc.VCALL:
            #  expression is an open function call?
            setargc(e, nresults + 1)
        elif e.kind() == Expdesc.VVARARG:
            setargb(e, nresults + 1)
            setarga(e, self.freereg)
            self.kReserveregs(1)

    #  Equivalent to luaK_stringK. 
    def kStringK(self, s):
        """ generated source for method kStringK """
        return addk(s.intern())

    def addk(self, o):
        """ generated source for method addk """
        hash = o
        v = self.h.get(hash)
        if v != None:
            #  :todo: assert
            return (int(v)).intValue()
        #  constant not found; create a new entry
        self.f.constantAppend(self.nk, o)
        self.h.put(hash, int(self.nk))
        return self.nk += 1

    def codearith(self, op, e1, e2):
        """ generated source for method codearith """
        if constfolding(op, e1, e2):
            return
        else:
            o1 = kExp2RK(e1)
            o2 = kExp2RK(e2) if (op != Lua.OP_UNM and op != Lua.OP_LEN) else 0
            freeexp(e2)
            freeexp(e1)
            e1.info = self.kCodeABC(op, 0, o1, o2)
            e1.k = Expdesc.VRELOCABLE

    def constfolding(self, op, e1, e2):
        """ generated source for method constfolding """
        r = float()
        if not self.isnumeral(e1) or not self.isnumeral(e2):
            return False
        v1 = e1.nval
        v2 = e2.nval
        if op == Lua.OP_ADD:
            r = v1 + v2
        elif op == Lua.OP_SUB:
            r = v1 - v2
        elif op == Lua.OP_MUL:
            r = v1 * v2
        elif op == Lua.OP_DIV:
            if v2 == 0.0:
                return False
            #  do not attempt to divide by 0 
            r = v1 / v2
        elif op == Lua.OP_MOD:
            if v2 == 0.0:
                return False
            #  do not attempt to divide by 0 
            r = v1 % v2
        elif op == Lua.OP_POW:
            r = self.L.iNumpow(v1, v2)
        elif op == Lua.OP_UNM:
            r = -v1
        elif op == Lua.OP_LEN:
            return False
        else:
            #  no constant folding for 'len' 
            # # assert false
            r = 0.0
        if Double.isNaN(r):
            return False
        #  do not attempt to produce NaN 
        e1.nval = r
        return True

    def codenot(self, e):
        """ generated source for method codenot """
        self.kDischargevars(e)
        if e.k == Expdesc.VNIL:
            pass
        elif e.k == Expdesc.VFALSE:
            e.k = Expdesc.VTRUE
        elif e.k == Expdesc.VK:
            pass
        elif e.k == Expdesc.VKNUM:
            pass
        elif e.k == Expdesc.VTRUE:
            e.k = Expdesc.VFALSE
        elif e.k == Expdesc.VJMP:
            invertjump(e)
        elif e.k == Expdesc.VRELOCABLE:
            pass
        elif e.k == Expdesc.VNONRELOC:
            discharge2anyreg(e)
            freeexp(e)
            e.info = self.kCodeABC(Lua.OP_NOT, 0, e.info, 0)
            e.k = Expdesc.VRELOCABLE
        else:
            # # assert false
        #  interchange true and false lists 
        temp = e.f
        e.f = e.t
        e.t = temp
        removevalues(e.f)
        removevalues(e.t)

    def removevalues(self, list_):
        """ generated source for method removevalues """
        while list_ != self.NO_JUMP:
            patchtestreg(list_, Lua.NO_REG)
            list_ = getjump(list_)

    def dischargejpc(self):
        """ generated source for method dischargejpc """
        patchlistaux(self.jpc, self.pc, Lua.NO_REG, self.pc)
        self.jpc = self.NO_JUMP

    def discharge2reg(self, e, reg):
        """ generated source for method discharge2reg """
        self.kDischargevars(e)
        if e.k == Expdesc.VNIL:
            self.kNil(reg, 1)
        elif e.k == Expdesc.VFALSE:
            pass
        elif e.k == Expdesc.VTRUE:
            self.kCodeABC(Lua.OP_LOADBOOL, reg, (1 if e.k == Expdesc.VTRUE else 0), 0)
        elif e.k == Expdesc.VK:
            self.kCodeABx(Lua.OP_LOADK, reg, e.info)
        elif e.k == Expdesc.VKNUM:
            self.kCodeABx(Lua.OP_LOADK, reg, self.kNumberK(e.nval))
        elif e.k == Expdesc.VRELOCABLE:
            setarga(e, reg)
        elif e.k == Expdesc.VNONRELOC:
            if reg != e.info:
                self.kCodeABC(Lua.OP_MOVE, reg, e.info, 0)
        elif e.k == Expdesc.VVOID:
            pass
        elif e.k == Expdesc.VJMP:
            return
        else:
            pass
        # # assert false
        e.nonreloc(reg)

    def exp2reg(self, e, reg):
        """ generated source for method exp2reg """
        self.discharge2reg(e, reg)
        if e.k == Expdesc.VJMP:
            e.t = kConcat(e.t, e.info)
            #  put this jump in `t' list 
        if e.hasjumps():
            p_f = self.NO_JUMP
            #  position of an eventual LOAD false 
            p_t = self.NO_JUMP
            #  position of an eventual LOAD true 
            if need_value(e.t) or need_value(e.f):
                fj = self.NO_JUMP if (e.k == Expdesc.VJMP) else kJump()
                p_f = code_label(reg, 0, 1)
                p_t = code_label(reg, 1, 0)
                kPatchtohere(fj)
            finalpos = kGetlabel()
            #  position after whole expression 
            patchlistaux(e.f, finalpos, reg, p_f)
            patchlistaux(e.t, finalpos, reg, p_t)
        e.init(Expdesc.VNONRELOC, reg)

    def code_label(self, a, b, jump):
        """ generated source for method code_label """
        kGetlabel()
        #  those instructions may be jump targets 
        return self.kCodeABC(Lua.OP_LOADBOOL, a, b, jump)

    # 
    #    * check whether list has any jump that do not produce a value
    #    * (or produce an inverted value)
    #    
    def need_value(self, list_):
        """ generated source for method need_value """
        while list_ != self.NO_JUMP:
            i = getjumpcontrol(list_)
            instr = self.f.code_[i]
            if Lua.OPCODE(instr) != Lua.OP_TESTSET:
                return True
            list_ = getjump(list_)
        return False
        #  not found 

    def freeexp(self, e):
        """ generated source for method freeexp """
        if e.kind() == Expdesc.VNONRELOC:
            self.freereg(e.info)

    def freereg(self, reg):
        """ generated source for method freereg """
        if not Lua.ISK(reg) and reg >= self.nactvar:
            self.freereg -= 1
            #  assert reg == freereg;

    def getcode(self, e):
        """ generated source for method getcode """
        return self.f.code_[e.info]

    def setcode(self, e, code_):
        """ generated source for method setcode """
        self.f.code_[e.info] = code_

    #  Equivalent to searchvar from lparser.c 
    def searchvar(self, n):
        """ generated source for method searchvar """
        #  caution: descending loop (in emulation of PUC-Rio).
        i = self.nactvar - 1
        while i >= 0:
            if n == self.getlocvar(i.varname):
                return i
            i -= 1
        return -1
        #  not found

    def setarga(self, e, a):
        """ generated source for method setarga """
        at = e.info
        code_ = self.f.code_
        code_[at] = Lua.SETARG_A(code_[at], a)

    def setargb(self, e, b):
        """ generated source for method setargb """
        at = e.info
        code_ = self.f.code_
        code_[at] = Lua.SETARG_B(code_[at], b)

    def setargc(self, e, c):
        """ generated source for method setargc """
        at = e.info
        code_ = self.f.code_
        code_[at] = Lua.SETARG_C(code_[at], c)

    #  Equivalent to <code>luaK_getlabel</code>. 
    def kGetlabel(self):
        """ generated source for method kGetlabel """
        self.lasttarget = self.pc
        return self.pc

    # 
    #    * Equivalent to <code>luaK_concat</code>.
    #    * l1 was an int*, now passing back as result.
    #    
    def kConcat(self, l1, l2):
        """ generated source for method kConcat """
        if l2 == self.NO_JUMP:
            return l1
        elif l1 == self.NO_JUMP:
            return l2
        else:
            list_ = l1
            next = int()
            while (next = getjump(list_)) != self.NO_JUMP:
                #  find last element 
            fixjump(list_, l2)
            return l1

    #  Equivalent to <code>luaK_patchlist</code>. 
    def kPatchlist(self, list_, target):
        """ generated source for method kPatchlist """
        if target == self.pc:
            kPatchtohere(list_)
        else:
            # # assert target < pc
            patchlistaux(list_, target, Lua.NO_REG, target)

    def patchlistaux(self, list_, vtarget, reg, dtarget):
        """ generated source for method patchlistaux """
        while list_ != self.NO_JUMP:
            next = getjump(list_)
            if patchtestreg(list_, reg):
                fixjump(list_, vtarget)
            else:
                fixjump(list_, dtarget)
            #  jump to default target 
            list_ = next

    def patchtestreg(self, node, reg):
        """ generated source for method patchtestreg """
        i = getjumpcontrol(node)
        code_ = self.f.code_
        instr = code_[i]
        if Lua.OPCODE(instr) != Lua.OP_TESTSET:
            return False
        #  cannot patch other instructions 
        if reg != Lua.NO_REG and reg != Lua.ARGB(instr):
            code_[i] = Lua.SETARG_A(instr, reg)
        else:
            code_[i] = Lua.CREATE_ABC(Lua.OP_TEST, Lua.ARGB(instr), 0, Lua.ARGC(instr))
        return True

    def getjumpcontrol(self, at):
        """ generated source for method getjumpcontrol """
        code_ = self.f.code_
        if at >= 1 and testTMode(Lua.OPCODE(code_[at - 1])):
            return at - 1
        else:
            return at

    # 
    #   ** masks for instruction properties. The format is:
    #   ** bits 0-1: op mode
    #   ** bits 2-3: C arg mode
    #   ** bits 4-5: B arg mode
    #   ** bit 6: instruction set register A
    #   ** bit 7: operator is a test
    #   
    #  arg modes 
    OP_ARG_N = 0
    OP_ARG_U = 1
    OP_ARG_R = 2
    OP_ARG_K = 3

    #  op modes 
    iABC = 0
    iABx = 1
    iAsBx = 2

    @classmethod
    def opmode(cls, t, a, b, c, m):
        """ generated source for method opmode """
        return int(((t << 7) | (a << 6) | (b << 4) | (c << 2) | m))

    OPMODE = [None] * 

    def getOpMode(self, m):
        """ generated source for method getOpMode """
        return self.OPMODE[m] & 3

    def testAMode(self, m):
        """ generated source for method testAMode """
        return (self.OPMODE[m] & (1 << 6)) != 0

    def testTMode(self, m):
        """ generated source for method testTMode """
        return (self.OPMODE[m] & (1 << 7)) != 0

    #  Equivalent to <code>luaK_patchtohere</code>. 
    def kPatchtohere(self, list_):
        """ generated source for method kPatchtohere """
        self.kGetlabel()
        self.jpc = self.kConcat(self.jpc, list_)

    def fixjump(self, at, dest):
        """ generated source for method fixjump """
        jmp = self.f.code_[at]
        offset = dest - (at + 1)
        # # assert dest != NO_JUMP
        if abs(offset) > Lua.MAXARG_sBx:
            self.ls.xSyntaxerror("control structure too long")
        self.f.code_[at] = Lua.SETARG_sBx(jmp, offset)

    def getjump(self, at):
        """ generated source for method getjump """
        offset = Lua.ARGsBx(self.f.code_[at])
        if offset == self.NO_JUMP:
            #  point to itself represents end of list 
            return self.NO_JUMP
        else:
            #  end of list 
            return (at + 1) + offset
        #  turn offset into absolute position 

    #  Equivalent to <code>luaK_jump</code>. 
    def kJump(self):
        """ generated source for method kJump """
        old_jpc = self.jpc
        #  save list of jumps to here 
        self.jpc = self.NO_JUMP
        j = self.kCodeAsBx(Lua.OP_JMP, 0, self.NO_JUMP)
        j = self.kConcat(j, old_jpc)
        #  keep them on hold 
        return j

    #  Equivalent to <code>luaK_storevar</code>. 
    def kStorevar(self, var, ex):
        """ generated source for method kStorevar """
        if var.k == Expdesc.VLOCAL:
            self.freeexp(ex)
            self.exp2reg(ex, var.info)
            return
        elif var.k == Expdesc.VUPVAL:
            e = self.kExp2anyreg(ex)
            self.kCodeABC(Lua.OP_SETUPVAL, e, var.info, 0)
        elif var.k == Expdesc.VGLOBAL:
            e = self.kExp2anyreg(ex)
            self.kCodeABx(Lua.OP_SETGLOBAL, e, var.info)
        elif var.k == Expdesc.VINDEXED:
            e = kExp2RK(ex)
            self.kCodeABC(Lua.OP_SETTABLE, var.info, var.aux, e)
        else:
            #  invalid var kind to store 
            # # assert false
        self.freeexp(ex)

    #  Equivalent to <code>luaK_indexed</code>. 
    def kIndexed(self, t, k):
        """ generated source for method kIndexed """
        t.aux = kExp2RK(k)
        t.k = Expdesc.VINDEXED

    #  Equivalent to <code>luaK_exp2RK</code>. 
    def kExp2RK(self, e):
        """ generated source for method kExp2RK """
        kExp2val(e)
        if e.k == Expdesc.VKNUM:
            pass
        elif e.k == Expdesc.VTRUE:
            pass
        elif e.k == Expdesc.VFALSE:
            pass
        elif e.k == Expdesc.VNIL:
            if self.nk <= Lua.MAXINDEXRK:
                #  constant fit in RK operand? 
                e.info = nilK() if (e.k == Expdesc.VNIL) else self.kNumberK(e.nval) if (e.k == Expdesc.VKNUM) else boolK(e.k == Expdesc.VTRUE)
                e.k = Expdesc.VK
                return e.info | Lua.BITRK
            else:
                pass
        elif e.k == Expdesc.VK:
            if e.info <= Lua.MAXINDEXRK:
                #  constant fit in argC? 
                return e.info | Lua.BITRK
            else:
                pass
        else:
        #  not a constant in the right range: put it in a register 
        return self.kExp2anyreg(e)

    #  Equivalent to <code>luaK_exp2val</code>. 
    def kExp2val(self, e):
        """ generated source for method kExp2val """
        if e.hasjumps():
            self.kExp2anyreg(e)
        else:
            self.kDischargevars(e)

    def boolK(self, b):
        """ generated source for method boolK """
        return self.addk(Lua.valueOfBoolean(b))

    def nilK(self):
        """ generated source for method nilK """
        return self.addk(Lua.NIL)

    #  Equivalent to <code>luaK_goiffalse</code>. 
    def kGoiffalse(self, e):
        """ generated source for method kGoiffalse """
        lj = int()
        #  pc of last jump 
        self.kDischargevars(e)
        if e.k == Expdesc.VNIL:
            pass
        elif e.k == Expdesc.VFALSE:
            lj = self.NO_JUMP
            #  always false; do nothing 
        elif e.k == Expdesc.VTRUE:
            lj = self.kJump()
            #  always jump 
        elif e.k == Expdesc.VJMP:
            lj = e.info
        else:
            lj = jumponcond(e, True)
        e.t = self.kConcat(e.t, lj)
        #  insert last jump in `t' list 
        self.kPatchtohere(e.f)
        e.f = self.NO_JUMP

    #  Equivalent to <code>luaK_goiftrue</code>. 
    def kGoiftrue(self, e):
        """ generated source for method kGoiftrue """
        lj = int()
        #  pc of last jump 
        self.kDischargevars(e)
        if e.k == Expdesc.VK:
            pass
        elif e.k == Expdesc.VKNUM:
            pass
        elif e.k == Expdesc.VTRUE:
            lj = self.NO_JUMP
            #  always true; do nothing 
        elif e.k == Expdesc.VFALSE:
            lj = self.kJump()
            #  always jump 
        elif e.k == Expdesc.VJMP:
            invertjump(e)
            lj = e.info
        else:
            lj = jumponcond(e, False)
        e.f = self.kConcat(e.f, lj)
        #  insert last jump in `f' list 
        self.kPatchtohere(e.t)
        e.t = self.NO_JUMP

    def invertjump(self, e):
        """ generated source for method invertjump """
        at = self.getjumpcontrol(e.info)
        code_ = self.f.code_
        instr = code_[at]
        # # assert testTMode(Lua.OPCODE(instr)) && Lua.OPCODE(instr) != Lua.OP_TESTSET && Lua.OPCODE(instr) != Lua.OP_TEST
        code_[at] = Lua.SETARG_A(instr, (1 if Lua.ARGA(instr) == 0 else 0))

    def jumponcond(self, e, cond):
        """ generated source for method jumponcond """
        if e.k == Expdesc.VRELOCABLE:
            ie = self.getcode(e)
            if Lua.OPCODE(ie) == Lua.OP_NOT:
                self.pc -= 1
                #  remove previous OP_NOT 
                return condjump(Lua.OP_TEST, Lua.ARGB(ie), 0, 0 if cond else 1)
            #  else go through 
        discharge2anyreg(e)
        self.freeexp(e)
        return condjump(Lua.OP_TESTSET, Lua.NO_REG, e.info, 1 if cond else 0)

    def condjump(self, op, a, b, c):
        """ generated source for method condjump """
        self.kCodeABC(op, a, b, c)
        return self.kJump()

    def discharge2anyreg(self, e):
        """ generated source for method discharge2anyreg """
        if e.k != Expdesc.VNONRELOC:
            self.kReserveregs(1)
            self.discharge2reg(e, self.freereg - 1)

    def kSelf(self, e, key):
        """ generated source for method kSelf """
        self.kExp2anyreg(e)
        self.freeexp(e)
        func = self.freereg
        self.kReserveregs(2)
        self.kCodeABC(Lua.OP_SELF, func, e.info, self.kExp2RK(key))
        self.freeexp(key)
        e.info = func
        e.k = Expdesc.VNONRELOC

    def kSetlist(self, base, nelems, tostore):
        """ generated source for method kSetlist """
        c = (nelems - 1) / Lua.LFIELDS_PER_FLUSH + 1
        b = 0 if (tostore == Lua.MULTRET) else tostore
        # # assert tostore != 0
        if c <= Lua.MAXARG_C:
            self.kCodeABC(Lua.OP_SETLIST, base, b, c)
        else:
            self.kCodeABC(Lua.OP_SETLIST, base, b, 0)
            self.kCode(c, self.ls.lastline)
        self.freereg = base + 1
        #  free registers with list values 

    def codecomp(self, op, cond, e1, e2):
        """ generated source for method codecomp """
        o1 = self.kExp2RK(e1)
        o2 = self.kExp2RK(e2)
        self.freeexp(e2)
        self.freeexp(e1)
        if (not cond) and op != Lua.OP_EQ:
            #  exchange args to replace by `<' or `<=' 
            temp = o1
            o1 = o2
            o2 = temp
            #  o1 <==> o2 
            cond = True
        e1.info = self.condjump(op, (1 if cond else 0), o1, o2)
        e1.k = Expdesc.VJMP

    def markupval(self, level):
        """ generated source for method markupval """
        b = self.bl
        while b != None and b.nactvar > level:
        if b != None:
            b.upval = True

