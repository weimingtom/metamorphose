#!/usr/bin/env python
""" generated source for module Proto """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Proto.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Models a function prototype.  This class is internal to Jill and
#  * should not be used by clients.  This is the analogue of the PUC-Rio
#  * type <code>Proto</code>, hence the name.
#  * A function prototype represents the constant part of a function, that
#  * is, a function without closures (upvalues) and without an
#  * environment.  It's a handle for a block of VM instructions and
#  * ancillary constants.
#  *
#  * For convenience some private arrays are exposed.  Modifying these
#  * arrays is punishable by death. (Java has no convenient constant
#  * array datatype)
#  
class Proto(object):
    """ generated source for class Proto """
    #  Interned 0-element array. 
    ZERO_INT_ARRAY = [None] * 0
    ZERO_LOCVAR_ARRAY = [None] * 0
    ZERO_CONSTANT_ARRAY = [None] * 0
    ZERO_PROTO_ARRAY = [None] * 0
    ZERO_STRING_ARRAY = [None] * 0

    #  Generally the fields are named following the PUC-Rio implementation
    #  and so are unusually terse.
    #  Array of constants. 
    k = []
    sizek = int()

    #  Array of VM instructions. 
    code_ = []
    sizecode = int()

    #  Array of Proto objects. 
    p = []
    sizep = int()

    # 
    #    * Number of upvalues used by this prototype (and so by all the
    #    * functions created from this Proto).
    #    
    nups = int()

    # 
    #    * Number of formal parameters used by this prototype, and so the
    #    * In a function defined to be variadic then this is the number of
    #    * fixed parameters, the number appearing before '...' in the parameter
    #    * list.
    #    
    numparams = int()

    # 
    #    * <code>true</code> if and only if the function is variadic, that is,
    #    * defined with '...' in its parameter list.
    #    
    isVararg = bool()
    maxstacksize = int()

    #  Debug info
    #  Map from PC to line number. 
    lineinfo = []
    sizelineinfo = int()
    locvars = []
    sizelocvars = int()
    upvalues = []
    sizeupvalues = int()
    source = None
    linedefined = int()
    lastlinedefined = int()

    # 
    #    * Proto synthesized by {@link Loader}.
    #    * All the arrays that are passed to the constructor are
    #    * referenced by the instance.  Avoid unintentional sharing.  All
    #    * arrays must be non-null and all int parameters must not be
    #    * negative.  Generally, this constructor is used by {@link Loader}
    #    * since that has all the relevant arrays already constructed (as
    #    * opposed to the compiler).
    #    * @param constant   array of constants.
    #    * @param code       array of VM instructions.
    #    * @param nups       number of upvalues (used by this function).
    #    * @param numparams  number of fixed formal parameters.
    #    * @param isVararg   whether '...' is used.
    #    * @param maxstacksize  number of stack slots required when invoking.
    #    * @throws NullPointerException if any array arguments are null.
    #    * @throws IllegalArgumentException if nups or numparams is negative.
    #    
    @overloaded
    def __init__(self, constant, code_, proto, nups, numparams, isVararg, maxstacksize):
        """ generated source for method __init__ """
        if None == constant or None == code_ or None == proto:
            raise NullPointerException()
        if nups < 0 or numparams < 0 or maxstacksize < 0:
            raise IllegalArgumentException()
        self.k = constant
        len(k)
        self.code_ = code_
        len(code_)
        self.p = proto
        len(proto)
        self.nups = nups
        self.numparams = numparams
        self.isVararg = isVararg
        self.maxstacksize = maxstacksize

    # 
    #    * Blank Proto in preparation for compilation.
    #    
    @__init__.register(object, str, int)
    def __init___0(self, source, maxstacksize):
        """ generated source for method __init___0 """
        self.maxstacksize = maxstacksize
        #     maxstacksize = 2;   // register 0/1 are always valid.
        #  :todo: Consider removing size* members
        self.source = source
        self.k = self.ZERO_CONSTANT_ARRAY
        self.sizek = 0
        self.code_ = self.ZERO_INT_ARRAY
        self.sizecode = 0
        self.p = self.ZERO_PROTO_ARRAY
        self.sizep = 0
        self.lineinfo = self.ZERO_INT_ARRAY
        self.sizelineinfo = 0
        self.locvars = self.ZERO_LOCVAR_ARRAY
        self.sizelocvars = 0
        self.upvalues = self.ZERO_STRING_ARRAY
        self.sizeupvalues = 0

    # 
    #    * Augment with debug info.  All the arguments are referenced by the
    #    * instance after the method has returned, so try not to share them.
    #    
    def debug(self, lineinfoArg, locvarsArg, upvaluesArg):
        """ generated source for method debug """
        self.lineinfo = lineinfoArg
        len(lineinfo)
        self.locvars = locvarsArg
        len(locvars)
        self.upvalues = upvaluesArg
        len(upvalues)

    #  Gets source. 
    def source(self):
        """ generated source for method source """
        return self.source

    #  Setter for source. 
    def setSource(self, source):
        """ generated source for method setSource """
        self.source = source

    def linedefined(self):
        """ generated source for method linedefined """
        return self.linedefined

    def setLinedefined(self, linedefined):
        """ generated source for method setLinedefined """
        self.linedefined = linedefined

    def lastlinedefined(self):
        """ generated source for method lastlinedefined """
        return self.lastlinedefined

    def setLastlinedefined(self, lastlinedefined):
        """ generated source for method setLastlinedefined """
        self.lastlinedefined = lastlinedefined

    #  Gets Number of Upvalues 
    def nups(self):
        """ generated source for method nups """
        return self.nups

    #  Number of Parameters. 
    def numparams(self):
        """ generated source for method numparams """
        return self.numparams

    #  Maximum Stack Size. 
    def maxstacksize(self):
        """ generated source for method maxstacksize """
        return self.maxstacksize

    #  Setter for maximum stack size. 
    def setMaxstacksize(self, m):
        """ generated source for method setMaxstacksize """
        self.maxstacksize = m

    #  Instruction block (do not modify). 
    def code_(self):
        """ generated source for method code_ """
        return self.code_

    #  Append instruction. 
    def codeAppend(self, L, pc, instruction, line):
        """ generated source for method codeAppend """
        if Lua.D:
            System.err.println(len(lineinfo))
        ensureCode(L, pc)
        self.code_[pc] = instruction
        if len(lineinfo):
            newLineinfo = [None] * 1 + len(lineinfo)
            System.arraycopy(self.lineinfo, 0, newLineinfo, 0, )
            self.lineinfo = newLineinfo
        self.lineinfo[pc] = line

    def ensureLocvars(self, L, atleast, limit):
        """ generated source for method ensureLocvars """
        if atleast + 1 > self.sizelocvars:
            newsize = atleast * 2 + 1
            if newsize > limit:
                newsize = limit
            if atleast + 1 > newsize:
                L.gRunerror("too many local variables")
            newlocvars = [None] * newsize
            System.arraycopy(self.locvars, 0, newlocvars, 0, self.sizelocvars)
            i = self.sizelocvars
            while i < newsize:
                newlocvars[i] = LocVar()
                i += 1
            self.locvars = newlocvars
            self.sizelocvars = newsize

    def ensureProtos(self, L, atleast):
        """ generated source for method ensureProtos """
        if atleast + 1 > self.sizep:
            newsize = atleast * 2 + 1
            if newsize > Lua.MAXARG_Bx:
                newsize = Lua.MAXARG_Bx
            if atleast + 1 > newsize:
                L.gRunerror("constant table overflow")
            newprotos = [None] * newsize
            System.arraycopy(self.p, 0, newprotos, 0, self.sizep)
            self.p = newprotos
            self.sizep = newsize

    def ensureUpvals(self, L, atleast):
        """ generated source for method ensureUpvals """
        if atleast + 1 > self.sizeupvalues:
            newsize = atleast * 2 + 1
            if atleast + 1 > newsize:
                L.gRunerror("upvalues overflow")
            newupvalues = [None] * newsize
            System.arraycopy(self.upvalues, 0, newupvalues, 0, self.sizeupvalues)
            self.upvalues = newupvalues
            self.sizeupvalues = newsize

    def ensureCode(self, L, atleast):
        """ generated source for method ensureCode """
        if atleast + 1 > self.sizecode:
            newsize = atleast * 2 + 1
            if atleast + 1 > newsize:
                L.gRunerror("code overflow")
            newcode = [None] * newsize
            System.arraycopy(self.code_, 0, newcode, 0, self.sizecode)
            self.code_ = newcode
            self.sizecode = newsize

    #  Set lineinfo record. 
    def setLineinfo(self, pc, line):
        """ generated source for method setLineinfo """
        self.lineinfo[pc] = line

    #  Get linenumber corresponding to pc, or 0 if no info. 
    def getline(self, pc):
        """ generated source for method getline """
        if len(lineinfo):
            return 0
        return self.lineinfo[pc]

    #  Array of inner protos (do not modify). 
    def proto(self):
        """ generated source for method proto """
        return self.p

    #  Constant array (do not modify). 
    def constant(self):
        """ generated source for method constant """
        return self.k

    #  Append constant. 
    def constantAppend(self, idx, o):
        """ generated source for method constantAppend """
        if len(k):
            newK = [None] * 1 + len(k)
            System.arraycopy(self.k, 0, newK, 0, )
            self.k = newK
        self.k[idx] = Slot(o)

    #  Predicate for whether function uses ... in its parameter list. 
    def isVararg(self):
        """ generated source for method isVararg """
        return self.isVararg

    #  "Setter" for isVararg.  Sets it to true. 
    def setIsVararg(self):
        """ generated source for method setIsVararg """
        self.isVararg = True

    #  LocVar array (do not modify). 
    def locvars(self):
        """ generated source for method locvars """
        return self.locvars

    #  All the trim functions, below, check for the redundant case of
    #  trimming to the length that they already are.  Because they are
    #  initially allocated as interned zero-length arrays this also means
    #  that no unnecesary zero-length array objects are allocated.
    # 
    #    * Trim an int array to specified size.
    #    * @return the trimmed array.
    #    
    def trimInt(self, old, n):
        """ generated source for method trimInt """
        if len(old):
            return old
        newArray = [None] * n
        System.arraycopy(old, 0, newArray, 0, n)
        return newArray

    #  Trim code array to specified size. 
    def closeCode(self, n):
        """ generated source for method closeCode """
        self.code_ = self.trimInt(self.code_, n)
        len(code_)

    #  Trim lineinfo array to specified size. 
    def closeLineinfo(self, n):
        """ generated source for method closeLineinfo """
        self.lineinfo = self.trimInt(self.lineinfo, n)
        self.sizelineinfo = n

    #  Trim k (constant) array to specified size. 
    def closeK(self, n):
        """ generated source for method closeK """
        if len(k):
            newArray = [None] * n
            System.arraycopy(self.k, 0, newArray, 0, n)
            self.k = newArray
        self.sizek = n
        return

    #  Trim p (proto) array to specified size. 
    def closeP(self, n):
        """ generated source for method closeP """
        if len(p):
            return
        newArray = [None] * n
        System.arraycopy(self.p, 0, newArray, 0, n)
        self.p = newArray
        self.sizep = n

    #  Trim locvar array to specified size. 
    def closeLocvars(self, n):
        """ generated source for method closeLocvars """
        if len(locvars):
            return
        newArray = [None] * n
        System.arraycopy(self.locvars, 0, newArray, 0, n)
        self.locvars = newArray
        self.sizelocvars = n

    #  Trim upvalues array to size <var>nups</var>. 
    def closeUpvalues(self):
        """ generated source for method closeUpvalues """
        if len(upvalues):
            return
        newArray = [None] * nups
        System.arraycopy(self.upvalues, 0, newArray, 0, self.nups)
        self.upvalues = newArray
        self.sizeupvalues = self.nups

Proto.#    * number of argument received by a function created from this Proto.

