#!/usr/bin/env python
""" generated source for module BaseLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/BaseLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Contains Lua's base library.  The base library is generally
#  * considered essential for running any Lua program.  The base library
#  * can be opened using the {@link #open} method.
#  
class BaseLib(LuaJavaCallback):
    """ generated source for class BaseLib """
    #  :todo: consider making the enums contiguous so that the compiler
    #  uses the compact and faster form of switch.
    #  Each function in the base library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    ASSERT = 1
    COLLECTGARBAGE = 2
    DOFILE = 3
    ERROR = 4

    #  private static final int GCINFO = 5;
    GETFENV = 6
    GETMETATABLE = 7
    LOADFILE = 8
    LOAD = 9
    LOADSTRING = 10
    NEXT = 11
    PCALL = 12
    PRINT = 13
    RAWEQUAL = 14
    RAWGET = 15
    RAWSET = 16
    SELECT = 17
    SETFENV = 18
    SETMETATABLE = 19
    TONUMBER = 20
    TOSTRING = 21
    TYPE = 22
    UNPACK = 23
    XPCALL = 24
    IPAIRS = 25
    PAIRS = 26
    IPAIRS_AUX = 27
    PAIRS_AUX = 28

    #  The coroutine functions (which reside in the table "coroutine") are also
    #  part of the base library.
    CREATE = 50
    RESUME = 51
    RUNNING = 52
    STATUS = 53
    WRAP = 54
    YIELD = 55
    WRAP_AUX = 56

    # 
    #    * Lua value that represents the generator function for ipairs.  In
    #    * PUC-Rio this is implemented as an upvalue of ipairs.
    #    
    IPAIRS_AUX_FUN = BaseLib(IPAIRS_AUX)

    # 
    #    * Lua value that represents the generator function for pairs.  In
    #    * PUC-Rio this is implemented as an upvalue of pairs.
    #    
    PAIRS_AUX_FUN = BaseLib(PAIRS_AUX)

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    # 
    #    * For wrapped threads created by coroutine.wrap, this references the
    #    * Lua thread object.
    #    
    thread = None

    #  Constructs instance, filling in the 'which' member. 
    @overloaded
    def __init__(self, which):
        """ generated source for method __init__ """
        super(BaseLib, self).__init__()
        self.which = which
        OutputArr = ArrayList()
        OutputArr.add("")

    #  Instance constructor used by coroutine.wrap. 
    @__init__.register(object, Lua)
    def __init___0(self, L):
        """ generated source for method __init___0 """
        super(BaseLib, self).__init__()
        self.__init__(self.WRAP_AUX)
        self.thread = L

    # 
    #    * Implements all of the functions in the Lua base library.  Do not
    #    * call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.ASSERT:
            return assertFunction(L)
        elif self.which == self.COLLECTGARBAGE:
            return collectgarbage(L)
        elif self.which == self.DOFILE:
            return dofile(L)
        elif self.which == self.ERROR:
            return error(L)
        elif self.which == self.GETFENV:
            return getfenv(L)
        elif self.which == self.GETMETATABLE:
            return getmetatable(L)
        elif self.which == self.IPAIRS:
            return ipairs(L)
        elif self.which == self.LOAD:
            return load(L)
        elif self.which == self.LOADFILE:
            return loadfile(L)
        elif self.which == self.LOADSTRING:
            return loadstring(L)
        elif self.which == self.NEXT:
            return next(L)
        elif self.which == self.PAIRS:
            return pairs(L)
        elif self.which == self.PCALL:
            return pcall(L)
        elif self.which == self.PRINT:
            return print_(L)
        elif self.which == self.RAWEQUAL:
            return rawequal(L)
        elif self.which == self.RAWGET:
            return rawget(L)
        elif self.which == self.RAWSET:
            return rawset(L)
        elif self.which == self.SELECT:
            return select(L)
        elif self.which == self.SETFENV:
            return setfenv(L)
        elif self.which == self.SETMETATABLE:
            return setmetatable(L)
        elif self.which == self.TONUMBER:
            return tonumber(L)
        elif self.which == self.TOSTRING:
            return tostring(L)
        elif self.which == self.TYPE:
            return type_(L)
        elif self.which == self.UNPACK:
            return unpack(L)
        elif self.which == self.XPCALL:
            return xpcall(L)
        elif self.which == self.IPAIRS_AUX:
            return ipairsaux(L)
        elif self.which == self.PAIRS_AUX:
            return pairsaux(L)
        elif self.which == self.CREATE:
            return create(L)
        elif self.which == self.RESUME:
            return resume(L)
        elif self.which == self.RUNNING:
            return running(L)
        elif self.which == self.STATUS:
            return status(L)
        elif self.which == self.WRAP:
            return wrap(L)
        elif self.which == self.YIELD:
            return yield_(L)
        elif self.which == self.WRAP_AUX:
            return wrapaux(L)
        return 0

    # 
    #    * Opens the base library into the given Lua state.  This registers
    #    * the symbols of the base library in the global table.
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        #  set global _G
        L.setGlobal("_G", L.getGlobals())
        #  set global _VERSION
        L.setGlobal("_VERSION", Lua.VERSION)
        r(L, "assert", cls.ASSERT)
        r(L, "collectgarbage", cls.COLLECTGARBAGE)
        r(L, "dofile", cls.DOFILE)
        r(L, "error", cls.ERROR)
        r(L, "getfenv", cls.GETFENV)
        r(L, "getmetatable", cls.GETMETATABLE)
        r(L, "ipairs", cls.IPAIRS)
        r(L, "loadfile", cls.LOADFILE)
        r(L, "load", cls.LOAD)
        r(L, "loadstring", cls.LOADSTRING)
        r(L, "next", cls.NEXT)
        r(L, "pairs", cls.PAIRS)
        r(L, "pcall", cls.PCALL)
        r(L, "print", cls.PRINT)
        r(L, "rawequal", cls.RAWEQUAL)
        r(L, "rawget", cls.RAWGET)
        r(L, "rawset", cls.RAWSET)
        r(L, "select", cls.SELECT)
        r(L, "setfenv", cls.SETFENV)
        r(L, "setmetatable", cls.SETMETATABLE)
        r(L, "tonumber", cls.TONUMBER)
        r(L, "tostring", cls.TOSTRING)
        r(L, "type", cls.TYPE)
        r(L, "unpack", cls.UNPACK)
        r(L, "xpcall", cls.XPCALL)
        L.register("coroutine")
        c(L, "create", cls.CREATE)
        c(L, "resume", cls.RESUME)
        c(L, "running", cls.RUNNING)
        c(L, "status", cls.STATUS)
        c(L, "wrap", cls.WRAP)
        c(L, "yield", cls.YIELD)

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = BaseLib(which)
        L.setGlobal(name, f)

    #  Register a function in the coroutine table. 
    @classmethod
    def c(cls, L, name, which):
        """ generated source for method c """
        f = BaseLib(which)
        L.setField(L.getGlobal("coroutine"), name, f)

    #  Implements assert.  <code>assert</code> is a keyword in some
    #    * versions of Java, so this function has a mangled name.
    #    
    @classmethod
    def assertFunction(cls, L):
        """ generated source for method assertFunction """
        L.checkAny(1)
        if not L.toBoolean(L.value(1)):
            L.error(L.optString(2, "assertion failed!"))
        return L.getTop()

    #  Used by {@link #collectgarbage}. 
    CGOPTS = [None] * 

    #  Used by {@link #collectgarbage}. 
    CGOPTSNUM = [None] * 

    #  Implements collectgarbage. 
    @classmethod
    def collectgarbage(cls, L):
        """ generated source for method collectgarbage """
        o = L.checkOption(1, "collect", cls.CGOPTS)
        ex = L.optInt(2, 0)
        res = L.gc(cls.CGOPTSNUM[o], ex)
        if cls.CGOPTSNUM[o] == Lua.GCCOUNT:
            b = L.gc(Lua.GCCOUNTB, 0)
            L.pushNumber(res + (float(b)) / 1024)
            return 1
        elif cls.CGOPTSNUM[o] == Lua.GCSTEP:
            L.pushBoolean(res != 0)
            return 1
        else:
            L.pushNumber(res)
            return 1

    #  Implements dofile. 
    @classmethod
    def dofile(cls, L):
        """ generated source for method dofile """
        fname = L.optString(1, None)
        n = L.getTop()
        if L.loadFile(fname) != 0:
            L.error(L.value(-1))
        L.call(0, Lua.MULTRET)
        return L.getTop() - n

    #  Implements error. 
    @classmethod
    def error(cls, L):
        """ generated source for method error """
        level = L.optInt(2, 1)
        L.setTop(1)
        if L.isString(L.value(1)) and level > 0:
            L.insert(L.where(level), 1)
            L.concat(2)
        L.error(L.value(1))
        #  NOTREACHED
        return 0

    #  Helper for getfenv and setfenv. 
    @classmethod
    def getfunc(cls, L):
        """ generated source for method getfunc """
        o = L.value(1)
        if L.isFunction(o):
            return o
        else:
            level = L.optInt(1, 1)
            L.argCheck(level >= 0, 1, "level must be non-negative")
            ar = L.getStack(level)
            if ar == None:
                L.argError(1, "invalid level")
            L.getInfo("f", ar)
            o = L.value(-1)
            if L.isNil(o):
                L.error("no function environment for tail call at level " + level)
            L.pop(1)
            return o

    #  Implements getfenv. 
    @classmethod
    def getfenv(cls, L):
        """ generated source for method getfenv """
        o = cls.getfunc(L)
        if Lua.isJavaFunction(o):
            L.push(L.getGlobals())
        else:
            f = o
            L.push(f.getEnv())
        return 1

    #  Implements getmetatable. 
    @classmethod
    def getmetatable(cls, L):
        """ generated source for method getmetatable """
        L.checkAny(1)
        mt = L.getMetatable(L.value(1))
        if mt == None:
            L.pushNil()
            return 1
        protectedmt = L.getMetafield(L.value(1), "__metatable")
        if L.isNil(protectedmt):
            L.push(mt)
            #  return metatable
        else:
            L.push(protectedmt)
            #  return __metatable field
        return 1

    #  Implements load. 
    @classmethod
    def load(cls, L):
        """ generated source for method load """
        cname = L.optString(2, "=(load)")
        L.checkType(1, Lua.TFUNCTION)
        r = BaseLibReader(L, L.value(1))
        status = int()
        status = L.load(r, cname)
        return load_aux(L, status)

    #  Implements loadfile. 
    @classmethod
    def loadfile(cls, L):
        """ generated source for method loadfile """
        fname = L.optString(1, None)
        return load_aux(L, L.loadFile(fname))

    #  Implements loadstring. 
    @classmethod
    def loadstring(cls, L):
        """ generated source for method loadstring """
        s = L.checkString(1)
        chunkname = L.optString(2, s)
        if s.startsWith("\033"):
            #  "binary" dumped into string using string.dump.
            return load_aux(L, L.load(DumpedInput(s), chunkname))
        else:
            return load_aux(L, L.loadString(s, chunkname))

    @classmethod
    def load_aux(cls, L, status):
        """ generated source for method load_aux """
        if status == 0:
            #  OK?
            return 1
        else:
            L.insert(Lua.NIL, -1)
            #  put before error message
            return 2
            #  return nil plus error message

    #  Implements next. 
    @classmethod
    def next(cls, L):
        """ generated source for method next """
        L.checkType(1, Lua.TTABLE)
        L.setTop(2)
        #  Create a 2nd argument is there isn't one
        if L.next(1):
            return 2
        L.push(Lua.NIL)
        return 1

    #  Implements ipairs. 
    @classmethod
    def ipairs(cls, L):
        """ generated source for method ipairs """
        L.checkType(1, Lua.TTABLE)
        L.push(cls.IPAIRS_AUX_FUN)
        L.pushValue(1)
        L.pushNumber(0)
        return 3

    #  Generator for ipairs. 
    @classmethod
    def ipairsaux(cls, L):
        """ generated source for method ipairsaux """
        i = L.checkInt(2)
        L.checkType(1, Lua.TTABLE)
        i += 1
        v = L.rawGetI(L.value(1), i)
        if L.isNil(v):
            return 0
        L.pushNumber(i)
        L.push(v)
        return 2

    #  Implements pairs.  PUC-Rio uses "next" as the generator for pairs.
    #    * Jill doesn't do that because it would be way too slow.  We use the
    #    * {@link java.util.Enumeration} returned from
    #    * {@link java.util.Hashtable#keys}.  The {@link #pairsaux} method
    #    * implements the step-by-step iteration.
    #    
    @classmethod
    def pairs(cls, L):
        """ generated source for method pairs """
        L.checkType(1, Lua.TTABLE)
        L.push(cls.PAIRS_AUX_FUN)
        #  return generator,
        t = L.value(1)
        L.push([None] * )
        #  state,
        L.push(Lua.NIL)
        #  and initial value.
        return 3

    #  Generator for pairs.  This expects a <var>state</var> and
    #    * <var>var</var> as (Lua) arguments.
    #    * The state is setup by {@link #pairs} and is a
    #    * pair of {LuaTable, Enumeration} stored in a 2-element array.  The
    #    * <var>var</var> is not used.  This is in contrast to the PUC-Rio
    #    * implementation, where the state is the table, and the var is used
    #    * to generated the next key in sequence.  The implementation, of
    #    * pairs and pairsaux, has no control over <var>var</var>,  Lua's
    #    * semantics of <code>for</code> force it to be the previous result
    #    * returned by this function.  In Jill this value is not suitable to
    #    * use for enumeration, which is why it isn't used.
    #    
    @classmethod
    def pairsaux(cls, L):
        """ generated source for method pairsaux """
        a = L.value(1)
        t = a[0]
        e = a[1]
        if not e.hasMoreElements():
            return 0
        key = e.nextElement()
        L.push(key)
        L.push(t.getlua(key))
        return 2

    #  Implements pcall. 
    @classmethod
    def pcall(cls, L):
        """ generated source for method pcall """
        L.checkAny(1)
        status = L.pcall(L.getTop() - 1, Lua.MULTRET, None)
        b = (status == 0)
        L.insert(Lua.valueOfBoolean(b), 1)
        return L.getTop()

    # 
    #    * The {@link PrintStream} used by print.  Makes it more convenient if
    #    * redirection is desired.  For example, client code could implement
    #    * their own instance which sent output to the screen of a JME device.
    #    
    OUT = System.out
    OutputArr = None

    #  Implements print. 
    @classmethod
    def print_(cls, L):
        """ generated source for method print_ """
        n = L.getTop()
        tostring = L.getGlobal("tostring")
        i = 1
        while i <= n:
            L.push(tostring)
            L.pushValue(i)
            L.call(1, 1)
            s = L.toString(L.value(-1))
            if s == None:
                return L.error("'tostring' must return a string to 'print'")
            if i > 1:
                cls.OutputArr.set(len(cls.OutputArr) - 1, cls.OutputArr.get(len(cls.OutputArr) - 1) + "\t")
                cls.OUT.print_('\t')
            cls.OutputArr.set(len(cls.OutputArr) - 1, cls.OutputArr.get(len(cls.OutputArr) - 1) + s)
            cls.OUT.print_(s)
            L.pop(1)
            i += 1
        cls.OutputArr.add("")
        cls.OUT.println()
        return 0

    #  Implements rawequal. 
    @classmethod
    def rawequal(cls, L):
        """ generated source for method rawequal """
        L.checkAny(1)
        L.checkAny(2)
        L.pushBoolean(L.rawEqual(L.value(1), L.value(2)))
        return 1

    #  Implements rawget. 
    @classmethod
    def rawget(cls, L):
        """ generated source for method rawget """
        L.checkType(1, Lua.TTABLE)
        L.checkAny(2)
        L.push(L.rawGet(L.value(1), L.value(2)))
        return 1

    #  Implements rawset. 
    @classmethod
    def rawset(cls, L):
        """ generated source for method rawset """
        L.checkType(1, Lua.TTABLE)
        L.checkAny(2)
        L.checkAny(3)
        L.rawSet(L.value(1), L.value(2), L.value(3))
        return 0

    #  Implements select. 
    @classmethod
    def select(cls, L):
        """ generated source for method select """
        n = L.getTop()
        if L.type_(1) == Lua.TSTRING and "#" == L.toString(L.value(1)):
            L.pushNumber(n - 1)
            return 1
        i = L.checkInt(1)
        if i < 0:
            i = n + i
        elif i > n:
            i = n
        L.argCheck(1 <= i, 1, "index out of range")
        return n - i

    #  Implements setfenv. 
    @classmethod
    def setfenv(cls, L):
        """ generated source for method setfenv """
        L.checkType(2, Lua.TTABLE)
        o = cls.getfunc(L)
        first = L.value(1)
        if L.isNumber(first) and L.toNumber(first) == 0:
            #  :todo: change environment of current thread.
            return 0
        elif Lua.isJavaFunction(o) or not L.setFenv(o, L.value(2)):
            L.error("'setfenv' cannot change environment of given object")
        L.push(o)
        return 1

    #  Implements setmetatable. 
    @classmethod
    def setmetatable(cls, L):
        """ generated source for method setmetatable """
        L.checkType(1, Lua.TTABLE)
        t = L.type_(2)
        L.argCheck(t == Lua.TNIL or t == Lua.TTABLE, 2, "nil or table expected")
        if not L.isNil(L.getMetafield(L.value(1), "__metatable")):
            L.error("cannot change a protected metatable")
        L.setMetatable(L.value(1), L.value(2))
        L.setTop(1)
        return 1

    #  Implements tonumber. 
    @classmethod
    def tonumber(cls, L):
        """ generated source for method tonumber """
        base = L.optInt(2, 10)
        if base == 10:
            #  standard conversion
            L.checkAny(1)
            o = L.value(1)
            if L.isNumber(o):
                L.pushNumber(L.toNumber(o))
                return 1
        else:
            s = L.checkString(1)
            L.argCheck(2 <= base and base <= 36, 2, "base out of range")
            #  :todo: consider stripping space and sharing some code with
            #  Lua.vmTostring
            try:
                i = Integer.parseInt(s, base)
                L.pushNumber(i)
                return 1
            except NumberFormatException as e_:
                pass
        L.push(Lua.NIL)
        return 1

    #  Implements tostring. 
    @classmethod
    def tostring(cls, L):
        """ generated source for method tostring """
        L.checkAny(1)
        o = L.value(1)
        if L.callMeta(1, "__tostring"):
            #  is there a metafield?
            return 1
            #  use its value
        if L.type_(1) == Lua.TNUMBER:
            L.push(L.toString(o))
        elif L.type_(1) == Lua.TSTRING:
            L.push(o)
        elif L.type_(1) == Lua.TBOOLEAN:
            if L.toBoolean(o):
                L.pushLiteral("true")
            else:
                L.pushLiteral("false")
        elif L.type_(1) == Lua.TNIL:
            L.pushLiteral("nil")
        else:
            L.push(o.__str__())
        return 1

    #  Implements type. 
    @classmethod
    def type_(cls, L):
        """ generated source for method type_ """
        L.checkAny(1)
        L.push(L.typeNameOfIndex(1))
        return 1

    #  Implements unpack. 
    @classmethod
    def unpack(cls, L):
        """ generated source for method unpack """
        L.checkType(1, Lua.TTABLE)
        t = L.value(1)
        i = L.optInt(2, 1)
        e = L.optInt(3, t.getn())
        n = e - i + 1
        #  number of elements
        if n <= 0:
            return 0
            #  empty range
        #  i already initialised to start index, which isn't necessarily 1
        while i <= e:
            L.push(t.getnum(i))
            i += 1
        return n

    #  Implements xpcall. 
    @classmethod
    def xpcall(cls, L):
        """ generated source for method xpcall """
        L.checkAny(2)
        errfunc = L.value(2)
        L.setTop(1)
        #  remove error function from stack
        status = L.pcall(0, Lua.MULTRET, errfunc)
        L.insert(Lua.valueOfBoolean(status == 0), 1)
        return L.getTop()
        #  return status + all results

    #  Implements coroutine.create. 
    @classmethod
    def create(cls, L):
        """ generated source for method create """
        NL = L.newThread()
        faso = L.value(1)
        L.argCheck(L.isFunction(faso) and not Lua.isJavaFunction(faso), 1, "Lua function expected")
        L.setTop(1)
        #  function is at top
        L.xmove(NL, 1)
        #  move function from L to NL
        L.push(NL)
        return 1

    #  Implements coroutine.resume. 
    @classmethod
    def resume(cls, L):
        """ generated source for method resume """
        co = L.toThread(L.value(1))
        L.argCheck(co != None, 1, "coroutine expected")
        r = auxresume(L, co, L.getTop() - 1)
        if r < 0:
            L.insert(Lua.valueOfBoolean(False), -1)
            return 2
            #  return false + error message
        L.insert(Lua.valueOfBoolean(True), L.getTop() - (r - 1))
        return r + 1
        #  return true + 'resume' returns

    #  Implements coroutine.running. 
    @classmethod
    def running(cls, L):
        """ generated source for method running """
        if L.isMain():
            return 0
            #  main thread is not a coroutine
        L.push(L)
        return 1

    #  Implements coroutine.status. 
    @classmethod
    def status(cls, L):
        """ generated source for method status """
        co = L.toThread(L.value(1))
        L.argCheck(co != None, 1, "coroutine expected")
        if L == co:
            L.pushLiteral("running")
        else:
            if co.status() == Lua.YIELD:
                L.pushLiteral("suspended")
            elif co.status() == 0:
                ar = co.getStack(0)
                if ar != None:
                    #  does it have frames?
                    L.pushLiteral("normal")
                    #  it is running
                elif co.getTop() == 0:
                    L.pushLiteral("dead")
                else:
                    L.pushLiteral("suspended")
                    #  initial state
            else:
                #  some error occured
                L.pushLiteral("dead")
        return 1

    #  Implements coroutine.wrap. 
    @classmethod
    def wrap(cls, L):
        """ generated source for method wrap """
        cls.create(L)
        L.push(wrapit(L.toThread(L.value(-1))))
        return 1

    #  Helper for wrap.  Returns a LuaJavaCallback that has access to the
    #    * Lua thread.
    #    * @param L the Lua thread to be wrapped.
    #    
    @classmethod
    def wrapit(cls, L):
        """ generated source for method wrapit """
        return BaseLib(L)

    #  Helper for wrap.  This implements the function returned by wrap. 
    def wrapaux(self, L):
        """ generated source for method wrapaux """
        co = self.thread
        r = auxresume(L, co, L.getTop())
        if r < 0:
            if L.isString(L.value(-1)):
                #  error object is a string?
                w = L.where(1)
                L.insert(w, -1)
                L.concat(2)
            L.error(L.value(-1))
            #  propagate error
        return r

    @classmethod
    def auxresume(cls, L, co, narg):
        """ generated source for method auxresume """
        #  if (!co.checkStack...
        if co.status() == 0 and co.getTop() == 0:
            L.pushLiteral("cannot resume dead coroutine")
            return -1
            #  error flag;
        L.xmove(co, narg)
        status = co.resume(narg)
        if status == 0 or status == Lua.YIELD:
            nres = co.getTop()
            #  if (!L.checkStack...
            co.xmove(L, nres)
            #  move yielded values
            return nres
        co.xmove(L, 1)
        #  move error message
        return -1
        #  error flag;

    #  Implements coroutine.yield. 
    @classmethod
    def yield_(cls, L):
        """ generated source for method yield_ """
        return L.yield_(L.getTop())

