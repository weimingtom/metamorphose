#!/usr/bin/env python
""" generated source for module LauncherApplet """
from __future__ import print_function
# package: com.iteye.weimingtom.metamorphose.launcher
class LauncherApplet(JApplet):
    """ generated source for class LauncherApplet """
    serialVersionUID = -2353821250345588401

    def __init__(self):
        """ generated source for method __init__ """
        super(LauncherApplet, self).__init__()

    font = None
    frameTop = None
    panelOutput = None
    textAreaOutput = None
    scrollPaneOutput = None
    panelInput = None
    textAreaInput = None
    scrollPaneInput = None

    def initFrame(self):
        """ generated source for method initFrame """
        self.font = Font("song", Font.BOLD, 20)
        self.frameTop = getContentPane()
        initPanel()
        initPanelOutput()
        initPanelInput()

    def initPanel(self):
        """ generated source for method initPanel """
        self.panelOutput = JPanel()
        self.panelOutput.setLayout(GridLayout(1, 1))
        self.panelOutput.setBackground(Color(220, 235, 245))
        self.frameTop.add(self.panelOutput, BorderLayout.CENTER)
        self.panelInput = JPanel()
        self.panelInput.setLayout(BorderLayout())
        self.panelInput.setPreferredSize(Dimension(800, 100))
        # small height
        self.panelInput.setBackground(Color(222, 235, 245))
        self.frameTop.add(self.panelInput, BorderLayout.SOUTH)

    def initPanelOutput(self):
        """ generated source for method initPanelOutput """
        self.textAreaOutput = JMenuTextArea()
        self.textAreaOutput.setBackground(Color.BLACK)
        self.textAreaOutput.setForeground(Color.GREEN)
        self.textAreaOutput.setCaretColor(Color.GREEN)
        self.textAreaOutput.setSelectionColor(Color.WHITE)
        self.textAreaOutput.setFont(self.font)
        self.textAreaOutput.setLineWrap(True)
        self.textAreaOutput.setWrapStyleWord(True)
        self.textAreaOutput.setEditable(False)
        self.textAreaOutput.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5))
        self.scrollPaneOutput = JScrollPane(self.textAreaOutput)
        self.scrollPaneOutput.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0))
        self.panelOutput.add(self.scrollPaneOutput)

    def initPanelInput(self):
        """ generated source for method initPanelInput """
        textAreaPre = JLabel()
        textAreaPre.setBackground(Color.BLACK)
        textAreaPre.setForeground(Color.GREEN)
        textAreaPre.setFont(self.font)
        textAreaPre.setText("> ")
        textAreaPre.setOpaque(True)
        textAreaPre.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 0))
        textAreaPre.setHorizontalAlignment(SwingConstants.LEADING)
        textAreaPre.setVerticalAlignment(SwingConstants.TOP)
        self.panelInput.add(textAreaPre, BorderLayout.WEST)
        self.textAreaInput = JMenuTextArea()
        self.textAreaInput.setBackground(Color.BLACK)
        self.textAreaInput.setForeground(Color.GREEN)
        self.textAreaInput.setCaretColor(Color.GREEN)
        self.textAreaInput.setSelectionColor(Color.WHITE)
        self.textAreaInput.setFont(self.font)
        self.textAreaInput.setLineWrap(True)
        self.textAreaInput.setWrapStyleWord(True)
        self.textAreaInput.addKeyListener(KeyAdapter())
        self.textAreaInput.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 5))
        self.scrollPaneInput = JScrollPane(self.textAreaInput)
        self.scrollPaneInput.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0))
        self.panelInput.add(self.scrollPaneInput, BorderLayout.CENTER)

    # 
    # 	 * @see http://bbs.csdn.net/topics/330223621
    # 	 
    def scrollBottom(self):
        """ generated source for method scrollBottom """
        # 		textAreaInput.setCaretPosition(textAreaInput.getDocument().getLength());
        # 		JScrollBar sbar = scrollPaneInput.getVerticalScrollBar(); 
        # 		int max = sbar.getMaximum();
        # 		sbar.setValue(max);
        # 		Document doc = textAreaInput.getDocument();
        # 		textAreaInput.select(doc.getLength(), doc.getLength()); 

    # 
    # 	 * @see http://stackoverflow.com/questions/5147768/scroll-jscrollpane-to-bottom
    # 	 
    def scrollToBottom(self, scrollPane):
        """ generated source for method scrollToBottom """
        verticalBar = scrollPane.getVerticalScrollBar()
        downScroller = AdjustmentListener()
        verticalBar.addAdjustmentListener(downScroller)

    # 
    # 	 * @see http://www.oschina.net/code/snippet_54100_1242
    # 	 * @author Administrator
    # 	 *
    # 	 
    class JMenuTextArea(JTextArea, MouseListener):
        """ generated source for class JMenuTextArea """
        serialVersionUID = -2308615404205560110
        pop = None
        copy = None
        paste = None
        cut = None

        def __init__(self):
            """ generated source for method __init__ """
            super(JMenuTextArea, self).__init__()
            init()

        def init(self):
            """ generated source for method init """
            self.addMouseListener(self)
            self.pop = JPopupMenu()
            self.pop.add(self.copy = JMenuItem("Copy"))
            self.pop.add(self.paste = JMenuItem("Paste"))
            self.pop.add(self.cut = JMenuItem("Cut"))
            self.copy.setAccelerator(KeyStroke.getKeyStroke('C', InputEvent.CTRL_MASK))
            self.paste.setAccelerator(KeyStroke.getKeyStroke('V', InputEvent.CTRL_MASK))
            self.cut.setAccelerator(KeyStroke.getKeyStroke('X', InputEvent.CTRL_MASK))
            self.copy.addActionListener(ActionListener())
            self.paste.addActionListener(ActionListener())
            self.cut.addActionListener(ActionListener())
            self.add(self.pop)

        def action(self, e):
            """ generated source for method action """
            str_ = e.getActionCommand()
            if str_ == self.copy.getText():
                self.copy()
            elif str_ == self.paste.getText():
                self.paste()
            elif str_ == self.cut.getText():
                self.cut()

        def getPop(self):
            """ generated source for method getPop """
            return self.pop

        def setPop(self, pop):
            """ generated source for method setPop """
            self.pop = pop

        def isClipboardString(self):
            """ generated source for method isClipboardString """
            b = False
            clipboard = self.getToolkit().getSystemClipboard()
            content = clipboard.getContents(self)
            try:
                if isinstance(, (str, )):
                    b = True
            except Exception as e:
                pass
            return b

        def isCanCopy(self):
            """ generated source for method isCanCopy """
            b = False
            start = self.getSelectionStart()
            end = self.getSelectionEnd()
            if start != end:
                b = True
            return b

        def mouseClicked(self, e):
            """ generated source for method mouseClicked """

        def mouseEntered(self, e):
            """ generated source for method mouseEntered """

        def mouseExited(self, e):
            """ generated source for method mouseExited """

        def mousePressed(self, e):
            """ generated source for method mousePressed """
            if e.getButton() == MouseEvent.BUTTON3:
                self.copy.setEnabled(self.isCanCopy())
                self.paste.setEnabled(self.isClipboardString())
                self.cut.setEnabled(self.isCanCopy())
                self.pop.show(self, e.getX(), e.getY())

        def mouseReleased(self, e):
            """ generated source for method mouseReleased """

    _L = None
    _isLoadLib = True
    _arrHistory = ArrayList()
    _nHistoryIndex = 0

    def execute(self, str_):
        """ generated source for method execute """
        self._L.setTop(0)
        BaseLib.OutputArr = ArrayList()
        BaseLib.OutputArr.add("")
        res = self._L.doString(str_)
        OutputArrBuffer = StringBuffer()
        i = 0
        while i < len(BaseLib.OutputArr):
            output = BaseLib.OutputArr.get(i)
            if i == len(BaseLib.OutputArr) - 1:
                OutputArrBuffer.append(output)
            else:
                OutputArrBuffer.append(output).append("\n")
            i += 1
        log(OutputArrBuffer.__str__(), False)
        if res == 0:
            obj = self._L.value(1)
            tostring = self._L.getGlobal("tostring")
            self._L.push(tostring)
            self._L.push(obj)
            self._L.call(1, 1)
            resultStr = self._L.toString(self._L.value(-1))
            log(resultStr)
        else:
            result = "Error: " + res
            if res == Lua.ERRRUN:
                result += " Runtime error"
            elif res == Lua.ERRSYNTAX:
                result += " Syntax error"
            elif res == Lua.ERRERR:
                result += " Error error"
            elif res == Lua.ERRFILE:
                result += " File error"
            log("[Error] " + result)
            log("[Error Info] " + self._L.value(1))

    def initLua(self):
        """ generated source for method initLua """
        self.textAreaInput.setText("return 1 + 1")
        log(Lua.RELEASE + "  " + Lua.COPYRIGHT)
        self._L = Lua()
        if self._isLoadLib:
            BaseLib.open(self._L)
            PackageLib.open(self._L)
            MathLib.open(self._L)
            OSLib.open(self._L)
            StringLib.open(self._L)
            TableLib.open(self._L)

    @overloaded
    def log(self, str_):
        """ generated source for method log """
        self.log(str_, True)

    @log.register(object, str, bool)
    def log_0(self, str_, lineReturn):
        """ generated source for method log_0 """
        self.textAreaOutput.append(str_ + ("\n" if lineReturn else ""))
        self.textAreaInput.setText(None)
        self.scrollToBottom(self.scrollPaneInput)

    def init(self):
        """ generated source for method init """
        super(LauncherApplet, self).init()
        self.initFrame()
        self.textAreaInput.requestFocus()
        self.initLua()

