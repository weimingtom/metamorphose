#!/usr/bin/env python
""" generated source for module MathLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/MathLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Contains Lua's math library.
#  * The library can be opened using the {@link #open} method.
#  * Because this library is implemented on top of CLDC 1.1 it is not as
#  * complete as the PUC-Rio math library.  Trigononmetric inverses
#  * (EG <code>acos</code>) and hyperbolic trigonometric functions (EG
#  * <code>cosh</code>) are not provided.
#  
class MathLib(LuaJavaCallback):
    """ generated source for class MathLib """
    #  Each function in the library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    ABS = 1

    # private static final int acos = 2;
    # private static final int asin = 3;
    # private static final int atan2 = 4;
    # private static final int atan = 5;
    CEIL = 6

    # private static final int cosh = 7;
    COS = 8
    DEG = 9
    EXP = 10
    FLOOR = 11
    FMOD = 12

    # private static final int frexp = 13;
    # private static final int ldexp = 14;
    # private static final int log = 15;
    MAX = 16
    MIN = 17
    MODF = 18
    POW = 19
    RAD = 20
    RANDOM = 21
    RANDOMSEED = 22

    # private static final int sinh = 23;
    SIN = 24
    SQRT = 25

    # private static final int tanh = 26;
    TAN = 27
    rng = Random()

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    #  Constructs instance, filling in the 'which' member. 
    def __init__(self, which):
        """ generated source for method __init__ """
        super(MathLib, self).__init__()
        self.which = which

    # 
    #    * Implements all of the functions in the Lua math library.  Do not
    #    * call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.ABS:
            return abs(L)
        elif self.which == self.CEIL:
            return ceil(L)
        elif self.which == self.COS:
            return cos(L)
        elif self.which == self.DEG:
            return deg(L)
        elif self.which == self.EXP:
            return exp(L)
        elif self.which == self.FLOOR:
            return floor(L)
        elif self.which == self.FMOD:
            return fmod(L)
        elif self.which == self.MAX:
            return max(L)
        elif self.which == self.MIN:
            return min(L)
        elif self.which == self.MODF:
            return modf(L)
        elif self.which == self.POW:
            return pow(L)
        elif self.which == self.RAD:
            return rad(L)
        elif self.which == self.RANDOM:
            return random(L)
        elif self.which == self.RANDOMSEED:
            return randomseed(L)
        elif self.which == self.SIN:
            return sin(L)
        elif self.which == self.SQRT:
            return sqrt(L)
        elif self.which == self.TAN:
            return tan(L)
        return 0

    # 
    #    * Opens the library into the given Lua state.  This registers
    #    * the symbols of the library in the global table.
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        t = L.register("math")
        r(L, "abs", cls.ABS)
        r(L, "ceil", cls.CEIL)
        r(L, "cos", cls.COS)
        r(L, "deg", cls.DEG)
        r(L, "exp", cls.EXP)
        r(L, "floor", cls.FLOOR)
        r(L, "fmod", cls.FMOD)
        r(L, "max", cls.MAX)
        r(L, "min", cls.MIN)
        r(L, "modf", cls.MODF)
        r(L, "pow", cls.POW)
        r(L, "rad", cls.RAD)
        r(L, "random", cls.RANDOM)
        r(L, "randomseed", cls.RANDOMSEED)
        r(L, "sin", cls.SIN)
        r(L, "sqrt", cls.SQRT)
        r(L, "tan", cls.TAN)
        L.setField(t, "pi", Lua.valueOfNumber(PI))
        L.setField(t, "huge", Lua.valueOfNumber(Double.POSITIVE_INFINITY))

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = MathLib(which)
        L.setField(L.getGlobal("math"), name, f)

    @classmethod
    def abs(cls, L):
        """ generated source for method abs """
        L.pushNumber(abs(L.checkNumber(1)))
        return 1

    @classmethod
    def ceil(cls, L):
        """ generated source for method ceil """
        L.pushNumber(ceil(L.checkNumber(1)))
        return 1

    @classmethod
    def cos(cls, L):
        """ generated source for method cos """
        L.pushNumber(cos(L.checkNumber(1)))
        return 1

    @classmethod
    def deg(cls, L):
        """ generated source for method deg """
        L.pushNumber(toDegrees(L.checkNumber(1)))
        return 1

    @classmethod
    def exp(cls, L):
        """ generated source for method exp """
        #  CLDC 1.1 has E but no exp, pow, or log.  Bizarre.
        L.pushNumber(Lua.iNumpow(E, L.checkNumber(1)))
        return 1

    @classmethod
    def floor(cls, L):
        """ generated source for method floor """
        L.pushNumber(floor(L.checkNumber(1)))
        return 1

    @classmethod
    def fmod(cls, L):
        """ generated source for method fmod """
        L.pushNumber(L.checkNumber(1) % L.checkNumber(2))
        return 1

    @classmethod
    def max(cls, L):
        """ generated source for method max """
        n = L.getTop()
        #  number of arguments
        dmax = L.checkNumber(1)
        i = 2
        while i <= n:
            d = L.checkNumber(i)
            dmax = max(dmax, d)
            i += 1
        L.pushNumber(dmax)
        return 1

    @classmethod
    def min(cls, L):
        """ generated source for method min """
        n = L.getTop()
        #  number of arguments
        dmin = L.checkNumber(1)
        i = 2
        while i <= n:
            d = L.checkNumber(i)
            dmin = min(dmin, d)
            i += 1
        L.pushNumber(dmin)
        return 1

    @classmethod
    def modf(cls, L):
        """ generated source for method modf """
        x = L.checkNumber(1)
        fp = x % 1
        ip = x - fp
        L.pushNumber(ip)
        L.pushNumber(fp)
        return 2

    @classmethod
    def pow(cls, L):
        """ generated source for method pow """
        L.pushNumber(Lua.iNumpow(L.checkNumber(1), L.checkNumber(2)))
        return 1

    @classmethod
    def rad(cls, L):
        """ generated source for method rad """
        L.pushNumber(toRadians(L.checkNumber(1)))
        return 1

    @classmethod
    def random(cls, L):
        """ generated source for method random """
        #  It would seem better style to associate the java.util.Random
        #  instance with the Lua instance (by implementing and using a
        #  registry for example).  However, PUC-rio uses the ISO C library
        #  and so will share the same random number generator across all Lua
        #  states.  So we do too.
        if L.getTop() == 0:
            #  no arguments
            L.pushNumber(cls.rng.nextDouble())
        elif L.getTop() == 1:
            #  only upper limit
            u = L.checkInt(1)
            L.argCheck(1 <= u, 1, "interval is empty")
            L.pushNumber(cls.rng.nextInt(u) + 1)
        elif L.getTop() == 2:
            #  lower and upper limits
            l = L.checkInt(1)
            u = L.checkInt(2)
            L.argCheck(l <= u, 2, "interval is empty")
            L.pushNumber(cls.rng.nextInt(u) + l)
        else:
            return L.error("wrong number of arguments")
        return 1

    @classmethod
    def randomseed(cls, L):
        """ generated source for method randomseed """
        cls.rng.setSeed(long(L.checkNumber(1)))
        return 0

    @classmethod
    def sin(cls, L):
        """ generated source for method sin """
        L.pushNumber(sin(L.checkNumber(1)))
        return 1

    @classmethod
    def sqrt(cls, L):
        """ generated source for method sqrt """
        L.pushNumber(sqrt(L.checkNumber(1)))
        return 1

    @classmethod
    def tan(cls, L):
        """ generated source for method tan """
        L.pushNumber(tan(L.checkNumber(1)))
        return 1

