#!/usr/bin/env python
""" generated source for module Test001 """
from __future__ import print_function
# package: com.iteye.weimingtom.metamorphose.test
class Test001(object):
    """ generated source for class Test001 """
    # 
    # 	 * @param args
    # 	 
    @classmethod
    def main(cls, args):
        """ generated source for method main """
        test001 = "n = 99 + (1 * 10) / 2 - 0.5;\n" + "if n > 10 then return 'Oh, larger than 10:'..n end\n" + "return n\n"
        test002 = "return _VERSION"
        test003 = "return nil"
        test004 = "io.write(\"Hello world, from \",_VERSION,\"!\\n\")"
        test005 = "function printf(...)\n" + " io.write(string.format(...))\n" + "end\n" + "\n" + "" + "printf(\"Hello %s from %s on %s\\n\",os.getenv\"USER\" or \"there\",_VERSION,os.date())"
        test006 = "-- echo command line arguments\n" + "\n" + "for i=0,table.getn(arg) do\n" + " print(i,arg[i])\n" + "end"
        test007 = "-- read environment variables as if they were global variables\n" + "\n" + "local f=function (t,i) return os.getenv(i) end\n" + "setmetatable(getfenv(),{__index=f})\n" + "\n" + "-- an example\n" + "print(a,USER,PATH)\n"
        test008 = "-- example of for with generator functions\n" + "\n" + "function generatefib (n)\n" + "  return coroutine.wrap(function ()\n" + "    local a,b = 1, 1\n" + "    while a <= n do\n" + "      coroutine.yield(a)\n" + "      a, b = b, a+b\n" + "    end\n" + "  end)\n" + "end\n" + "\n" + "for i in generatefib(1000) do print(i) end\n"
        isLoadLib = True
        useArg = True
        argv = [None] * 
        try:
            L = Lua()
            if isLoadLib:
                BaseLib.open(L)
                PackageLib.open(L)
                MathLib.open(L)
                OSLib.open(L)
                StringLib.open(L)
                TableLib.open(L)
                IOLib.open(L)
            if useArg:
                # FIXME: index may be minus (for example, arg[-1], before script file name)
                # @see http://www.ttlsa.com/lua/lua-install-and-lua-variable-ttlsa/
                narg = int()
                tbl = L.createTable(narg, narg)
                i = 0
                while i < narg:
                    L.rawSetI(tbl, i, argv[i])
                    i += 1
                L.setGlobal("arg", tbl)
            status = L.doString(test008)
            if status != 0:
                errObj = L.value(1)
                tostring = L.getGlobal("tostring")
                L.push(tostring)
                L.push(errObj)
                L.call(1, 1)
                errObjStr = L.toString(L.value(-1))
                raise Exception("Error compiling : " + errObjStr)
            else:
                result = L.value(1)
                tostring_ = L.getGlobal("tostring")
                L.push(tostring_)
                L.push(result)
                L.call(1, 1)
                resultStr = L.toString(L.value(-1))
                System.err.println("Result >>> " + resultStr)
        except Exception as e:
            e.printStackTrace()


if __name__ == '__main__':
    import sys
    Test001.main(sys.argv)

