#!/usr/bin/env python
""" generated source for module Syntax """
from __future__ import print_function
def bsr(value, bits):
    """ bsr(value, bits) -> value shifted right by bits

    This function is here because an expression in the original java
    source contained the token '>>>' and/or '>>>=' (bit shift right
    and/or bit shift right assign).  In place of these, the python
    source code below contains calls to this function.

    Copyright 2003 Jeffrey Clement.  See pyrijnadel.py for license and
    original source.
    """
    minint = -2147483648
    if bits == 0:
        return value
    elif bits == 31:
        if value & minint:
            return 1
        else:
            return 0
    elif bits < 0 or bits > 31:
        raise ValueError('bad shift count')
    tmp = (value & 0x7FFFFFFE) // 2**bits
    if (value & minint):
        return (tmp | (0x40000000 // 2**(bits-1)))
    else:
        return tmp

#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Syntax.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Syntax analyser.  Lexing, parsing, code generation.
#  
class Syntax(object):
    """ generated source for class Syntax """
    #  End of File, must be -1 as that is what read() returns. 
    EOZ = -1
    FIRST_RESERVED = 257

    #  WARNING: if you change the order of this enumeration,
    #  grep "ORDER RESERVED"
    TK_AND = FIRST_RESERVED + 0
    TK_BREAK = FIRST_RESERVED + 1
    TK_DO = FIRST_RESERVED + 2
    TK_ELSE = FIRST_RESERVED + 3
    TK_ELSEIF = FIRST_RESERVED + 4
    TK_END = FIRST_RESERVED + 5
    TK_FALSE = FIRST_RESERVED + 6
    TK_FOR = FIRST_RESERVED + 7
    TK_FUNCTION = FIRST_RESERVED + 8
    TK_IF = FIRST_RESERVED + 9
    TK_IN = FIRST_RESERVED + 10
    TK_LOCAL = FIRST_RESERVED + 11
    TK_NIL = FIRST_RESERVED + 12
    TK_NOT = FIRST_RESERVED + 13
    TK_OR = FIRST_RESERVED + 14
    TK_REPEAT = FIRST_RESERVED + 15
    TK_RETURN = FIRST_RESERVED + 16
    TK_THEN = FIRST_RESERVED + 17
    TK_TRUE = FIRST_RESERVED + 18
    TK_UNTIL = FIRST_RESERVED + 19
    TK_WHILE = FIRST_RESERVED + 20
    TK_CONCAT = FIRST_RESERVED + 21
    TK_DOTS = FIRST_RESERVED + 22
    TK_EQ = FIRST_RESERVED + 23
    TK_GE = FIRST_RESERVED + 24
    TK_LE = FIRST_RESERVED + 25
    TK_NE = FIRST_RESERVED + 26
    TK_NUMBER = FIRST_RESERVED + 27
    TK_NAME = FIRST_RESERVED + 28
    TK_STRING = FIRST_RESERVED + 29
    TK_EOS = FIRST_RESERVED + 30
    NUM_RESERVED = TK_WHILE - FIRST_RESERVED + 1

    #  Equivalent to luaX_tokens.  ORDER RESERVED 
    tokens = [None] * 
    reserved = Hashtable()
    i = 0

    #  From struct LexState
    #  current character 
    current = int()

    #  input line counter 
    linenumber = 1

    #  line of last token 'consumed' 
    lastline = 1

    # 
    #    * The token value.  For "punctuation" tokens this is the ASCII value
    #    * for the character for the token; for other tokens a member of the
    #    * enum (all of which are > 255).
    #    
    token = int()

    #  Semantic info for token; a number. 
    tokenR = float()

    #  Semantic info for token; a string. 
    tokenS = None

    #  Lookahead token value. 
    lookahead = TK_EOS

    #  Semantic info for lookahead; a number. 
    lookaheadR = float()

    #  Semantic info for lookahead; a string. 
    lookaheadS = None

    #  Semantic info for return value from {@link #llex}; a number. 
    semR = float()

    #  As {@link #semR}, for string. 
    semS = None

    #  FuncState for current (innermost) function being parsed. 
    fs = None
    L = None

    #  input stream 
    z = None

    #  Buffer for tokens. 
    buff = StringBuffer()

    #  current source name 
    source = None

    #  locale decimal point. 
    decpoint = '.'

    def __init__(self, L, z, source):
        """ generated source for method __init__ """
        self.L = L
        self.z = z
        self.source = source
        next()

    def lastline(self):
        """ generated source for method lastline """
        return self.lastline

    #  From <ctype.h>
    #  Implementations of functions from <ctype.h> are only correct copies
    #  to the extent that Lua requires them.
    #  Generally they have default access so that StringLib can see them.
    #  Unlike C's these version are not locale dependent, they use the
    #  ISO-Latin-1 definitions from CLDC 1.1 Character class.
    @classmethod
    def isalnum(cls, c):
        """ generated source for method isalnum """
        ch = str(c)
        return Character.isUpperCase(ch) or Character.isLowerCase(ch) or Character.isDigit(ch)

    @classmethod
    def isalpha(cls, c):
        """ generated source for method isalpha """
        ch = str(c)
        return Character.isUpperCase(ch) or Character.isLowerCase(ch)

    #  True if and only if the char (when converted from the int) is a
    #    * control character.
    #    
    @classmethod
    def iscntrl(cls, c):
        """ generated source for method iscntrl """
        return str(c) < 0x20 or c == 0x7f

    @classmethod
    def isdigit(cls, c):
        """ generated source for method isdigit """
        return Character.isDigit(str(c))

    @classmethod
    def islower(cls, c):
        """ generated source for method islower """
        return Character.isLowerCase(str(c))

    # 
    #    * A character is punctuation if not cntrl, not alnum, and not space.
    #    
    @classmethod
    def ispunct(cls, c):
        """ generated source for method ispunct """
        return not cls.isalnum(c) and not cls.iscntrl(c) and not isspace(c)

    @classmethod
    def isspace(cls, c):
        """ generated source for method isspace """
        return c == ' ' or c == '\f' or c == '\n' or c == '\r' or c == '\t'

    @classmethod
    def isupper(cls, c):
        """ generated source for method isupper """
        return Character.isUpperCase(str(c))

    @classmethod
    def isxdigit(cls, c):
        """ generated source for method isxdigit """
        return Character.isDigit(str(c)) or ('a' <= c and c <= 'f') or ('A' <= c and c <= 'F')

    #  From llex.c
    def check_next(self, set):
        """ generated source for method check_next """
        if set.indexOf(self.current) < 0:
            return False
        save_and_next()
        return True

    def currIsNewline(self):
        """ generated source for method currIsNewline """
        return self.current == '\n' or self.current == '\r'

    def inclinenumber(self):
        """ generated source for method inclinenumber """
        old = self.current
        # # assert currIsNewline()
        next()
        #  skip '\n' or '\r'
        if self.currIsNewline() and self.current != old:
            next()
            #  skip '\n\r' or '\r\n'
        linenumber += 1
        if linenumber < 0:
            #  overflow
            xSyntaxerror("chunk has too many lines")

    def skip_sep(self):
        """ generated source for method skip_sep """
        count = 0
        s = self.current
        # # assert s == '[' || s == ']'
        save_and_next()
        while self.current == '=':
            save_and_next()
            count += 1
        return count if (self.current == s) else (-count) - 1

    def read_long_string(self, isString, sep):
        """ generated source for method read_long_string """
        cont = 0
        save_and_next()
        #  skip 2nd `[' 
        if self.currIsNewline():
            self.inclinenumber()
        #  skip it 
        while True:
            if self.current == self.EOZ:
                xLexerror("unfinished long string" if isString else "unfinished long comment", self.TK_EOS)
            elif self.current == ']':
                if self.skip_sep() == sep:
                    save_and_next()
                    #  skip 2nd `]' 
            elif self.current == '\n':
                pass
            elif self.current == '\r':
                save('\n')
                self.inclinenumber()
                if not isString:
                    self.buff.setLength(0)
                #  avoid wasting space 
            else:
                if isString:
                    save_and_next()
                else:
                    next()
        #  loop 
        if isString:
            rawtoken = self.buff.__str__()
            trim_by = 2 + sep
            self.semS = rawtoken.substring(trim_by, trim_by - len(rawtoken))

    #  Lex a token and return it.  The semantic info for the token is
    #    * stored in <code>this.semR</code> or <code>this.semS</code> as
    #    * appropriate.
    #    
    def llex(self):
        """ generated source for method llex """
        self.buff.setLength(0)
        while True:
            if self.current == '\n':
                pass
            elif self.current == '\r':
                self.inclinenumber()
                continue 
            elif self.current == '-':
                next()
                if self.current != '-':
                    return '-'
                #  else is a comment 
                next()
                if self.current == '[':
                    sep = self.skip_sep()
                    self.buff.setLength(0)
                    #  `skip_sep' may dirty the buffer 
                    if sep >= 0:
                        self.read_long_string(False, sep)
                        #  long comment 
                        self.buff.setLength(0)
                        continue 
                #  else short comment 
                while not self.currIsNewline() and self.current != self.EOZ:
                continue 
            elif self.current == '[':
                sep = self.skip_sep()
                if sep >= 0:
                    self.read_long_string(True, sep)
                    return self.TK_STRING
                elif sep == -1:
                    return '['
                else:
                    xLexerror("invalid long string delimiter", self.TK_STRING)
                continue 
            elif self.current == '=':
                next()
                if self.current != '=':
                    return '='
                else:
                    next()
                    return self.TK_EQ
            elif self.current == '<':
                next()
                if self.current != '=':
                    return '<'
                else:
                    next()
                    return self.TK_LE
            elif self.current == '>':
                next()
                if self.current != '=':
                    return '>'
                else:
                    next()
                    return self.TK_GE
            elif self.current == '~':
                next()
                if self.current != '=':
                    return '~'
                else:
                    next()
                    return self.TK_NE
            elif self.current == '"':
                pass
            elif self.current == '\'':
                read_string(self.current)
                return self.TK_STRING
            elif self.current == '.':
                save_and_next()
                if self.check_next("."):
                    if self.check_next("."):
                        return self.TK_DOTS
                    else:
                        return self.TK_CONCAT
                elif not self.isdigit(self.current):
                    return '.'
                else:
                    read_numeral()
                    return self.TK_NUMBER
            elif self.current == self.EOZ:
                return self.TK_EOS
            else:
                if self.isspace(self.current):
                    #  assert !currIsNewline();
                    next()
                    continue 
                elif self.isdigit(self.current):
                    read_numeral()
                    return self.TK_NUMBER
                elif self.isalpha(self.current) or self.current == '_':
                    #  identifier or reserved word
                    while True:
                        save_and_next()
                        if not ((self.isalnum(self.current) or self.current == '_')):
                            break
                    s = self.buff.__str__()
                    t = self.reserved.get(s)
                    if t == None:
                        self.semS = s
                        return self.TK_NAME
                    else:
                        return (int(t)).intValue()
                else:
                    c = self.current
                    next()
                    return c
                    #  single-char tokens

    def next(self):
        """ generated source for method next """
        self.current = self.z.read()

    #  Reads number.  Writes to semR. 
    def read_numeral(self):
        """ generated source for method read_numeral """
        #  assert isdigit(current);
        while True:
            save_and_next()
            if not ((self.isdigit(self.current) or self.current == '.')):
                break
        if self.check_next("Ee"):
            #  'E' ?
            self.check_next("+-")
            #  optional exponent sign
        while self.isalnum(self.current) or self.current == '_':
            save_and_next()
        #  :todo: consider doing PUC-Rio's decimal point tricks.
        try:
            self.semR = Double.parseDouble(self.buff.__str__())
            return
        except NumberFormatException as e:
            xLexerror("malformed number", self.TK_NUMBER)

    #  Reads string.  Writes to semS. 
    def read_string(self, del_):
        """ generated source for method read_string """
        save_and_next()
        i += 1
        while self.current != del_:
            if self.current == self.EOZ:
                xLexerror("unfinished string", self.TK_EOS)
                continue 
            elif self.current == '\n':
                pass
            elif self.current == '\r':
                xLexerror("unfinished string", self.TK_STRING)
                continue 
            elif self.current == '\\':
                c = int()
                self.next()
                #  do not save the '\'
                if self.current == 'a':
                    c = 7
                elif self.current == 'b':
                    c = '\b'
                elif self.current == 'f':
                    c = '\f'
                elif self.current == 'n':
                    c = '\n'
                elif self.current == 'r':
                    c = '\r'
                elif self.current == 't':
                    c = '\t'
                elif self.current == 'v':
                    c = 11
                elif self.current == '\n':
                    pass
                elif self.current == '\r':
                    save('\n')
                    self.inclinenumber()
                    continue 
                elif self.current == self.EOZ:
                    continue 
                else:
                    #  will raise an error next loop
                    if not self.isdigit(self.current):
                        save_and_next()
                        #  handles \\, \", \', \?
                    else:
                        #  \xxx
                        i = 0
                        c = 0
                        while True:
                            c = 10 * c + (self.current - '0')
                            self.next()
                            if not ((i < 3 and self.isdigit(self.current))):
                                break
                        #  In unicode, there are no bounds on a 3-digit decimal.
                        save(c)
                    continue 
                save(c)
                self.next()
                continue 
            else:
                save_and_next()
        save_and_next()
        #  skip delimiter
        rawtoken = self.buff.__str__()
        self.semS = rawtoken.substring(1, 1 - len(rawtoken))

    @overloaded
    def save(self):
        """ generated source for method save """
        self.buff.append(str(self.current))

    @save.register(object, int)
    def save_0(self, c):
        """ generated source for method save_0 """
        self.buff.append(str(c))

    def save_and_next(self):
        """ generated source for method save_and_next """
        self.save()
        self.next()

    #  Getter for source. 
    def source(self):
        """ generated source for method source """
        return self.source

    def txtToken(self, tok):
        """ generated source for method txtToken """
        if tok == self.TK_NAME:
            pass
        elif tok == self.TK_STRING:
            pass
        elif tok == self.TK_NUMBER:
            return self.buff.__str__()
        else:
            return xToken2str(tok)

    #  Equivalent to <code>luaX_lexerror</code>. 
    def xLexerror(self, msg, tok):
        """ generated source for method xLexerror """
        msg = self.source + ":" + self.linenumber + ": " + msg
        if tok != 0:
            msg = msg + " near '" + self.txtToken(tok) + "'"
        self.L.pushString(msg)
        self.L.dThrow(Lua.ERRSYNTAX)

    #  Equivalent to <code>luaX_next</code>. 
    def xNext(self):
        """ generated source for method xNext """
        self.lastline = self.linenumber
        if self.lookahead != self.TK_EOS:
            #  is there a look-ahead token?
            self.token = self.lookahead
            #  Use this one,
            self.tokenR = self.lookaheadR
            self.tokenS = self.lookaheadS
            self.lookahead = self.TK_EOS
            #  and discharge it.
        else:
            self.token = self.llex()
            self.tokenR = self.semR
            self.tokenS = self.semS

    #  Equivalent to <code>luaX_syntaxerror</code>. 
    def xSyntaxerror(self, msg):
        """ generated source for method xSyntaxerror """
        self.xLexerror(msg, self.token)

    @classmethod
    def xToken2str(cls, token):
        """ generated source for method xToken2str """
        if token < cls.FIRST_RESERVED:
            #  assert token == (char)token;
            if cls.iscntrl(token):
                return "char(" + token + ")"
            return (Character(str(token))).__str__()
        return cls.tokens[token - cls.FIRST_RESERVED]

    #  From lparser.c
    @classmethod
    def block_follow(cls, token):
        """ generated source for method block_follow """
        if token == cls.TK_ELSE:
            pass
        elif token == cls.TK_ELSEIF:
            pass
        elif token == cls.TK_END:
            pass
        elif token == cls.TK_UNTIL:
            pass
        elif token == cls.TK_EOS:
            return True
        else:
            return False

    def check(self, c):
        """ generated source for method check """
        if self.token != c:
            error_expected(c)

    # 
    #    * @param what   the token that is intended to end the match.
    #    * @param who    the token that begins the match.
    #    * @param where  the line number of <var>what</var>.
    #    
    def check_match(self, what, who, where):
        """ generated source for method check_match """
        if not testnext(what):
            if where == self.linenumber:
                error_expected(what)
            else:
                self.xSyntaxerror("'" + self.xToken2str(what) + "' expected (to close '" + self.xToken2str(who) + "' at line " + where + ")")

    def close_func(self):
        """ generated source for method close_func """
        removevars(0)
        self.fs.kRet(0, 0)
        #  final return;
        self.fs.close()
        #  :todo: check this is a valid assertion to make
        # # assert fs != fs.prev
        self.fs = self.fs.prev

    @classmethod
    def opcode_name(cls, op):
        """ generated source for method opcode_name """
        if op == Lua.OP_MOVE:
            return "MOVE"
        elif op == Lua.OP_LOADK:
            return "LOADK"
        elif op == Lua.OP_LOADBOOL:
            return "LOADBOOL"
        elif op == Lua.OP_LOADNIL:
            return "LOADNIL"
        elif op == Lua.OP_GETUPVAL:
            return "GETUPVAL"
        elif op == Lua.OP_GETGLOBAL:
            return "GETGLOBAL"
        elif op == Lua.OP_GETTABLE:
            return "GETTABLE"
        elif op == Lua.OP_SETGLOBAL:
            return "SETGLOBAL"
        elif op == Lua.OP_SETUPVAL:
            return "SETUPVAL"
        elif op == Lua.OP_SETTABLE:
            return "SETTABLE"
        elif op == Lua.OP_NEWTABLE:
            return "NEWTABLE"
        elif op == Lua.OP_SELF:
            return "SELF"
        elif op == Lua.OP_ADD:
            return "ADD"
        elif op == Lua.OP_SUB:
            return "SUB"
        elif op == Lua.OP_MUL:
            return "MUL"
        elif op == Lua.OP_DIV:
            return "DIV"
        elif op == Lua.OP_MOD:
            return "MOD"
        elif op == Lua.OP_POW:
            return "POW"
        elif op == Lua.OP_UNM:
            return "UNM"
        elif op == Lua.OP_NOT:
            return "NOT"
        elif op == Lua.OP_LEN:
            return "LEN"
        elif op == Lua.OP_CONCAT:
            return "CONCAT"
        elif op == Lua.OP_JMP:
            return "JMP"
        elif op == Lua.OP_EQ:
            return "EQ"
        elif op == Lua.OP_LT:
            return "LT"
        elif op == Lua.OP_LE:
            return "LE"
        elif op == Lua.OP_TEST:
            return "TEST"
        elif op == Lua.OP_TESTSET:
            return "TESTSET"
        elif op == Lua.OP_CALL:
            return "CALL"
        elif op == Lua.OP_TAILCALL:
            return "TAILCALL"
        elif op == Lua.OP_RETURN:
            return "RETURN"
        elif op == Lua.OP_FORLOOP:
            return "FORLOOP"
        elif op == Lua.OP_FORPREP:
            return "FORPREP"
        elif op == Lua.OP_TFORLOOP:
            return "TFORLOOP"
        elif op == Lua.OP_SETLIST:
            return "SETLIST"
        elif op == Lua.OP_CLOSE:
            return "CLOSE"
        elif op == Lua.OP_CLOSURE:
            return "CLOSURE"
        elif op == Lua.OP_VARARG:
            return "VARARG"
        else:
            return "??" + op

    def codestring(self, e, s):
        """ generated source for method codestring """
        e.init(Expdesc.VK, self.fs.kStringK(s))

    def checkname(self, e):
        """ generated source for method checkname """
        self.codestring(e, str_checkname())

    def enterlevel(self):
        """ generated source for method enterlevel """
        self.L.nCcalls += 1

    def error_expected(self, tok):
        """ generated source for method error_expected """
        self.xSyntaxerror("'" + self.xToken2str(tok) + "' expected")

    def leavelevel(self):
        """ generated source for method leavelevel """
        self.L.nCcalls -= 1

    #  Equivalent to luaY_parser. 
    @classmethod
    def parser(cls, L, in_, name):
        """ generated source for method parser """
        ls = Syntax(L, in_, name)
        fs = FuncState(ls)
        ls.open_func(fs)
        fs.f.setIsVararg()
        ls.xNext()
        ls.chunk()
        ls.check(cls.TK_EOS)
        ls.close_func()
        # # assert fs.prev == null
        # # assert fs.f.nups == 0
        # # assert ls.fs == null
        return fs.f

    def removevars(self, tolevel):
        """ generated source for method removevars """
        #  :todo: consider making a method in FuncState.
        while self.fs.nactvar > tolevel:
            self.fs.nactvar -= 1
            self.fs.getlocvar(self.fs.nactvar).endpc = self.fs.pc

    def singlevar(self, var):
        """ generated source for method singlevar """
        varname = str_checkname()
        if singlevaraux(self.fs, varname, var, True) == Expdesc.VGLOBAL:
            var.setInfo(self.fs.kStringK(varname))

    def singlevaraux(self, f, n, var, base):
        """ generated source for method singlevaraux """
        if f == None:
            #  no more levels?
            var.init(Expdesc.VGLOBAL, Lua.NO_REG)
            #  default is global variable
            return Expdesc.VGLOBAL
        else:
            v = f.searchvar(n)
            if v >= 0:
                var.init(Expdesc.VLOCAL, v)
                if not base:
                    f.markupval(v)
                    #  local will be used as an upval
                return Expdesc.VLOCAL
            else:
                #  not found at current level; try upper one
                if self.singlevaraux(f.prev, n, var, False) == Expdesc.VGLOBAL:
                    return Expdesc.VGLOBAL
                var.upval(indexupvalue(f, n, var))
                #  else was LOCAL or UPVAL
                return Expdesc.VUPVAL

    def str_checkname(self):
        """ generated source for method str_checkname """
        self.check(self.TK_NAME)
        s = self.tokenS
        self.xNext()
        return s

    def testnext(self, c):
        """ generated source for method testnext """
        if self.token == c:
            self.xNext()
            return True
        return False

    #  GRAMMAR RULES
    def chunk(self):
        """ generated source for method chunk """
        #  chunk -> { stat [';'] }
        islast = False
        self.enterlevel()
        while not islast and not self.block_follow(self.token):
            islast = statement()
            self.testnext(';')
            # # assert fs.f.maxstacksize >= fs.freereg && fs.freereg >= fs.nactvar
            self.fs.freereg = self.fs.nactvar
        self.leavelevel()

    def constructor(self, t):
        """ generated source for method constructor """
        #  constructor -> ??
        line = self.linenumber
        pc = self.fs.kCodeABC(Lua.OP_NEWTABLE, 0, 0, 0)
        cc = ConsControl(t)
        t.init(Expdesc.VRELOCABLE, pc)
        cc.v.init(Expdesc.VVOID, 0)
        #  no value (yet) 
        self.fs.kExp2nextreg(t)
        #  fix it at stack top (for gc) 
        checknext('{')
        while True:
            # # assert cc.v.k == Expdesc.VVOID || cc.tostore > 0
            if self.token == '}':
                break
            closelistfield(cc)
            if self.token == self.TK_NAME:
                #  may be listfields or recfields 
                xLookahead()
                if self.lookahead != '=':
                    listfield(cc)
                else:
                    recfield(cc)
            elif self.token == '[':
                #  constructor_item -> recfield 
                recfield(cc)
            else:
                #  constructor_part -> listfield 
                listfield(cc)
            if not ((self.testnext(',') or self.testnext(';'))):
                break
        self.check_match('}', '{', line)
        lastlistfield(cc)
        code_ = self.fs.f.code_
        code_[pc] = Lua.SETARG_B(code_[pc], oInt2fb(cc.na))
        #  set initial array size 
        code_[pc] = Lua.SETARG_C(code_[pc], oInt2fb(cc.nh))
        #  set initial table size 

    @classmethod
    def oInt2fb(cls, x):
        """ generated source for method oInt2fb """
        e = 0
        #  exponent 
        while x < 0 or x >= 16:
            x = bsr((x + 1), 1)
            e += 1
        return x if (x < 8) else (((e + 1) << 3) | (x - 8))

    def recfield(self, cc):
        """ generated source for method recfield """
        #  recfield -> (NAME | `['exp1`]') = exp1 
        reg = self.fs.freereg
        key = Expdesc()
        val = Expdesc()
        if self.token == self.TK_NAME:
            #  yChecklimit(fs, cc.nh, MAX_INT, "items in a constructor");
            self.checkname(key)
        else:
            yindex(key)
        cc.nh += 1
        checknext('=')
        self.fs.kExp2RK(key)
        expr(val)
        self.fs.kCodeABC(Lua.OP_SETTABLE, cc.t.info, self.fs.kExp2RK(key), self.fs.kExp2RK(val))
        self.fs.freereg = reg
        #  free registers 

    def lastlistfield(self, cc):
        """ generated source for method lastlistfield """
        if cc.tostore == 0:
            return
        if hasmultret(cc.v.k):
            self.fs.kSetmultret(cc.v)
            self.fs.kSetlist(cc.t.info, cc.na, Lua.MULTRET)
            cc.na -= 1
            #  do not count last expression (unknown number of elements) 
        else:
            if cc.v.k != Expdesc.VVOID:
                self.fs.kExp2nextreg(cc.v)
            self.fs.kSetlist(cc.t.info, cc.na, cc.tostore)

    def closelistfield(self, cc):
        """ generated source for method closelistfield """
        if cc.v.k == Expdesc.VVOID:
            return
        #  there is no list item 
        self.fs.kExp2nextreg(cc.v)
        cc.v.k = Expdesc.VVOID
        if cc.tostore == Lua.LFIELDS_PER_FLUSH:
            self.fs.kSetlist(cc.t.info, cc.na, cc.tostore)
            #  flush 
            cc.tostore = 0
            #  no more items pending 

    def expr(self, v):
        """ generated source for method expr """
        subexpr(v, 0)

    #  @return number of expressions in expression list. 
    def explist1(self, v):
        """ generated source for method explist1 """
        #  explist1 -> expr { ',' expr }
        n = 1
        #  at least one expression
        self.expr(v)
        while self.testnext(','):
            self.fs.kExp2nextreg(v)
            self.expr(v)
            n += 1
        return n

    def exprstat(self):
        """ generated source for method exprstat """
        #  stat -> func | assignment
        v = LHSAssign()
        primaryexp(v.v)
        if v.v.k == Expdesc.VCALL:
            #  stat -> func
            self.fs.setargc(v.v, 1)
            #  call statement uses no results
        else:
            #  stat -> assignment
            v.prev = None
            assignment(v, 1)

    # 
    #   ** check whether, in an assignment to a local variable, the local variable
    #   ** is needed in a previous assignment (to a table). If so, save original
    #   ** local value in a safe place and use this safe copy in the previous
    #   ** assignment.
    #   
    def check_conflict(self, lh, v):
        """ generated source for method check_conflict """
        extra = self.fs.freereg
        #  eventual position to save local variable 
        conflict = False
        while lh != None:
            if lh.v.k == Expdesc.VINDEXED:
                if lh.v.info == v.info:
                    #  conflict? 
                    conflict = True
                    lh.v.info = extra
                    #  previous assignment will use safe copy 
                if lh.v.aux == v.info:
                    #  conflict? 
                    conflict = True
                    lh.v.aux = extra
                    #  previous assignment will use safe copy 
            lh = lh.prev
        if conflict:
            self.fs.kCodeABC(Lua.OP_MOVE, self.fs.freereg, v.info, 0)
            #  make copy 
            self.fs.kReserveregs(1)

    def assignment(self, lh, nvars):
        """ generated source for method assignment """
        e = Expdesc()
        kind = lh.v.k
        if not (Expdesc.VLOCAL <= kind and kind <= Expdesc.VINDEXED):
            self.xSyntaxerror("syntax error")
        if self.testnext(','):
            #  assignment -> `,' primaryexp assignment 
            nv = LHSAssign(lh)
            primaryexp(nv.v)
            if nv.v.k == Expdesc.VLOCAL:
                self.check_conflict(lh, nv.v)
            self.assignment(nv, nvars + 1)
        else:
            #  assignment -> `=' explist1 
            nexps = int()
            checknext('=')
            nexps = self.explist1(e)
            if nexps != nvars:
                adjust_assign(nvars, nexps, e)
                if nexps > nvars:
                    self.fs.freereg -= nexps - nvars
                #  remove extra values 
            else:
                self.fs.kSetoneret(e)
                #  close last expression 
                self.fs.kStorevar(lh.v, e)
                return
                #  avoid default 
        e.init(Expdesc.VNONRELOC, self.fs.freereg - 1)
        #  default assignment 
        self.fs.kStorevar(lh.v, e)

    def funcargs(self, f):
        """ generated source for method funcargs """
        args = Expdesc()
        line = self.linenumber
        if self.token == '(':
            #  funcargs -> '(' [ explist1 ] ')'
            if line != self.lastline:
                self.xSyntaxerror("ambiguous syntax (function call x new statement)")
            self.xNext()
            if self.token == ')':
                #  arg list is empty?
                args.setKind(Expdesc.VVOID)
            else:
                self.explist1(args)
                self.fs.kSetmultret(args)
            self.check_match(')', '(', line)
        elif self.token == '{':
            #  funcargs -> constructor
            self.constructor(args)
        elif self.token == self.TK_STRING:
            #  funcargs -> STRING
            self.codestring(args, self.tokenS)
            self.xNext()
            #  must use tokenS before 'next'
        else:
            self.xSyntaxerror("function arguments expected")
            return
        #  assert (f.kind() == VNONRELOC);
        nparams = int()
        base = f.info()
        #  base register for call
        if args.hasmultret():
            nparams = Lua.MULTRET
            #  open call
        else:
            if args.kind() != Expdesc.VVOID:
                self.fs.kExp2nextreg(args)
                #  close last argument
            nparams = self.fs.freereg - (base + 1)
        f.init(Expdesc.VCALL, self.fs.kCodeABC(Lua.OP_CALL, base, nparams + 1, 2))
        self.fs.kFixline(line)
        self.fs.freereg = base + 1
        #  call removes functions and arguments
        #  and leaves (unless changed) one result.

    def prefixexp(self, v):
        """ generated source for method prefixexp """
        #  prefixexp -> NAME | '(' expr ')'
        if self.token == '(':
            line = self.linenumber
            self.xNext()
            self.expr(v)
            self.check_match(')', '(', line)
            self.fs.kDischargevars(v)
            return
        elif self.token == self.TK_NAME:
            self.singlevar(v)
            return
        else:
            self.xSyntaxerror("unexpected symbol")
            return

    def primaryexp(self, v):
        """ generated source for method primaryexp """
        #  primaryexp ->
        #     prefixexp { '.' NAME | '[' exp ']' | ':' NAME funcargs | funcargs }
        self.prefixexp(v)
        while True:
            if self.token == '.':
                #  field 
                field(v)
            elif self.token == '[':
                #  `[' exp1 `]' 
                key = Expdesc()
                self.fs.kExp2anyreg(v)
                yindex(key)
                self.fs.kIndexed(v, key)
            elif self.token == ':':
                #  `:' NAME funcargs 
                key = Expdesc()
                self.xNext()
                self.checkname(key)
                self.fs.kSelf(v, key)
                self.funcargs(v)
            elif self.token == '(':
                pass
            elif self.token == self.TK_STRING:
                pass
            elif self.token == '{':
                #  funcargs
                self.fs.kExp2nextreg(v)
                self.funcargs(v)
            else:
                return

    def retstat(self):
        """ generated source for method retstat """
        #  stat -> RETURN explist
        self.xNext()
        #  skip RETURN
        #  registers with returned values (first, nret)
        first = 0
        nret = int()
        if self.block_follow(self.token) or self.token == ';':
            #  return no values
            first = 0
            nret = 0
        else:
            e = Expdesc()
            nret = self.explist1(e)
            if hasmultret(e.k):
                self.fs.kSetmultret(e)
                if e.k == Expdesc.VCALL and nret == 1:
                    #  tail call? 
                    self.fs.setcode(e, Lua.SET_OPCODE(self.fs.getcode(e), Lua.OP_TAILCALL))
                    # # assert Lua.ARGA(fs.getcode(e)) == fs.nactvar
                first = self.fs.nactvar
                nret = Lua.MULTRET
                #  return all values 
            else:
                if nret == 1:
                    #  only one single value?
                    first = self.fs.kExp2anyreg(e)
                else:
                    self.fs.kExp2nextreg(e)
                    #  values must go to the `stack' 
                    first = self.fs.nactvar
                    #  return all `active' values 
                    # # assert nret == fs.freereg - first
        self.fs.kRet(first, nret)

    def simpleexp(self, v):
        """ generated source for method simpleexp """
        #  simpleexp -> NUMBER | STRING | NIL | true | false | ... |
        #               constructor | FUNCTION body | primaryexp
        if self.token == self.TK_NUMBER:
            v.init(Expdesc.VKNUM, 0)
            v.nval = self.tokenR
        elif self.token == self.TK_STRING:
            self.codestring(v, self.tokenS)
        elif self.token == self.TK_NIL:
            v.init(Expdesc.VNIL, 0)
        elif self.token == self.TK_TRUE:
            v.init(Expdesc.VTRUE, 0)
        elif self.token == self.TK_FALSE:
            v.init(Expdesc.VFALSE, 0)
        elif self.token == self.TK_DOTS:
            #  vararg 
            if not self.fs.f.isVararg():
                self.xSyntaxerror("cannot use \"...\" outside a vararg function")
            v.init(Expdesc.VVARARG, self.fs.kCodeABC(Lua.OP_VARARG, 0, 1, 0))
        elif self.token == '{':
            #  constructor 
            self.constructor(v)
            return
        elif self.token == self.TK_FUNCTION:
            self.xNext()
            body(v, False, self.linenumber)
            return
        else:
            self.primaryexp(v)
            return
        self.xNext()

    def statement(self):
        """ generated source for method statement """
        line = self.linenumber
        if self.token == self.TK_IF:
            #  stat -> ifstat
            ifstat(line)
            return False
        elif self.token == self.TK_WHILE:
            #  stat -> whilestat
            whilestat(line)
            return False
        elif self.token == self.TK_DO:
            #  stat -> DO block END
            self.xNext()
            #  skip DO
            block()
            self.check_match(self.TK_END, self.TK_DO, line)
            return False
        elif self.token == self.TK_FOR:
            #  stat -> forstat
            forstat(line)
            return False
        elif self.token == self.TK_REPEAT:
            #  stat -> repeatstat
            repeatstat(line)
            return False
        elif self.token == self.TK_FUNCTION:
            funcstat(line)
            #  stat -> funcstat
            return False
        elif self.token == self.TK_LOCAL:
            #  stat -> localstat
            self.xNext()
            #  skip LOCAL
            if self.testnext(self.TK_FUNCTION):
                localfunc()
            else:
                localstat()
            return False
        elif self.token == self.TK_RETURN:
            self.retstat()
            return True
        elif self.token == self.TK_BREAK:
            #  stat -> breakstat
            self.xNext()
            #  skip BREAK
            breakstat()
            return True
        else:
            #  must be last statement
            self.exprstat()
            return False

    #  grep "ORDER OPR" if you change these enums.
    #  default access so that FuncState can access them.
    OPR_ADD = 0
    OPR_SUB = 1
    OPR_MUL = 2
    OPR_DIV = 3
    OPR_MOD = 4
    OPR_POW = 5
    OPR_CONCAT = 6
    OPR_NE = 7
    OPR_EQ = 8
    OPR_LT = 9
    OPR_LE = 10
    OPR_GT = 11
    OPR_GE = 12
    OPR_AND = 13
    OPR_OR = 14
    OPR_NOBINOPR = 15
    OPR_MINUS = 0
    OPR_NOT = 1
    OPR_LEN = 2
    OPR_NOUNOPR = 3

    #  Converts token into binary operator.  
    @classmethod
    def getbinopr(cls, op):
        """ generated source for method getbinopr """
        if op == '+':
            return cls.OPR_ADD
        elif op == '-':
            return cls.OPR_SUB
        elif op == '*':
            return cls.OPR_MUL
        elif op == '/':
            return cls.OPR_DIV
        elif op == '%':
            return cls.OPR_MOD
        elif op == '^':
            return cls.OPR_POW
        elif op == cls.TK_CONCAT:
            return cls.OPR_CONCAT
        elif op == cls.TK_NE:
            return cls.OPR_NE
        elif op == cls.TK_EQ:
            return cls.OPR_EQ
        elif op == '<':
            return cls.OPR_LT
        elif op == cls.TK_LE:
            return cls.OPR_LE
        elif op == '>':
            return cls.OPR_GT
        elif op == cls.TK_GE:
            return cls.OPR_GE
        elif op == cls.TK_AND:
            return cls.OPR_AND
        elif op == cls.TK_OR:
            return cls.OPR_OR
        else:
            return cls.OPR_NOBINOPR

    @classmethod
    def getunopr(cls, op):
        """ generated source for method getunopr """
        if op == cls.TK_NOT:
            return cls.OPR_NOT
        elif op == '-':
            return cls.OPR_MINUS
        elif op == '#':
            return cls.OPR_LEN
        else:
            return cls.OPR_NOUNOPR

    #  ORDER OPR
    # 
    #    * Priority table.  left-priority of an operator is
    #    * <code>priority[op][0]</code>, its right priority is
    #    * <code>priority[op][1]</code>.  Please do not modify this table.
    #    
    PRIORITY = [None] * 

    #  Priority for unary operators. 
    UNARY_PRIORITY = 8

    # 
    #    * Operator precedence parser.
    #    * <code>subexpr -> (simpleexp) | unop subexpr) { binop subexpr }</code>
    #    * where <var>binop</var> is any binary operator with a priority
    #    * higher than <var>limit</var>.
    #    
    def subexpr(self, v, limit):
        """ generated source for method subexpr """
        self.enterlevel()
        uop = self.getunopr(self.token)
        if uop != self.OPR_NOUNOPR:
            self.xNext()
            self.subexpr(v, self.UNARY_PRIORITY)
            self.fs.kPrefix(uop, v)
        else:
            self.simpleexp(v)
        #  expand while operators have priorities higher than 'limit'
        op = self.getbinopr(self.token)
        while op != self.OPR_NOBINOPR and self.PRIORITY[op][0] > limit:
            v2 = Expdesc()
            self.xNext()
            self.fs.kInfix(op, v)
            nextop = self.subexpr(v2, self.PRIORITY[op][1])
            self.fs.kPosfix(op, v, v2)
            op = nextop
        self.leavelevel()
        return op

    def enterblock(self, f, bl, isbreakable):
        """ generated source for method enterblock """
        bl.breaklist = FuncState.NO_JUMP
        bl.isbreakable = isbreakable
        bl.nactvar = f.nactvar
        bl.upval = False
        bl.previous = f.bl
        f.bl = bl

    def leaveblock(self, f):
        """ generated source for method leaveblock """
        bl = f.bl
        f.bl = bl.previous
        self.removevars(bl.nactvar)
        if bl.upval:
            f.kCodeABC(Lua.OP_CLOSE, bl.nactvar, 0, 0)
        f.freereg = f.nactvar
        f.kPatchtohere(bl.breaklist)

    def block(self):
        """ generated source for method block """
        bl = BlockCnt()
        self.enterblock(self.fs, bl, False)
        self.chunk()
        self.leaveblock(self.fs)

    def breakstat(self):
        """ generated source for method breakstat """
        bl = self.fs.bl
        upval = False
        while bl != None and not bl.isbreakable:
            upval |= bl.upval
            bl = bl.previous
        if bl == None:
            self.xSyntaxerror("no loop to break")
        if upval:
            self.fs.kCodeABC(Lua.OP_CLOSE, bl.nactvar, 0, 0)
        bl.breaklist = self.fs.kConcat(bl.breaklist, self.fs.kJump())

    def funcstat(self, line):
        """ generated source for method funcstat """
        b = Expdesc()
        v = Expdesc()
        self.xNext()
        needself = funcname(v)
        body(b, needself, line)
        self.fs.kStorevar(v, b)
        self.fs.kFixline(line)

    def checknext(self, c):
        """ generated source for method checknext """
        self.check(c)
        self.xNext()

    def parlist(self):
        """ generated source for method parlist """
        f = self.fs.f
        nparams = 0
        if self.token != ')':
        __nparams_2 = nparams
        nparams += 1
            while True:
                if self.token == self.TK_NAME:
                    new_localvar(self.str_checkname(), __nparams_2)
                elif self.token == self.TK_DOTS:
                    self.xNext()
                    f.setIsVararg()
                else:
                    self.xSyntaxerror("<name> or '...' expected")
                if not (((not f.isVararg()) and self.testnext(','))):
                    break
        adjustlocalvars(nparams)
        f.numparams = self.fs.nactvar
        self.fs.kReserveregs(self.fs.nactvar)

    def getlocvar(self, i):
        """ generated source for method getlocvar """
        fstate = self.fs
        return fstate.f.locvars[fstate.actvar[i]]

    def adjustlocalvars(self, nvars):
        """ generated source for method adjustlocalvars """
        self.fs.nactvar += nvars
        while nvars != 0:
            self.getlocvar(self.fs.nactvar - nvars).startpc = self.fs.pc
            nvars -= 1

    def new_localvarliteral(self, v, n):
        """ generated source for method new_localvarliteral """
        new_localvar(v, n)

    def errorlimit(self, limit, what):
        """ generated source for method errorlimit """
        msg = "main function has more than " + limit + " " + what if self.fs.f.linedefined == 0 else "function at line " + self.fs.f.linedefined + " has more than " + limit + " " + what
        self.xLexerror(msg, 0)

    def yChecklimit(self, v, l, m):
        """ generated source for method yChecklimit """
        if v > l:
            self.errorlimit(l, m)

    def new_localvar(self, name, n):
        """ generated source for method new_localvar """
        self.yChecklimit(self.fs.nactvar + n + 1, Lua.MAXVARS, "local variables")
        self.fs.actvar[self.fs.nactvar + n] = int(registerlocalvar(name))

    def registerlocalvar(self, varname):
        """ generated source for method registerlocalvar """
        f = self.fs.f
        f.ensureLocvars(self.L, self.fs.nlocvars, Short.MAX_VALUE)
        f.locvars[self.fs.nlocvars].varname = varname
        return self.fs.nlocvars += 1

    def body(self, e, needself, line):
        """ generated source for method body """
        new_fs = FuncState(self)
        open_func(new_fs)
        new_fs.f.linedefined = line
        self.checknext('(')
        if needself:
            self.new_localvarliteral("self", 0)
            self.adjustlocalvars(1)
        self.parlist()
        self.checknext(')')
        self.chunk()
        new_fs.f.lastlinedefined = self.linenumber
        self.check_match(self.TK_END, self.TK_FUNCTION, line)
        self.close_func()
        pushclosure(new_fs, e)

    def UPVAL_K(self, upvaldesc):
        """ generated source for method UPVAL_K """
        return (bsr(upvaldesc, 8)) & 0xFF

    def UPVAL_INFO(self, upvaldesc):
        """ generated source for method UPVAL_INFO """
        return upvaldesc & 0xFF

    def UPVAL_ENCODE(self, k, info):
        """ generated source for method UPVAL_ENCODE """
        return ((k & 0xFF) << 8) | (info & 0xFF)

    def pushclosure(self, func, v):
        """ generated source for method pushclosure """
        f = self.fs.f
        f.ensureProtos(self.L, self.fs.np)
        ff = func.f
        f.p[self.fs.np] = ff
        self.fs.np += 1
        v.init(Expdesc.VRELOCABLE, self.fs.kCodeABx(Lua.OP_CLOSURE, 0, self.fs.np - 1))
        i = 0
        while i < ff.nups:
            upvalue = func.upvalues[i]
            o = Lua.OP_MOVE if (self.UPVAL_K(upvalue) == Expdesc.VLOCAL) else Lua.OP_GETUPVAL
            self.fs.kCodeABC(o, 0, self.UPVAL_INFO(upvalue), 0)
            i += 1

    def funcname(self, v):
        """ generated source for method funcname """
        needself = False
        self.singlevar(v)
        while self.token == '.':
        if self.token == ':':
            needself = True
            field(v)
        return needself

    def field(self, v):
        """ generated source for method field """
        key = Expdesc()
        self.fs.kExp2anyreg(v)
        self.xNext()
        self.checkname(key)
        self.fs.kIndexed(v, key)

    def repeatstat(self, line):
        """ generated source for method repeatstat """
        repeat_init = self.fs.kGetlabel()
        bl1 = BlockCnt()
        bl2 = BlockCnt()
        self.enterblock(self.fs, bl1, True)
        self.enterblock(self.fs, bl2, False)
        self.xNext()
        self.chunk()
        self.check_match(self.TK_UNTIL, self.TK_REPEAT, line)
        condexit = cond()
        if not bl2.upval:
            self.leaveblock(self.fs)
            self.fs.kPatchlist(condexit, repeat_init)
        else:
            self.breakstat()
            self.fs.kPatchtohere(condexit)
            self.leaveblock(self.fs)
            self.fs.kPatchlist(self.fs.kJump(), repeat_init)
        self.leaveblock(self.fs)

    def cond(self):
        """ generated source for method cond """
        v = Expdesc()
        self.expr(v)
        if v.k == Expdesc.VNIL:
            v.k = Expdesc.VFALSE
        self.fs.kGoiftrue(v)
        return v.f

    def open_func(self, funcstate):
        """ generated source for method open_func """
        f = Proto(self.source, 2)
        funcstate.f = f
        funcstate.ls = self
        funcstate.L = self.L
        funcstate.prev = self.fs
        self.fs = funcstate

    def localstat(self):
        """ generated source for method localstat """
        nvars = 0
        nexps = int()
        e = Expdesc()
        __nvars_3 = nvars
        nvars += 1
        while True:
            self.new_localvar(self.str_checkname(), __nvars_3)
            if not ((self.testnext(','))):
                break
        if self.testnext('='):
            nexps = self.explist1(e)
        else:
            e.k = Expdesc.VVOID
            nexps = 0
        adjust_assign(nvars, nexps, e)
        self.adjustlocalvars(nvars)

    def forstat(self, line):
        """ generated source for method forstat """
        bl = BlockCnt()
        self.enterblock(self.fs, bl, True)
        self.xNext()
        varname = self.str_checkname()
        if self.token == '=':
            fornum(varname, line)
        elif self.token == ',':
            pass
        elif self.token == self.TK_IN:
            forlist(varname)
        else:
            self.xSyntaxerror("\"=\" or \"in\" expected")
        self.check_match(self.TK_END, self.TK_FOR, line)
        self.leaveblock(self.fs)

    def fornum(self, varname, line):
        """ generated source for method fornum """
        base = self.fs.freereg
        self.new_localvarliteral("(for index)", 0)
        self.new_localvarliteral("(for limit)", 1)
        self.new_localvarliteral("(for step)", 2)
        self.new_localvar(varname, 3)
        self.checknext('=')
        exp1()
        self.checknext(',')
        exp1()
        if self.testnext(','):
            exp1()
        else:
            self.fs.kCodeABx(Lua.OP_LOADK, self.fs.freereg, self.fs.kNumberK(1))
            self.fs.kReserveregs(1)
        forbody(base, line, 1, True)

    def exp1(self):
        """ generated source for method exp1 """
        e = Expdesc()
        self.expr(e)
        k = e.k
        self.fs.kExp2nextreg(e)
        return k

    def forlist(self, indexname):
        """ generated source for method forlist """
        e = Expdesc()
        nvars = 0
        base = self.fs.freereg
        __nvars_4 = nvars
        nvars += 1
        self.new_localvarliteral("(for generator)", __nvars_4)
        __nvars_5 = nvars
        nvars += 1
        self.new_localvarliteral("(for state)", __nvars_5)
        __nvars_6 = nvars
        nvars += 1
        self.new_localvarliteral("(for control)", __nvars_6)
        __nvars_7 = nvars
        nvars += 1
        self.new_localvar(indexname, __nvars_7)
        while self.testnext(','):
        self.checknext(self.TK_IN)
        line = self.linenumber
        adjust_assign(3, self.explist1(e), e)
        self.fs.kCheckstack(3)
        forbody(base, line, nvars - 3, False)

    def forbody(self, base, line, nvars, isnum):
        """ generated source for method forbody """
        bl = BlockCnt()
        self.adjustlocalvars(3)
        self.checknext(self.TK_DO)
        prep = self.fs.kCodeAsBx(Lua.OP_FORPREP, base, FuncState.NO_JUMP) if isnum else self.fs.kJump()
        self.enterblock(self.fs, bl, False)
        self.adjustlocalvars(nvars)
        self.fs.kReserveregs(nvars)
        self.block()
        self.leaveblock(self.fs)
        self.fs.kPatchtohere(prep)
        endfor = self.fs.kCodeAsBx(Lua.OP_FORLOOP, base, FuncState.NO_JUMP) if isnum else self.fs.kCodeABC(Lua.OP_TFORLOOP, base, 0, nvars)
        self.fs.kFixline(line)
        self.fs.kPatchlist((endfor if isnum else self.fs.kJump()), prep + 1)

    def ifstat(self, line):
        """ generated source for method ifstat """
        escapelist = FuncState.NO_JUMP
        flist = test_then_block()
        while self.token == self.TK_ELSEIF:
            escapelist = self.fs.kConcat(escapelist, self.fs.kJump())
            self.fs.kPatchtohere(flist)
            flist = test_then_block()
        if self.token == self.TK_ELSE:
            escapelist = self.fs.kConcat(escapelist, self.fs.kJump())
            self.fs.kPatchtohere(flist)
            self.xNext()
            self.block()
        else:
            escapelist = self.fs.kConcat(escapelist, flist)
        self.fs.kPatchtohere(escapelist)
        self.check_match(self.TK_END, self.TK_IF, line)

    def test_then_block(self):
        """ generated source for method test_then_block """
        self.xNext()
        condexit = self.cond()
        self.checknext(self.TK_THEN)
        self.block()
        return condexit

    def whilestat(self, line):
        """ generated source for method whilestat """
        bl = BlockCnt()
        self.xNext()
        whileinit = self.fs.kGetlabel()
        condexit = self.cond()
        self.enterblock(self.fs, bl, True)
        self.checknext(self.TK_DO)
        self.block()
        self.fs.kPatchlist(self.fs.kJump(), whileinit)
        self.check_match(self.TK_END, self.TK_WHILE, line)
        self.leaveblock(self.fs)
        self.fs.kPatchtohere(condexit)

    @classmethod
    def hasmultret(cls, k):
        """ generated source for method hasmultret """
        return k == Expdesc.VCALL or k == Expdesc.VVARARG

    def adjust_assign(self, nvars, nexps, e):
        """ generated source for method adjust_assign """
        extra = nvars - nexps
        if self.hasmultret(e.k):
            extra += 1
            if extra < 0:
                extra = 0
            self.fs.kSetreturns(e, extra)
            if extra > 1:
                self.fs.kReserveregs(extra - 1)
        else:
            if e.k != Expdesc.VVOID:
                self.fs.kExp2nextreg(e)
            if extra > 0:
                reg = self.fs.freereg
                self.fs.kReserveregs(extra)
                self.fs.kNil(reg, extra)

    def localfunc(self):
        """ generated source for method localfunc """
        b = Expdesc()
        self.new_localvar(self.str_checkname(), 0)
        v = Expdesc(Expdesc.VLOCAL, self.fs.freereg)
        self.fs.kReserveregs(1)
        self.adjustlocalvars(1)
        self.body(b, False, self.linenumber)
        self.fs.kStorevar(v, b)
        self.fs.getlocvar(self.fs.nactvar - 1).startpc = self.fs.pc

    def yindex(self, v):
        """ generated source for method yindex """
        self.xNext()
        self.expr(v)
        self.fs.kExp2val(v)
        self.checknext(']')

    def xLookahead(self):
        """ generated source for method xLookahead """
        self.lookahead = self.llex()
        self.lookaheadR = self.semR
        self.lookaheadS = self.semS

    def listfield(self, cc):
        """ generated source for method listfield """
        self.expr(cc.v)
        self.yChecklimit(cc.na, Lua.MAXARG_Bx, "items in a constructor")
        cc.na += 1
        cc.tostore += 1

    def indexupvalue(self, funcstate, name, v):
        """ generated source for method indexupvalue """
        f = funcstate.f
        oldsize = f.sizeupvalues
        i = 0
        while i < f.nups:
            entry = funcstate.upvalues[i]
            if self.UPVAL_K(entry) == v.k and self.UPVAL_INFO(entry) == v.info:
                return i
            i += 1
        self.yChecklimit(f.nups + 1, Lua.MAXUPVALUES, "upvalues")
        f.ensureUpvals(self.L, f.nups)
        f.upvalues[f.nups] = name
        funcstate.upvalues[f.nups] = self.UPVAL_ENCODE(v.k, v.info)
        return f.nups += 1


class LHSAssign(object):
    """ generated source for class LHSAssign """
    prev = None
    v = Expdesc()

    @overloaded
    def __init__(self):
        """ generated source for method __init__ """

    @__init__.register(object, LHSAssign)
    def __init___0(self, prev):
        """ generated source for method __init___0 """
        self.prev = prev


class ConsControl(object):
    """ generated source for class ConsControl """
    v = Expdesc()
    t = None
    nh = int()
    na = int()
    tostore = int()

    def __init__(self, t):
        """ generated source for method __init__ """
        self.t = t

