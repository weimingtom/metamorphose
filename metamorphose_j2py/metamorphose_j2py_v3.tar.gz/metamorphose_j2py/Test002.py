#!/usr/bin/env python
""" generated source for module Test002 """
from __future__ import print_function
# package: com.iteye.weimingtom.metamorphose.test
class Test002(object):
    """ generated source for class Test002 """
    _bisectClass = "assets/accept-basic/bisect.lua"
    _cfClass = "assets/accept-basic/cf.lua"
    _echoClass = "assets/accept-basic/echo.lua"

    # miss
    _envClass = "assets/accept-basic/env.lua"
    _factorialClass = "assets/accept-basic/factorial.lua"
    _fibClass = "assets/accept-basic/fib.lua"
    _fibforClass = "assets/accept-basic/fibfor.lua"
    _globalsClass = "assets/accept-basic/globals.lua"

    # miss
    _helloClass = "assets/accept-basic/hello.lua"

    # miss
    _lifeClass = "assets/accept-basic/life.lua"
    _luacClass = "assets/accept-basic/luac.lua"

    # miss
    _printfClass = "assets/accept-basic/printf.lua"
    _readonlyClass = "assets/accept-basic/readonly.lua"
    _sieveClass = "assets/accept-basic/sieve.lua"
    _sortClass = "assets/accept-basic/sort.lua"
    _tableClass = "assets/accept-basic/table.lua"

    # miss
    _traceCallsClass = "assets/accept-basic/trace-calls.lua"

    # miss
    _traceGlobalsClass = "assets/accept-basic/trace-globals.lua"

    # miss
    _xdClass = "assets/accept-basic/xd.lua"

    # miss
    class LuaFile(object):
        """ generated source for class LuaFile """
        test = bool()
        label = None
        asset = None
        code_ = None
        filename = None

        @overloaded
        def __init__(self):
            """ generated source for method __init__ """

        @__init__.register(object, bool, str, str)
        def __init___0(self, test, label, asset):
            """ generated source for method __init___0 """
            self.test = test
            self.label = label
            self.asset = asset

        @__init__.register(object, str, str)
        def __init___1(self, label, asset):
            """ generated source for method __init___1 """
            self.__init__(False, label, asset)

    _embeddedLuaFiles = [LuaFile(False, "Bisection method for solving non-linear equations", _bisectClass), LuaFile(False, "Temperature conversion table (celsius to farenheit)", _cfClass), LuaFile(False, "Echo command line arguments", _echoClass), LuaFile(False, "Environment variables as automatic global variables", _envClass), LuaFile(False, "Factorial without recursion", _factorialClass), LuaFile(False, "Fibonacci function with cache", _fibClass), LuaFile(False, "Fibonacci numbers with coroutines and generators", _fibforClass), LuaFile("Report global variable usage", _globalsClass), LuaFile(True, "The first program in every language", _helloClass), LuaFile("Conway's Game of Life", _lifeClass), LuaFile("Bare-bones luac", _luacClass), LuaFile("An implementation of printf", _printfClass), LuaFile("The sieve of of Eratosthenes programmed with coroutines", _readonlyClass), LuaFile("Make global variables readonly", _sieveClass), LuaFile("Two implementations of a sort function", _sortClass), LuaFile("Make table, grouping all data for the same item", _tableClass), LuaFile("Trace calls", _traceCallsClass), LuaFile("Trace assigments to global variables", _traceGlobalsClass), LuaFile("Hex dump", _xdClass)]

    # miss
    @classmethod
    def main(cls, args):
        """ generated source for method main """
        print("Start test...")
        code_ = ArrayList()
        for luaFile in _embeddedLuaFiles:
            luaString = clsToUTF8(luaFile.asset)
            item = cls.LuaFile()
            item.test = luaFile.test
            item.label = luaFile.label
            item.code_ = luaString
            item.filename = luaFile.asset
            code_.add(item)
        i = 0
        while i < len(code_):
            if code_.get(i).test:
                print(code_.get(i).label)
                runScript(code_.get(i).code_, code_.get(i).filename)
            i += 1

    @classmethod
    def runScript(cls, code_, filename):
        """ generated source for method runScript """
        isLoadLib = True
        useArg = True
        argv = [None] * 
        try:
            L = Lua()
            if isLoadLib:
                BaseLib.open(L)
                PackageLib.open(L)
                MathLib.open(L)
                OSLib.open(L)
                StringLib.open(L)
                TableLib.open(L)
                IOLib.open(L)
            if useArg:
                # FIXME: index may be minus (for example, arg[-1], before script file name)
                # @see http://www.ttlsa.com/lua/lua-install-and-lua-variable-ttlsa/
                narg = int()
                tbl = L.createTable(narg, narg)
                L.rawSetI(tbl, 0, filename)
                i = 0
                while i < narg:
                    L.rawSetI(tbl, i, argv[i])
                    i += 1
                L.setGlobal("arg", tbl)
            status = L.doString(code_)
            if status != 0:
                errObj = L.value(1)
                tostring = L.getGlobal("tostring")
                L.push(tostring)
                L.push(errObj)
                L.call(1, 1)
                errObjStr = L.toString(L.value(-1))
                raise Exception("Error compiling : " + errObjStr)
            else:
                result = L.value(1)
                tostring_ = L.getGlobal("tostring")
                L.push(tostring_)
                L.push(result)
                L.call(1, 1)
                resultStr = L.toString(L.value(-1))
                System.err.println("Result >>> " + resultStr)
        except Exception as e:
            e.printStackTrace()

    @classmethod
    def clsToUTF8(cls, filename):
        """ generated source for method clsToUTF8 """
        sb = StringBuffer()
        instr = None
        reader = None
        buffer_ = None
        try:
            instr = FileInputStream(filename)
            reader = InputStreamReader(instr, "UTF-8")
            buffer_ = BufferedReader(reader)
            line = None
            while None != (line = buffer_.readLine()):
                sb.append(line)
                sb.append("\n")
        except IOError as e:
            e.printStackTrace()
        finally:
            if buffer_ != None:
                try:
                    buffer_.close()
                except IOError as e:
                    e.printStackTrace()
            if reader != None:
                try:
                    reader.close()
                except IOError as e:
                    e.printStackTrace()
            if instr != None:
                try:
                    instr.close()
                except IOError as e:
                    e.printStackTrace()
        return sb.__str__()


if __name__ == '__main__':
    import sys
    Test002.main(sys.argv)

