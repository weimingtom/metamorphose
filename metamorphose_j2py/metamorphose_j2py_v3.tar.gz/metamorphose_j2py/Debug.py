#!/usr/bin/env python
""" generated source for module Debug """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Debug.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Equivalent to struct lua_Debug.  This implementation is incomplete
#  * because it is not intended to form part of the public API.  It has
#  * only been implemented to the extent necessary for internal use.
#  
class Debug(object):
    """ generated source for class Debug """
    #  private, no public accessors defined.
    ici = int()

    #  public accessors may be defined for these.
    event = int()
    what = None
    source = None
    currentline = int()
    linedefined = int()
    lastlinedefined = int()
    shortsrc = None

    # 
    #    * @param ici  index of CallInfo record in L.civ
    #    
    def __init__(self, ici):
        """ generated source for method __init__ """
        self.ici = ici

    # 
    #    * Get ici, index of the {@link CallInfo} record.
    #    
    def ici(self):
        """ generated source for method ici """
        return self.ici

    # 
    #    * Setter for event.
    #    
    def setEvent(self, event):
        """ generated source for method setEvent """
        self.event = event

    def what(self):
        """ generated source for method what """
        return self.what

    # 
    #    * Sets the what field.
    #    
    def setWhat(self, what):
        """ generated source for method setWhat """
        self.what = what

    # 
    #    * Sets the source, and the shortsrc.
    #    
    def setSource(self, source):
        """ generated source for method setSource """
        self.source = source
        self.shortsrc = Lua.oChunkid(source)

    # 
    #    * Gets the current line.  May become public.
    #    
    def currentline(self):
        """ generated source for method currentline """
        return self.currentline

    # 
    #    * Set currentline.
    #    
    def setCurrentline(self, currentline):
        """ generated source for method setCurrentline """
        self.currentline = currentline

    # 
    #    * Get linedefined.
    #    
    def linedefined(self):
        """ generated source for method linedefined """
        return self.linedefined

    # 
    #    * Set linedefined.
    #    
    def setLinedefined(self, linedefined):
        """ generated source for method setLinedefined """
        self.linedefined = linedefined

    # 
    #    * Set lastlinedefined.
    #    
    def setLastlinedefined(self, lastlinedefined):
        """ generated source for method setLastlinedefined """
        self.lastlinedefined = lastlinedefined

    # 
    #    * Gets the "printable" version of source, for error messages.
    #    * May become public.
    #    
    def shortsrc(self):
        """ generated source for method shortsrc """
        return self.shortsrc

