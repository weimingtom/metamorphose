#!/usr/bin/env python
""" generated source for module StringLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/StringLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Contains Lua's string library.
#  * The library can be opened using the {@link #open} method.
#  
class StringLib(LuaJavaCallback):
    """ generated source for class StringLib """
    #  Each function in the string library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    BYTE = 1
    CHAR = 2
    DUMP = 3
    FIND = 4
    FORMAT = 5
    GFIND = 6
    GMATCH = 7
    GSUB = 8
    LEN = 9
    LOWER = 10
    MATCH = 11
    REP = 12
    REVERSE = 13
    SUB = 14
    UPPER = 15
    GMATCH_AUX = 16
    GMATCH_AUX_FUN = StringLib(GMATCH_AUX)

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    #  Constructs instance, filling in the 'which' member. 
    def __init__(self, which):
        """ generated source for method __init__ """
        super(StringLib, self).__init__()
        self.which = which

    # 
    #    * Adjusts the output of string.format so that %e and %g use 'e'
    #    * instead of 'E' to indicate the exponent.  In other words so that
    #    * string.format follows the ISO C (ISO 9899) standard for printf.
    #    
    def formatISO(self):
        """ generated source for method formatISO """
        FormatItem.E_LOWER = 'e'

    # 
    #    * Implements all of the functions in the Lua string library.  Do not
    #    * call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.BYTE:
            return byteFunction(L)
        elif self.which == self.CHAR:
            return charFunction(L)
        elif self.which == self.DUMP:
            return dump(L)
        elif self.which == self.FIND:
            return find(L)
        elif self.which == self.FORMAT:
            return format(L)
        elif self.which == self.GMATCH:
            return gmatch(L)
        elif self.which == self.GSUB:
            return gsub(L)
        elif self.which == self.LEN:
            return len(L)
        elif self.which == self.LOWER:
            return lower(L)
        elif self.which == self.MATCH:
            return match(L)
        elif self.which == self.REP:
            return rep(L)
        elif self.which == self.REVERSE:
            return reverse(L)
        elif self.which == self.SUB:
            return sub(L)
        elif self.which == self.UPPER:
            return upper(L)
        elif self.which == self.GMATCH_AUX:
            return gmatchaux(L)
        return 0

    # 
    #    * Opens the string library into the given Lua state.  This registers
    #    * the symbols of the string library in a newly created table called
    #    * "string".
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        lib = L.register("string")
        r(L, "byte", cls.BYTE)
        r(L, "char", cls.CHAR)
        r(L, "dump", cls.DUMP)
        r(L, "find", cls.FIND)
        r(L, "format", cls.FORMAT)
        r(L, "gfind", cls.GFIND)
        r(L, "gmatch", cls.GMATCH)
        r(L, "gsub", cls.GSUB)
        r(L, "len", cls.LEN)
        r(L, "lower", cls.LOWER)
        r(L, "match", cls.MATCH)
        r(L, "rep", cls.REP)
        r(L, "reverse", cls.REVERSE)
        r(L, "sub", cls.SUB)
        r(L, "upper", cls.UPPER)
        mt = LuaTable()
        L.setMetatable("", mt)
        #  set string metatable
        L.setField(mt, "__index", lib)

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = StringLib(which)
        lib = L.getGlobal("string")
        L.setField(lib, name, f)

    #  Implements string.byte.  Name mangled to avoid keyword. 
    @classmethod
    def byteFunction(cls, L):
        """ generated source for method byteFunction """
        s = L.checkString(1)
        posi = posrelat(L.optInt(2, 1), s)
        pose = posrelat(L.optInt(3, posi), s)
        if posi <= 0:
            posi = 1
        if pose > len(s):
            pose = len(s)
        if posi > pose:
            return 0
            #  empty interval; return no values
        n = pose - posi + 1
        i = 0
        while i < n:
            L.pushNumber(s.charAt(posi + i - 1))
            i += 1
        return n

    #  Implements string.char.  Name mangled to avoid keyword. 
    @classmethod
    def charFunction(cls, L):
        """ generated source for method charFunction """
        n = L.getTop()
        #  number of arguments
        b = StringBuffer()
        i = 1
        while i <= n:
            c = L.checkInt(i)
            L.argCheck(str(c) == c, i, "invalid value")
            b.append(str(c))
            i += 1
        L.push(b.__str__())
        return 1

    #  Implements string.dump. 
    @classmethod
    def dump(cls, L):
        """ generated source for method dump """
        L.checkType(1, Lua.TFUNCTION)
        L.setTop(1)
        try:
            s = ByteArrayOutputStream()
            Lua.dump(L.value(1), s)
            a = s.toByteArray()
            s = None
            b = StringBuffer()
            i = 0
            while len(a):
                b.append(str((a[i] & 0xff)))
                i += 1
            L.pushString(b.__str__())
            return 1
        except IOError as e_:
            L.error("unabe to dump given function")
        #  NOTREACHED
        return 0

    #  Helper for find and match.  Equivalent to str_find_aux. 
    @classmethod
    def findAux(cls, L, isFind):
        """ generated source for method findAux """
        s = L.checkString(1)
        p = L.checkString(2)
        l1 = len(s)
        l2 = len(p)
        init = posrelat(L.optInt(3, 1), s) - 1
        if init < 0:
            init = 0
        elif init > l1:
            init = l1
        if isFind and (L.toBoolean(L.value(4)) or strpbrk(p, MatchState.SPECIALS) < 0):
            #  or no special characters?
            #  do a plain search
            off = lmemfind(s.substring(init), l1 - init, p, l2)
            if off >= 0:
                L.pushNumber(init + off + 1)
                L.pushNumber(init + off + l2)
                return 2
        else:
        __si_0 = si
        si += 1
            ms = MatchState(L, s, l1)
            anchor = p.charAt(0) == '^'
            si = init
            while True:
                ms.level = 0
                res = ms.match(si, p, 1 if anchor else 0)
                if res >= 0:
                    if isFind:
                        L.pushNumber(si + 1)
                        #  start
                        L.pushNumber(res)
                        #  end
                        return ms.push_captures(-1, -1) + 2
                    #  else
                    return ms.push_captures(si, res)
                if not ((__si_0 < ms.end and not anchor)):
                    break
        L.pushNil()
        #  not found
        return 1

    #  Implements string.find. 
    @classmethod
    def find(cls, L):
        """ generated source for method find """
        return cls.findAux(L, True)

    #  Implement string.match.  Operates slightly differently from the
    #    * PUC-Rio code because instead of storing the iteration state as
    #    * upvalues of the C closure the iteration state is stored in an
    #    * Object[3] and kept on the stack.
    #    
    @classmethod
    def gmatch(cls, L):
        """ generated source for method gmatch """
        state = [None] * 3
        state[0] = L.checkString(1)
        state[1] = L.checkString(2)
        state[2] = int(0)
        L.push(cls.GMATCH_AUX_FUN)
        L.push(state)
        return 2

    # 
    #    * Expects the iteration state, an Object[3] (see {@link
    #    * #gmatch}), to be first on the stack.
    #    
    @classmethod
    def gmatchaux(cls, L):
        """ generated source for method gmatchaux """
        state = L.value(1)
        s = str(state[0])
        p = str(state[1])
        i = (int(state[2])).intValue()
        ms = MatchState(L, s, len(s))
        while i <= ms.end:
            ms.level = 0
            e = ms.match(i, p, 0)
            if e >= 0:
                newstart = e
                if e == i:
                    newstart += 1
                #  go at least one position
                state[2] = int(newstart)
                return ms.push_captures(i, e)
            i += 1
        return 0
        #  not found.

    #  Implements string.gsub. 
    @classmethod
    def gsub(cls, L):
        """ generated source for method gsub """
        s = L.checkString(1)
        sl = len(s)
        p = L.checkString(2)
        maxn = L.optInt(4, sl + 1)
        anchor = False
        if 0 > len(p):
            anchor = p.charAt(0) == '^'
        if anchor:
            p = p.substring(1)
        ms = MatchState(L, s, sl)
        b = StringBuffer()
        n = 0
        si = 0
        __si_1 = si
        si += 1
        while n < maxn:
            ms.level = 0
            e = ms.match(si, p, 0)
            if e >= 0:
                n += 1
                ms.addvalue(b, si, e)
            if e >= 0 and e > si:
                si = e
            elif si < ms.end:
                b.append(s.charAt(__si_1))
            else:
                pass
            if anchor:
                break
        b.append(s.substring(si))
        L.pushString(b.__str__())
        L.pushNumber(n)
        #  number of substitutions
        return 2

    @classmethod
    def addquoted(cls, L, b, arg):
        """ generated source for method addquoted """
        s = L.checkString(arg)
        l = len(s)
        b.append('"')
        i = 0
        while i < l:
            if s.charAt(i) == '"':
                pass
            elif s.charAt(i) == '\\':
                pass
            elif s.charAt(i) == '\n':
                b.append('\\')
                b.append(s.charAt(i))
            elif s.charAt(i) == '\r':
                b.append("\\r")
            elif s.charAt(i) == '\0':
                b.append("\\000")
            else:
                b.append(s.charAt(i))
            i += 1
        b.append('"')

    @classmethod
    def format(cls, L):
        """ generated source for method format """
        arg = 1
        strfrmt = L.checkString(1)
        sfl = len(strfrmt)
        b = StringBuffer()
        i = 0
        __i_2 = i
        i += 1
        i += 1
        __i_4 = i
        i += 1
        while i < sfl:
            if strfrmt.charAt(i) != MatchState.L_ESC:
                b.append(strfrmt.charAt(__i_2))
            elif strfrmt.charAt(i) == MatchState.L_ESC:
                b.append(strfrmt.charAt(__i_4))
            else:
                #  format item
                arg += 1
                item = FormatItem(L, strfrmt.substring(i))
                i += len(item)
                if item.type_() == 'c':
                    item.formatChar(b, str(L.checkNumber(arg)))
                elif item.type_() == 'd':
                    pass
                elif item.type_() == 'i':
                    pass
                elif item.type_() == 'o':
                    pass
                elif item.type_() == 'u':
                    pass
                elif item.type_() == 'x':
                    pass
                elif item.type_() == 'X':
                    #  :todo: should be unsigned conversions cope better with
                    #  negative number?
                    item.formatInteger(b, long(L.checkNumber(arg)))
                elif item.type_() == 'e':
                    pass
                elif item.type_() == 'E':
                    pass
                elif item.type_() == 'f':
                    pass
                elif item.type_() == 'g':
                    pass
                elif item.type_() == 'G':
                    item.formatFloat(b, L.checkNumber(arg))
                elif item.type_() == 'q':
                    cls.addquoted(L, b, arg)
                elif item.type_() == 's':
                    item.formatString(b, L.checkString(arg))
                else:
                    return L.error("invalid option to 'format'")
        L.pushString(b.__str__())
        return 1

    #  Implements string.len. 
    @classmethod
    def len(cls, L):
        """ generated source for method len """
        s = L.checkString(1)
        L.pushNumber(len(s))
        return 1

    #  Implements string.lower. 
    @classmethod
    def lower(cls, L):
        """ generated source for method lower """
        s = L.checkString(1)
        L.push(s.lower())
        return 1

    #  Implements string.match. 
    @classmethod
    def match(cls, L):
        """ generated source for method match """
        return cls.findAux(L, False)

    #  Implements string.rep. 
    @classmethod
    def rep(cls, L):
        """ generated source for method rep """
        s = L.checkString(1)
        n = L.checkInt(2)
        b = StringBuffer()
        i = 0
        while i < n:
            b.append(s)
            i += 1
        L.push(b.__str__())
        return 1

    #  Implements string.reverse. 
    @classmethod
    def reverse(cls, L):
        """ generated source for method reverse """
        s = L.checkString(1)
        b = StringBuffer()
        l = len(s)
        l -= 1
        while l >= 0:
            b.append(s.charAt(l))
        L.push(b.__str__())
        return 1

    #  Helper for {@link #sub} and friends. 
    @classmethod
    def posrelat(cls, pos, s):
        """ generated source for method posrelat """
        if pos >= 0:
            return pos
        len = len(s)
        return len + pos + 1

    #  Implements string.sub. 
    @classmethod
    def sub(cls, L):
        """ generated source for method sub """
        s = L.checkString(1)
        start = cls.posrelat(L.checkInt(2), s)
        end = cls.posrelat(L.optInt(3, -1), s)
        if start < 1:
            start = 1
        if end > len(s):
            end = len(s)
        if start <= end:
            L.push(s.substring(start - 1, end))
        else:
            L.pushLiteral("")
        return 1

    #  Implements string.upper. 
    @classmethod
    def upper(cls, L):
        """ generated source for method upper """
        s = L.checkString(1)
        L.push(s.toUpperCase())
        return 1

    # 
    #    * @return  character index of start of match (-1 if no match).
    #    
    @classmethod
    def lmemfind(cls, s1, l1, s2, l2):
        """ generated source for method lmemfind """
        if l2 == 0:
            return 0
            #  empty strings are everywhere
        elif l2 > l1:
            return -1
            #  avoids a negative l1
        return s1.indexOf(s2)

    # 
    #    * Just like C's strpbrk.
    #    * @return an index into <var>s</var> or -1 for no match.
    #    
    @classmethod
    def strpbrk(cls, s, set):
        """ generated source for method strpbrk """
        l = len(set)
        i = 0
        while i < l:
            idx = s.indexOf(set.charAt(i))
            if idx >= 0:
                return idx
            i += 1
        return -1


class MatchState(object):
    """ generated source for class MatchState """
    L = None

    #  The entire string that is the subject of the match. 
    src = None

    #  The subject's length. 
    end = int()

    #  Total number of captures (finished or unfinished). 
    level = int()

    #  Each capture element is a 2-element array of (index, len). 
    capture = Vector()

    #  :todo: consider adding the pattern string as a member (and removing
    #  p parameter from methods).
    #  :todo: consider removing end parameter, if end always == // src.length()
    def __init__(self, L, src, end):
        """ generated source for method __init__ """
        self.L = L
        self.src = src
        self.end = end

    # 
    #    * Returns the length of capture <var>i</var>.
    #    
    def captureLen(self, i):
        """ generated source for method captureLen """
        c = int(self.capture.elementAt(i))
        return c[1]

    # 
    #    * Returns the init index of capture <var>i</var>.
    #    
    def captureInit(self, i):
        """ generated source for method captureInit """
        c = int(self.capture.elementAt(i))
        return c[0]

    # 
    #    * Returns the 2-element array for the capture <var>i</var>.
    #    
    def capture(self, i):
        """ generated source for method capture """
        return int(self.capture.elementAt(i))

    def capInvalid(self):
        """ generated source for method capInvalid """
        return self.L.error("invalid capture index")

    def malBra(self):
        """ generated source for method malBra """
        return self.L.error("malformed pattern (missing '[')")

    def capUnfinished(self):
        """ generated source for method capUnfinished """
        return self.L.error("unfinished capture")

    def malEsc(self):
        """ generated source for method malEsc """
        return self.L.error("malformed pattern (ends with '%')")

    def check_capture(self, l):
        """ generated source for method check_capture """
        l -= '1'
        #  relies on wraparound.
        if l >= self.level or self.captureLen(l) == CAP_UNFINISHED:
            self.capInvalid()
        return l

    def capture_to_close(self):
        """ generated source for method capture_to_close """
        lev = self.level
        while lev >= 0:
            if self.captureLen(lev) == CAP_UNFINISHED:
                return lev
            lev -= 1
        return self.capInvalid()

    def classend(self, p, pi):
        """ generated source for method classend """
        __pi_6 = pi
        pi += 1
        if p.charAt(__pi_6) == L_ESC:
            #  assert pi < p.length() // checked by callers
            return pi + 1
        elif p.charAt(__pi_6) == '[':
        __pi_7 = pi
        pi += 1
            if pi == len(p):
                return self.malBra()
            if p.charAt(pi) == '^':
                pi += 1
            while True:
                #  look for a ']'
                if pi == len(p):
                    return self.malBra()
                if p.charAt(__pi_7) == L_ESC:
                    if pi == len(p):
                        return self.malBra()
                    pi += 1
                    #  skip escapes (e.g. '%]')
                    if pi == len(p):
                        return self.malBra()
                if not ((p.charAt(pi) != ']')):
                    break
            return pi + 1
        else:
            return pi

    # 
    #    * @param c   char match.
    #    * @param cl  character class.
    #    
    @classmethod
    def match_class(cls, c, cl):
        """ generated source for method match_class """
        res = bool()
        if Character.toLowerCase(cl) == 'a':
            res = Syntax.isalpha(c)
        elif Character.toLowerCase(cl) == 'c':
            res = Syntax.iscntrl(c)
        elif Character.toLowerCase(cl) == 'd':
            res = Syntax.isdigit(c)
        elif Character.toLowerCase(cl) == 'l':
            res = Syntax.islower(c)
        elif Character.toLowerCase(cl) == 'p':
            res = Syntax.ispunct(c)
        elif Character.toLowerCase(cl) == 's':
            res = Syntax.isspace(c)
        elif Character.toLowerCase(cl) == 'u':
            res = Syntax.isupper(c)
        elif Character.toLowerCase(cl) == 'w':
            res = Syntax.isalnum(c)
        elif Character.toLowerCase(cl) == 'x':
            res = Syntax.isxdigit(c)
        elif Character.toLowerCase(cl) == 'z':
            res = (c == 0)
        else:
            return (cl == c)
        return res if Character.isLowerCase(cl) else not res

    # 
    #    * @param pi  index in p of start of class.
    #    * @param ec  index in p of end of class.
    #    
    @classmethod
    def matchbracketclass(cls, c, p, pi, ec):
        """ generated source for method matchbracketclass """
        #  :todo: consider changing char c to int c, then -1 could be used
        #  represent a guard value at the beginning and end of all strings (a
        #  better NUL).  -1 of course would match no positive class.
        #  assert p.charAt(pi) == '[';
        #  assert p.charAt(ec) == ']';
        sig = True
        if p.charAt(pi + 1) == '^':
            sig = False
            pi += 1
            #  skip the '6'
        pi += 1
        while pi < ec:
            if p.charAt(pi) == L_ESC:
                pi += 1
                if cls.match_class(c, p.charAt(pi)):
                    return sig
            elif (p.charAt(pi + 1) == '-') and (pi + 2 < ec):
                pi += 2
                if p.charAt(pi - 2) <= c and c <= p.charAt(pi):
                    return sig
            elif p.charAt(pi) == c:
                return sig
        return not sig

    @classmethod
    def singlematch(cls, c, p, pi, ep):
        """ generated source for method singlematch """
        if p.charAt(pi) == '.':
            return True
        elif p.charAt(pi) == L_ESC:
            return cls.match_class(c, p.charAt(pi + 1))
        elif p.charAt(pi) == '[':
            return cls.matchbracketclass(c, p, pi, ep - 1)
        else:
            return p.charAt(pi) == c

    #  Generally all the various match functions from PUC-Rio which take a
    #  MatchState and return a "const char *" are transformed into
    #  instance methods that take and return string indexes.
    def matchbalance(self, si, p, pi):
        """ generated source for method matchbalance """
        if pi + 1 >= len(p):
            self.L.error("unbalanced pattern")
        if si >= self.end or self.src.charAt(si) != p.charAt(pi):
            return -1
        b = p.charAt(pi)
        e = p.charAt(pi + 1)
        cont = 1
        si += 1
        cont -= 1
        while si < self.end:
            if self.src.charAt(si) == e:
                if cont == 0:
                    return si + 1
            elif self.src.charAt(si) == b:
                cont += 1
        return -1
        #  string ends out of balance

    def max_expand(self, si, p, pi, ep):
        """ generated source for method max_expand """
        i = 0
        #  counts maximum expand for item
        while si + i < self.end and self.singlematch(self.src.charAt(si + i), p, pi, ep):
            i += 1
        #  keeps trying to match with the maximum repetitions
        while i >= 0:
            res = match(si + i, p, ep + 1)
            if res >= 0:
                return res
            i -= 1
            #  else didn't match; reduce 1 repetition to try again
        return -1

    def min_expand(self, si, p, pi, ep):
        """ generated source for method min_expand """
        while True:
            res = match(si, p, ep + 1)
            if res >= 0:
                return res
            elif si < self.end and self.singlematch(self.src.charAt(si), p, pi, ep):
                si += 1
            else:
                #  try with one more repetition
                return -1

    def start_capture(self, si, p, pi, what):
        """ generated source for method start_capture """
        self.capture.setSize(self.level + 1)
        self.capture.setElementAt([None] * , self.level)
        self.level += 1
        res = match(si, p, pi)
        if res < 0:
            #  match failed
            self.level -= 1
        return res

    def end_capture(self, si, p, pi):
        """ generated source for method end_capture """
        l = self.capture_to_close()
        self.capture(l)[1] = si - self.captureInit(l)
        #  close it
        res = match(si, p, pi)
        if res < 0:
            #  match failed?
            self.capture(l)[1] = CAP_UNFINISHED
            #  undo capture
        return res

    def match_capture(self, si, l):
        """ generated source for method match_capture """
        l = self.check_capture(l)
        len = self.captureLen(l)
        if self.end - si >= len and self.src.regionMatches(False, self.captureInit(l), self.src, si, len):
            return si + len
        return -1

    L_ESC = '%'
    SPECIALS = "^$*+?.([%-"
    CAP_UNFINISHED = -1
    CAP_POSITION = -2

    # 
    #    * @param si  index of subject at which to attempt match.
    #    * @param p   pattern string.
    #    * @param pi  index into pattern (from which to being matching).
    #    * @return the index of the end of the match, -1 for no match.
    #    
    def match(self, si, p, pi):
        """ generated source for method match """
        #  This code has been considerably changed in the transformation
        #  from C to Java.  There are the following non-obvious changes:
        #  - The C code routinely relies on NUL being accessible at the end of
        #    the pattern string.  In Java we can't do this, so we use many
        #    more explicit length checks and pull error cases into this
        #    function.  :todo: consider appending NUL to the pattern string.
        #  - The C code uses a "goto dflt" which is difficult to transform in
        #    the usual way.
        #  labelled while loop emulates "goto init", which we use to
        #  optimize tail recursion.
        while True:
            if pi == len(p):
                #  end of pattern
                return si
            #  match succeeded
            if p.charAt(pi) == '(':
                if pi + 1 == len(p):
                    return self.capUnfinished()
                if p.charAt(pi + 1) == ')':
                    #  position capture?
                    return self.start_capture(si, p, pi + 2, self.CAP_POSITION)
                return self.start_capture(si, p, pi + 1, self.CAP_UNFINISHED)
            elif p.charAt(pi) == ')':
                #  end capture
                return self.end_capture(si, p, pi + 1)
            elif p.charAt(pi) == self.L_ESC:
                if pi + 1 == len(p):
                    return self.malEsc()
                if p.charAt(pi + 1) == 'b':
                    #  balanced string?
                    si = self.matchbalance(si, p, pi + 2)
                    if si < 0:
                        return si
                    pi += 4
                    #  else return match(ms, s, p+4);
                    continue 
                elif p.charAt(pi + 1) == 'f':
                    #  frontier
                    pi += 2
                    if pi == len(p) or p.charAt(pi) != '[':
                        return self.L.error("missing '[' after '%f' in pattern")
                    ep = self.classend(p, pi)
                    #  indexes what is next
                    previous = '\0' if (si == 0) else self.src.charAt(si - 1)
                    at = '\0' if (si == self.end) else self.src.charAt(si)
                    if self.matchbracketclass(previous, p, pi, ep - 1) or not self.matchbracketclass(at, p, pi, ep - 1):
                        return -1
                    pi = ep
                    #  else return match(ms, s, ep);
                    continue 
                else:
                    #  goto init
                    if Syntax.isdigit(p.charAt(pi + 1)):
                        #  capture results (%0-%09)?
                        si = self.match_capture(si, p.charAt(pi + 1))
                        if si < 0:
                            return si
                        pi += 2
                        #  else return match(ms, s, p+2);
                        continue 
                        #  goto init
                #  We emulate a goto dflt by a fallthrough to the next
                #  case (of the outer switch) and making sure that the
                #  next case has no effect when we fallthrough to it from here.
                #  goto dflt;
            elif p.charAt(pi) == '$':
                if p.charAt(pi) == '$':
                    if pi + 1 == len(p):
                        #  is the '$' the last char in pattern?
                        return si if (si == self.end) else -1
                    #  check end of string
                    #  else goto dflt;
            else:
                #  FALLTHROUGH
                #  it is a pattern item
                ep = self.classend(p, pi)
                #  indexes what is next
                m = si < self.end and self.singlematch(self.src.charAt(si), p, pi, ep)
                if ep > len(p):
                    if p.charAt(ep) == '?':
                        #  optional
                        if m:
                            res = self.match(si + 1, p, ep + 1)
                            if res >= 0:
                                return res
                        pi = ep + 1
                        #  else return match(s, ep+1);
                        continue 
                    elif p.charAt(ep) == '*':
                        #  0 or more repetitions
                        return self.max_expand(si, p, pi, ep)
                    elif p.charAt(ep) == '+':
                        #  1 or more repetitions
                        return self.max_expand(si + 1, p, pi, ep) if m else -1
                    elif p.charAt(ep) == '-':
                        #  0 or more repetitions (minimum)
                        return self.min_expand(si, p, pi, ep)
                #  else or default:
                if not m:
                    return -1
                si += 1
                pi = ep
                #  return match(ms, s+1, ep);
                continue 

    # 
    #    * @param s  index of start of match.
    #    * @param e  index of end of match.
    #    
    def onecapture(self, i, s, e):
        """ generated source for method onecapture """
        if i >= self.level:
            if i == 0:
                #  level == 0, too
                return self.src.substring(s, e)
            else:
                self.capInvalid()
            #  NOTREACHED;
        l = self.captureLen(i)
        if l == self.CAP_UNFINISHED:
            self.capUnfinished()
        if l == self.CAP_POSITION:
            return Lua.valueOfNumber(self.captureInit(i) + 1)
        return self.src.substring(self.captureInit(i), self.captureInit(i) + l)

    def push_onecapture(self, i, s, e):
        """ generated source for method push_onecapture """
        self.L.push(self.onecapture(i, s, e))

    # 
    #    * @param s  index of start of match.
    #    * @param e  index of end of match.
    #    
    def push_captures(self, s, e):
        """ generated source for method push_captures """
        nlevels = 1 if (self.level == 0 and s >= 0) else self.level
        i = 0
        while i < nlevels:
            self.push_onecapture(i, s, e)
            i += 1
        return nlevels
        #  number of strings pushed

    #  A helper for gsub.  Equivalent to add_s from lstrlib.c. 
    def adds(self, b, si, ei):
        """ generated source for method adds """
        news = self.L.toString(self.L.value(3))
        l = len(news)
        i = 0
        while i < l:
            if news.charAt(i) != self.L_ESC:
                b.append(news.charAt(i))
            else:
                i += 1
                #  skip L_ESC
                if not Syntax.isdigit(news.charAt(i)):
                    b.append(news.charAt(i))
                elif news.charAt(i) == '0':
                    b.append(self.src.substring(si, ei))
                else:
                    #  add capture to accumulated result
                    b.append(self.L.toString(self.onecapture(news.charAt(i) - '1', si, ei)))
            i += 1

    #  A helper for gsub.  Equivalent to add_value from lstrlib.c. 
    def addvalue(self, b, si, ei):
        """ generated source for method addvalue """
        if self.L.type_(3) == Lua.TNUMBER:
            pass
        elif self.L.type_(3) == Lua.TSTRING:
            self.adds(b, si, ei)
            return
        elif self.L.type_(3) == Lua.TFUNCTION:
            self.L.pushValue(3)
            n = self.push_captures(si, ei)
            self.L.call(n, 1)
        elif self.L.type_(3) == Lua.TTABLE:
            self.L.push(self.L.getTable(self.L.value(3), self.onecapture(0, si, ei)))
        else:
            self.L.argError(3, "string/function/table expected")
            return
        if not self.L.toBoolean(self.L.value(-1)):
            #  nil or false
            self.L.pop(1)
            self.L.pushString(self.src.substring(si, ei))
        elif not self.L.isString(self.L.value(-1)):
            self.L.error("invalid replacement value (a " + Lua.typeName(self.L.type_(-1)) + ")")
        b.append(self.L.toString(self.L.value(-1)))
        #  add result to accumulator
        self.L.pop(1)


class FormatItem(object):
    """ generated source for class FormatItem """
    L = None
    left = bool()

    #  '-' flag
    sign = bool()

    #  '+' flag
    space = bool()

    #  ' ' flag
    alt = bool()

    #  '#' flag
    zero = bool()

    #  '0' flag
    width = int()

    #  minimum field width
    precision = -1

    #  precision, -1 when no precision specified.
    type_ = str()

    #  the type of the conversion
    length = int()

    #  length of the format item in the format string.
    # 
    #    * Character used in formatted output when %e or %g format is used.
    #    
    E_LOWER = 'E'

    # 
    #    * Character used in formatted output when %E or %G format is used.
    #    
    E_UPPER = 'E'

    # 
    #    * Parse a format item (starting from after the <code>L_ESC</code>).
    #    * If you promise that there won't be any format errors, then
    #    * <var>L</var> can be <code>null</code>.
    #    
    def __init__(self, L, s):
        """ generated source for method __init__ """
        self.L = L
        i = 0
        l = len(s)
        #  parse flags
        while True:
            if i >= l:
                L.error("invalid format")
            if s.charAt(i) == '-':
                self.left = True
            elif s.charAt(i) == '+':
                self.sign = True
            elif s.charAt(i) == ' ':
                self.space = True
            elif s.charAt(i) == '#':
                self.alt = True
            elif s.charAt(i) == '0':
                self.zero = True
            else:
            i += 1
        #  flag 
        #  parse width
        widths = i
        #  index of start of width specifier
        while True:
            if i >= l:
                L.error("invalid format")
            if Syntax.isdigit(s.charAt(i)):
                i += 1
            else:
                pass
        if widths < i:
            try:
                self.width = Integer.parseInt(s.substring(widths, i))
            except NumberFormatException as e_:
                pass
        #  parse precision
        if s.charAt(i) == '.':
            i += 1
            precisions = i
            #  index of start of precision specifier
            while True:
                if i >= l:
                    L.error("invalid format")
                if Syntax.isdigit(s.charAt(i)):
                    i += 1
                else:
                    pass
            if precisions < i:
                try:
                    self.precision = Integer.parseInt(s.substring(precisions, i))
                except NumberFormatException as e_:
                    pass
        if s.charAt(i) == 'c':
            pass
        elif s.charAt(i) == 'd':
            pass
        elif s.charAt(i) == 'i':
            pass
        elif s.charAt(i) == 'o':
            pass
        elif s.charAt(i) == 'u':
            pass
        elif s.charAt(i) == 'x':
            pass
        elif s.charAt(i) == 'X':
            pass
        elif s.charAt(i) == 'e':
            pass
        elif s.charAt(i) == 'E':
            pass
        elif s.charAt(i) == 'f':
            pass
        elif s.charAt(i) == 'g':
            pass
        elif s.charAt(i) == 'G':
            pass
        elif s.charAt(i) == 'q':
            pass
        elif s.charAt(i) == 's':
            self.type_ = s.charAt(i)
            self.length = i + 1
            return
        L.error("invalid option to 'format'")

    def length(self):
        """ generated source for method length """
        return self.length

    def type_(self):
        """ generated source for method type_ """
        return self.type_

    # 
    #    * Format the converted string according to width, and left.
    #    * zero padding is handled in either {@link FormatItem#formatInteger}
    #    * or {@link FormatItem#formatFloat}
    #    * (and width is fixed to 0 in such cases).  Therefore we can ignore
    #    * zero.
    #    
    def format(self, b, s):
        """ generated source for method format """
        l = len(s)
        if l >= self.width:
            b.append(s)
            return
        pad = StringBuffer()
        while l < self.width:
            pad.append(' ')
            l += 1
        if self.left:
            b.append(s)
            b.append(pad)
        else:
            b.append(pad)
            b.append(s)

    #  All the format* methods take a StringBuffer and append the
    #  formatted representation of the value to it.
    #  Sadly after a format* method has been invoked the object is left in
    #  an unusable state and should not be used again.
    def formatChar(self, b, c):
        """ generated source for method formatChar """
        s = str(c)
        self.format(b, s)

    def formatInteger(self, b, i):
        """ generated source for method formatInteger """
        #  :todo: improve inefficient use of implicit StringBuffer
        if self.left:
            self.zero = False
        if self.precision >= 0:
            self.zero = False
        radix = 10
        if self.type_ == 'o':
            radix = 8
        elif self.type_ == 'd':
            pass
        elif self.type_ == 'i':
            pass
        elif self.type_ == 'u':
            radix = 10
        elif self.type_ == 'x':
            pass
        elif self.type_ == 'X':
            radix = 16
        else:
            self.L.error("invalid format")
        s = Long.toString(i, radix)
        if self.type_ == 'X':
            s = s.toUpperCase()
        if self.precision == 0 and s == "0":
            s = ""
        #  form a prefix by strippping possible leading '-',
        #  pad to precision,
        #  add prefix,
        #  pad to width.
        #  extra wart: padding with '0' is implemented using precision
        #  because this makes handling the prefix easier.
        prefix = ""
        if s.startsWith("-"):
            prefix = "-"
            s = s.substring(1)
        if self.alt and radix == 16:
            prefix = "0x"
        if prefix == "":
            if self.sign:
                prefix = "+"
            elif self.space:
                prefix = " "
        if self.alt and radix == 8 and not s.startsWith("0"):
            s = "0" + s
        l = len(s)
        if self.zero:
            self.precision = self.width - len(prefix)
            self.width = 0
        if l < self.precision:
            p = StringBuffer()
            while l < self.precision:
                p.append('0')
                l += 1
            p.append(s)
            s = p.__str__()
        s = prefix + s
        self.format(b, s)

    def formatFloat(self, b, d):
        """ generated source for method formatFloat """
        if self.type_ == 'g':
            pass
        elif self.type_ == 'G':
            formatFloatG(b, d)
            return
        elif self.type_ == 'f':
            formatFloatF(b, d)
            return
        elif self.type_ == 'e':
            pass
        elif self.type_ == 'E':
            formatFloatE(b, d)
            return

    def formatFloatE(self, b, d):
        """ generated source for method formatFloatE """
        s = formatFloatRawE(d)
        self.format(b, s)

    # 
    #    * Returns the formatted string for the number without any padding
    #    * (which can be added by invoking {@link FormatItem#format} later).
    #    
    def formatFloatRawE(self, d):
        """ generated source for method formatFloatRawE """
        m = abs(d)
        offset = 0
        if m >= 1e-3 and m < 1e7:
            d *= 1e10
            offset = 10
        s = Double.toString(d)
        t = StringBuffer(s)
        e = int()
        #  Exponent value
        if d == 0:
            e = 0
        else:
            ei = s.indexOf('E')
            e = Integer.parseInt(s.substring(ei + 1))
            t.delete(ei, Integer.MAX_VALUE)
        precisionTrim(t)
        e -= offset
        if Character.isLowerCase(self.type_):
            t.append(self.E_LOWER)
        else:
            t.append(self.E_UPPER)
        if e >= 0:
            t.append('+')
        t.append(Integer.toString(e))
        zeroPad(t)
        return t.__str__()

    def formatFloatF(self, b, d):
        """ generated source for method formatFloatF """
        s = formatFloatRawF(d)
        self.format(b, s)

    # 
    #    * Returns the formatted string for the number without any padding
    #    * (which can be added by invoking {@link FormatItem#format} later).
    #    
    def formatFloatRawF(self, d):
        """ generated source for method formatFloatRawF """
        s = Double.toString(d)
        t = StringBuffer(s)
        di = s.indexOf('.')
        ei = s.indexOf('E')
        if ei >= 0:
            t.delete(ei, Integer.MAX_VALUE)
            e = Integer.parseInt(s.substring(ei + 1))
            z = StringBuffer()
            i = 0
            while i < abs(e):
                z.append('0')
                i += 1
            if e > 0:
                t.deleteCharAt(di)
                t.append(z)
                t.insert(di + e, '.')
            else:
                t.deleteCharAt(di)
                at = 1 if t.charAt(0) == '-' else 0
                t.insert(at, z)
                t.insert(di, '.')
        precisionTrim(t)
        zeroPad(t)
        return t.__str__()

    def formatFloatG(self, b, d):
        """ generated source for method formatFloatG """
        if self.precision == 0:
            self.precision = 1
        if self.precision < 0:
            self.precision = 6
        s = None
        #  Decide whether to use %e or %f style.
        m = abs(d)
        if m == 0:
            #  :todo: Could test for -0 and use "-0" appropriately.
            s = "0"
        elif m < 1e-4 or m >= Lua.iNumpow(10, self.precision):
            #  %e style
            self.precision -= 1
            s = self.formatFloatRawE(d)
            di = s.indexOf('.')
            if di >= 0:
                #  Trim trailing zeroes from fractional part
                ei = s.indexOf('E')
                if ei < 0:
                    ei = s.indexOf('e')
                i = ei - 1
                while s.charAt(i) == '0':
                    i -= 1
                if s.charAt(i) != '.':
                    i += 1
                a = StringBuffer(s)
                a.delete(i, ei)
                s = a.__str__()
        else:
            #  %f style
            #  For %g precision specifies the number of significant digits,
            #  for %f precision specifies the number of fractional digits.
            #  There is a problem because it's not obvious how many fractional
            #  digits to format, it could be more than precision
            #  (when .0001 <= m < 1) or it could be less than precision
            #  (when m >= 1).
            #  Instead of trying to work out the correct precision to use for
            #  %f formatting we use a worse case to get at least all the
            #  necessary digits, then we trim using string editing.  The worst
            #  case is that 3 zeroes come after the decimal point before there
            #  are any significant digits.
            #  Save the required number of significant digits
            required = self.precision
            self.precision += 3
            s = self.formatFloatRawF(d)
            fsd = 0
            #  First Significant Digit
            while s.charAt(fsd) == '0' or s.charAt(fsd) == '.':
                fsd += 1
            #  Note that all the digits to the left of the decimal point in
            #  the formatted number are required digits (either significant
            #  when m >= 1 or 0 when m < 1).  We know this because otherwise 
            #  m >= (10**precision) and so formatting falls under the %e case.
            #  That means that we can always trim the string at fsd+required
            #  (this will remove the decimal point when m >=
            #  (10**(precision-1)).
            a = StringBuffer(s)
            a.delete(fsd + required, Integer.MAX_VALUE)
            if s.indexOf('.') < len(a):
                #  Trim trailing zeroes
                i = 1 - len(a)
                while a.charAt(i) == '0':
                    a.deleteCharAt(i)
                    i -= 1
                if a.charAt(i) == '.':
                    a.deleteCharAt(i)
            s = a.__str__()
        self.format(b, s)

    def formatString(self, b, s):
        """ generated source for method formatString """
        p = s
        if self.precision >= 0 and self.precision < len(s):
            p = s.substring(0, self.precision)
        self.format(b, p)

    def precisionTrim(self, t):
        """ generated source for method precisionTrim """
        if self.precision < 0:
            self.precision = 6
        s = t.__str__()
        di = s.indexOf('.')
        l = len(t)
        if 0 == self.precision:
            t.delete(di, Integer.MAX_VALUE)
        elif l > di + self.precision:
            t.delete(di + self.precision + 1, Integer.MAX_VALUE)
        else:
            while l <= di + self.precision:
                t.append('0')
                l += 1

    def zeroPad(self, t):
        """ generated source for method zeroPad """
        if self.zero and self.width < len(t):
            at = 1 if t.charAt(0) == '-' else 0
            while self.width < len(t):
                t.insert(at, '0')

