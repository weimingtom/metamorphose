#!/usr/bin/env python
""" generated source for module Lua """
from __future__ import print_function
def bsr(value, bits):
    """ bsr(value, bits) -> value shifted right by bits

    This function is here because an expression in the original java
    source contained the token '>>>' and/or '>>>=' (bit shift right
    and/or bit shift right assign).  In place of these, the python
    source code below contains calls to this function.

    Copyright 2003 Jeffrey Clement.  See pyrijnadel.py for license and
    original source.
    """
    minint = -2147483648
    if bits == 0:
        return value
    elif bits == 31:
        if value & minint:
            return 1
        else:
            return 0
    elif bits < 0 or bits > 31:
        raise ValueError('bad shift count')
    tmp = (value & 0x7FFFFFFE) // 2**bits
    if (value & minint):
        return (tmp | (0x40000000 // 2**(bits-1)))
    else:
        return tmp

#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Lua.java#3 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * <p>
#  * Encapsulates a Lua execution environment.  A lot of Jill's public API
#  * manifests as public methods in this class.  A key part of the API is
#  * the ability to call Lua functions from Java (ultimately, all Lua code
#  * is executed in this manner).
#  * </p>
#  *
#  * <p>
#  * The Stack
#  * </p>
#  *
#  * <p>
#  * All arguments to Lua functions and all results returned by Lua
#  * functions are placed onto a stack.  The stack can be indexed by an
#  * integer in the same way as the PUC-Rio implementation.  A positive
#  * index is an absolute index and ranges from 1 (the bottom-most
#  * element) through to <var>n</var> (the top-most element),
#  * where <var>n</var> is the number of elements on the stack.  Negative
#  * indexes are relative indexes, -1 is the top-most element, -2 is the
#  * element underneath that, and so on.  0 is not used.
#  * </p>
#  *
#  * <p>
#  * Note that in Jill the stack is used only for passing arguments and
#  * returning results, unlike PUC-Rio.
#  * </p>
#  *
#  * <p>
#  * The protocol for calling a function is described in the {@link #call}
#  * method.  In brief: push the function onto the stack, then push the
#  * arguments to the call.
#  * </p>
#  *
#  * <p>
#  * The methods {@link #push}, {@link #pop}, {@link #value},
#  * {@link #getTop}, {@link #setTop} are used to manipulate the stack.
#  * </p>
#  
class Lua(object):
    """ generated source for class Lua """
    D = False

    #  Version string. 
    VERSION = "Lua 5.1 (Jill 1.0.1)"

    # FIXME:added
    RELEASE = "Lua 5.1.4 (Jill 1.0.1)"
    VERSION_NUM = 501

    #  http://www.ravenbrook.com 
    AUTHORS = "R. Ierusalimschy, L. H. de Figueiredo & W. Celes (Ravenbrook Limited)"

    #  Table of globals (global variables).  This actually shared across
    #    * all threads (with the same main thread), but kept in each Lua
    #    * thread as an optimisation.
    #    
    global_ = None
    registry = None

    #  Reference the main Lua thread.  Itself if this is the main Lua
    #    * thread.
    #    
    main = None

    #  VM data stack.
    #    
    stack = [None] * 0

    # 
    #    * One more than the highest stack slot that has been written to
    #    * (ever).
    #    * Used by {@link #stacksetsize} to determine which stack slots
    #    * need nilling when growing the stack.
    #    
    stackhighwater = int()

    #  = 0;
    # 
    #    * Number of active elemements in the VM stack.  Should always be
    #    * <code><= stack.length</code>.
    #    
    stackSize = int()

    #  = 0;
    # 
    #    * The base stack element for this stack frame.  If in a Lua function
    #    * then this is the element indexed by operand field 0; if in a Java
    #    
    base = int()

    #  = 0;
    nCcalls = int()

    #  = 0;
    #  Instruction to resume execution at.  Index into code array. 
    savedpc = int()

    #  = 0;
    # 
    #    * Vector of CallInfo records.  Actually it's a Stack which is a
    #    * subclass of Vector, but it mostly the Vector methods that are used.
    #    
    civ = Stack()

    #  CallInfo record for currently active function. 
    def ci(self):
        """ generated source for method ci """
        return self.civ.lastElement()

    #  Open Upvalues.  All UpVal objects that reference the VM stack.
    #    * openupval is a java.util.Vector of UpVal stored in order of stack
    #    * slot index: higher stack indexes are stored at higher Vector
    #    * positions.
    #    
    openupval = Vector()
    hookcount = int()
    basehookcount = int()
    allowhook = True
    hook = None
    hookmask = int()

    #  Number of list items to accumulate before a SETLIST instruction. 
    LFIELDS_PER_FLUSH = 50

    #  Limit for table tag-method chains (to avoid loops) 
    MAXTAGLOOP = 100

    # 
    #    * The current error handler (set by {@link #pcall}).  A Lua
    #    * function to call.
    #    
    errfunc = None

    # 
    #    * thread activation status.
    #    
    status = int()

    #  Nonce object used by pcall and friends (to detect when an
    #    * exception is a Lua error). 
    LUA_ERROR = ""

    #  Metatable for primitive types.  Shared between all threads. 
    metatable = []

    # 
    #    * Maximum number of local variables per function.  As per
    #    * LUAI_MAXVARS from "luaconf.h".  Default access so that {@link
    #    * FuncState} can see it.
    #    
    MAXVARS = 200
    MAXSTACK = 250
    MAXUPVALUES = 60

    # 
    #    * Stored in Slot.r to denote a numeric value (which is stored at 
    #    * Slot.d).
    #    
    NUMBER = object()

    # 
    #    * Spare Slot used for a temporary.
    #    
    SPARE_SLOT = Slot()

    # 
    #    * Registry key for loaded modules.
    #    
    LOADED = "_LOADED"

    # 
    #    * Used to construct a Lua thread that shares its global state with
    #    * another Lua state.
    #    
    @overloaded
    def __init__(self, L):
        """ generated source for method __init__ """
        #  Copy the global state, that's shared across all threads that
        #  share the same main thread, into the new Lua thread.
        #  Any more than this and the global state should be shunted to a
        #  separate object (as it is in PUC-Rio).
        self.global_ = L.global_
        self.registry = L.registry
        self.metatable = L.metatable
        self.main = L

    # ////////////////////////////////////////////////////////////////////
    #  Public API
    # 
    #    * Creates a fresh Lua state.
    #    
    @__init__.register(object)
    def __init___0(self):
        """ generated source for method __init___0 """
        self.global_ = LuaTable()
        self.registry = LuaTable()
        self.metatable = [None] * NUM_TAGS
        self.main = self

    # 
    #    * Equivalent of LUA_MULTRET.
    #    
    #  Required, by vmPoscall, to be negative.
    MULTRET = -1

    # 
    #    * The Lua <code>nil</code> value.
    #    
    NIL = object()

    #  Lua type tags, from lua.h
    #  Lua type tag, representing no stack value. 
    TNONE = -1

    #  Lua type tag, representing <code>nil</code>. 
    TNIL = 0

    #  Lua type tag, representing boolean. 
    TBOOLEAN = 1

    #  TLIGHTUSERDATA not available.  :todo: make available?
    #  Lua type tag, representing numbers. 
    TNUMBER = 3

    #  Lua type tag, representing strings. 
    TSTRING = 4

    #  Lua type tag, representing tables. 
    TTABLE = 5

    #  Lua type tag, representing functions. 
    TFUNCTION = 6

    #  Lua type tag, representing userdata. 
    TUSERDATA = 7

    #  Lua type tag, representing threads. 
    TTHREAD = 8

    #  Number of type tags.  Should be one more than the
    #    * last entry in the list of tags.
    #    
    NUM_TAGS = 9

    #  Names for above type tags, starting from {@link #TNIL}.
    #    * Equivalent to luaT_typenames.
    #    
    TYPENAME = ["nil", "boolean", "userdata", "number", "string", "table", "function", "userdata", "thread"]

    # 
    #    * Minimum stack size that Lua Java functions gets.  May turn out to
    #    * be silly / redundant.
    #    
    MINSTACK = 20

    #  Status code, returned from pcall and friends, that indicates the
    #    * thread has yielded.
    #    
    YIELD = 1

    #  Status code, returned from pcall and friends, that indicates
    #    * a runtime error.
    #    
    ERRRUN = 2

    #  Status code, returned from pcall and friends, that indicates
    #    * a syntax error.
    #    
    ERRSYNTAX = 3

    #  Status code, returned from pcall and friends, that indicates
    #    * a memory allocation error.
    #    
    ERRMEM = 4

    #  Status code, returned from pcall and friends, that indicates
    #    * an error whilst running the error handler function.
    #    
    ERRERR = 5

    #  Status code, returned from loadFile and friends, that indicates
    #    * an IO error.
    #    
    ERRFILE = 6

    #  Enums for gc().
    #  Action, passed to {@link #gc}, that requests the GC to stop. 
    GCSTOP = 0

    #  Action, passed to {@link #gc}, that requests the GC to restart. 
    GCRESTART = 1

    #  Action, passed to {@link #gc}, that requests a full collection. 
    GCCOLLECT = 2

    #  Action, passed to {@link #gc}, that returns amount of memory
    #    * (in Kibibytes) in use (by the entire Java runtime).
    #    
    GCCOUNT = 3

    #  Action, passed to {@link #gc}, that returns the remainder of
    #    * dividing the amount of memory in use by 1024.
    #    
    GCCOUNTB = 4

    #  Action, passed to {@link #gc}, that requests an incremental
    #    * garbage collection be performed.
    #    
    GCSTEP = 5

    #  Action, passed to {@link #gc}, that sets a new value for the
    #    * <var>pause</var> of the collector.
    #    
    GCSETPAUSE = 6

    #  Action, passed to {@link #gc}, that sets a new values for the
    #    * <var>step multiplier</var> of the collector.
    #    
    GCSETSTEPMUL = 7

    #  Some of the hooks, etc, aren't implemented, so remain private.
    HOOKCALL = 0
    HOOKRET = 1
    HOOKLINE = 2

    # 
    #    * When {@link Hook} callback is called as a line hook, its
    #    * <var>ar.event</var> field is <code>HOOKCOUNT</code>.
    #    
    HOOKCOUNT = 3
    HOOKTAILRET = 4
    MASKCALL = 1 << HOOKCALL
    MASKRET = 1 << HOOKRET
    MASKLINE = 1 << HOOKLINE

    # 
    #    * Bitmask that specifies count hook in call to {@link #setHook}.
    #    
    MASKCOUNT = 1 << HOOKCOUNT

    # 
    #    * Calls a Lua value.  Normally this is called on functions, but the
    #    * semantics of Lua permit calls on any value as long as its metatable
    #    * permits it.
    #    *
    #    * In order to call a function, the function must be
    #    * pushed onto the stack, then its arguments must be
    #    * {@link #push pushed} onto the stack; the first argument is pushed
    #    * directly after the function,
    #    * then the following arguments are pushed in order (direct
    #    * order).  The parameter <var>nargs</var> specifies the number of
    #    * arguments (which may be 0).
    #    *
    #    * When the function returns the function value on the stack and all
    #    * the arguments are removed from the stack and replaced with the
    #    * results of the function, adjusted to the number specified by
    #    * <var>nresults</var>.  So the first result from the function call will
    #    * be at the same index where the function was immediately prior to
    #    * calling this method.
    #    *
    #    * @param nargs     The number of arguments in this function call.
    #    * @param nresults  The number of results required.
    #    
    def call(self, nargs, nresults):
        """ generated source for method call """
        apiChecknelems(nargs + 1)
        func = self.stackSize - (nargs + 1)
        self.vmCall(func, nresults)

    # 
    #    * Closes a Lua state.  In this implementation, this method does
    #    * nothing.
    #    
    def close(self):
        """ generated source for method close """

    # 
    #    * Concatenate values (usually strings) on the stack.
    #    * <var>n</var> values from the top of the stack are concatenated, as
    #    * strings, and replaced with the resulting string.
    #    * @param n  the number of values to concatenate.
    #    
    def concat(self, n):
        """ generated source for method concat """
        apiChecknelems(n)
        if n >= 2:
            vmConcat(n, (self.stackSize - self.base) - 1)
            pop(n - 1)
        elif n == 0:
            #  push empty string
            push("")
        #  else n == 1; nothing to do

    # 
    #    * Creates a new empty table and returns it.
    #    * @param narr  number of array elements to pre-allocate.
    #    * @param nrec  number of non-array elements to pre-allocate.
    #    * @return a fresh table.
    #    * @see #newTable
    #    
    def createTable(self, narr, nrec):
        """ generated source for method createTable """
        return LuaTable(narr, nrec)

    # 
    #    * Dumps a function as a binary chunk.
    #    * @param function  the Lua function to dump.
    #    * @param writer    the stream that receives the dumped binary.
    #    * @throws IOException when writer does.
    #    
    @classmethod
    def dump(cls, function_, writer):
        """ generated source for method dump """
        if not (isinstance(function_, (LuaFunction, ))):
            raise IOError("Cannot dump " + typeName(type_(function_)))
        f = function_
        uDump(f.proto(), writer, False)

    # 
    #    * Tests for equality according to the semantics of Lua's
    #    * <code>==</code> operator (so may call metamethods).
    #    * @param o1  a Lua value.
    #    * @param o2  another Lua value.
    #    * @return true when equal.
    #    
    def equal(self, o1, o2):
        """ generated source for method equal """
        if isinstance(o1, (float, )):
            return o1 == o2
        return vmEqualRef(o1, o2)

    # 
    #    * Generates a Lua error using the error message.
    #    * @param message  the error message.
    #    * @return never.
    #    
    def error(self, message):
        """ generated source for method error """
        return gErrormsg(message)

    # 
    #    * Control garbage collector.  Note that in Jill most of the options
    #    * to this function make no sense and they will not do anything.
    #    * @param what  specifies what GC action to take.
    #    * @param data  data that may be used by the action.
    #    * @return varies.
    #    
    def gc(self, what, data):
        """ generated source for method gc """
        rt = None
        if what == self.GCSTOP:
            return 0
        elif what == self.GCRESTART:
            pass
        elif what == self.GCCOLLECT:
            pass
        elif what == self.GCSTEP:
            System.gc()
            return 0
        elif what == self.GCCOUNT:
            rt = Runtime.getRuntime()
            return int(((rt.totalMemory() - rt.freeMemory()) / 1024))
        elif what == self.GCCOUNTB:
            rt = Runtime.getRuntime()
            return int(((rt.totalMemory() - rt.freeMemory()) % 1024))
        elif what == self.GCSETPAUSE:
            pass
        elif what == self.GCSETSTEPMUL:
            return 0
        return 0

    # 
    #    * Returns the environment table of the Lua value.
    #    * @param o  the Lua value.
    #    * @return its environment table.
    #    
    def getFenv(self, o):
        """ generated source for method getFenv """
        if isinstance(o, (LuaFunction, )):
            f = o
            return f.getEnv()
        if isinstance(o, (LuaJavaCallback, )):
            f = o
            #  :todo: implement this case.
            return None
        if isinstance(o, (LuaUserdata, )):
            u = o
            return u.getEnv()
        if isinstance(o, (Lua, )):
            l = o
            return l.global_
        return None

    # 
    #    * Get a field from a table (or other object).
    #    * @param t      The object whose field to retrieve.
    #    * @param field  The name of the field.
    #    * @return  the Lua value
    #    
    def getField(self, t, field):
        """ generated source for method getField """
        return getTable(t, field)

    # 
    #    * Get a global variable.
    #    * @param name  The name of the global variable.
    #    * @return  The value of the global variable.
    #    
    def getGlobal(self, name):
        """ generated source for method getGlobal """
        return self.getField(self.global_, name)

    # 
    #    * Gets the global environment.  The global environment, where global
    #    * variables live, is returned as a <code>LuaTable</code>.  Note that
    #    * modifying this table has exactly the same effect as creating or
    #    * @return  The global environment as a table.
    #    
    def getGlobals(self):
        """ generated source for method getGlobals """
        return self.global_

    #  Get metatable.
    #    * @param o  the Lua value whose metatable to retrieve.
    #    * @return The metatable, or null if there is no metatable.
    #    
    def getMetatable(self, o):
        """ generated source for method getMetatable """
        mt = None
        if isinstance(o, (LuaTable, )):
            t = o
            mt = t.getMetatable()
        elif isinstance(o, (LuaUserdata, )):
            u = o
            mt = u.getMetatable()
        else:
            mt = self.metatable[type_(o)]
        return mt

    # 
    #    * Gets the registry table.
    #    
    def getRegistry(self):
        """ generated source for method getRegistry """
        return self.registry

    # 
    #    * Indexes into a table and returns the value.
    #    * @param t  the Lua value to index.
    #    * @param k  the key whose value to return.
    #    * @return the value t[k].
    #    
    def getTable(self, t, k):
        """ generated source for method getTable """
        s = Slot(k)
        v = Slot()
        vmGettable(t, s, v)
        return v.asObject()

    # 
    #    * Gets the number of elements in the stack.  If the stack is not
    #    * empty then this is the index of the top-most element.
    #    * @return number of stack elements.
    #    
    def getTop(self):
        """ generated source for method getTop """
        return self.stackSize - self.base

    # 
    #    * Insert Lua value into stack immediately at specified index.  Values
    #    * in stack at that index and higher get pushed up.
    #    * @param o    the Lua value to insert into the stack.
    #    * @param idx  the stack index at which to insert.
    #    
    def insert(self, o, idx):
        """ generated source for method insert """
        idx = absIndexUnclamped(idx)
        stackInsertAt(o, idx)

    # 
    #    * Tests that an object is a Lua boolean.
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is a Lua boolean.
    #    
    @classmethod
    def isBoolean(cls, o):
        """ generated source for method isBoolean """
        return isinstance(o, (bool, ))

    # 
    #    * Tests that an object is a Lua function implementated in Java (a Lua
    #    * Java Function).
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is a Lua Java Function.
    #    
    @classmethod
    def isJavaFunction(cls, o):
        """ generated source for method isJavaFunction """
        return isinstance(o, (LuaJavaCallback, ))

    # 
    #    * Tests that an object is a Lua function (implemented in Lua or
    #    * Java).
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is a function.
    #    
    def isFunction(self, o):
        """ generated source for method isFunction """
        # static
        return isinstance(o, (LuaFunction, )) or isinstance(o, (LuaJavaCallback, ))

    # 
    #    * Tests that a Lua thread is the main thread.
    #    * @return true if and only if is the main thread.
    #    
    def isMain(self):
        """ generated source for method isMain """
        return self == self.main

    # 
    #    * Tests that an object is Lua <code>nil</code>.
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is Lua <code>nil</code>.
    #    
    def isNil(self, o):
        """ generated source for method isNil """
        # static
        return self.NIL == o

    # 
    #    * Tests that an object is a Lua number or a string convertible to a
    #    * number.
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is a number or a convertible string.
    #    
    def isNumber(self, o):
        """ generated source for method isNumber """
        # static
        self.SPARE_SLOT.setObject(o)
        return tonumber(self.SPARE_SLOT, NUMOP)

    # 
    #    * Tests that an object is a Lua string or a number (which is always
    #    * convertible to a string).
    #    * @param o  the Object to test.
    #    * @return true if and only if object is a string or number.
    #    
    def isString(self, o):
        """ generated source for method isString """
        # static
        return isinstance(o, (str, )) or isinstance(o, (float, ))

    # 
    #    * Tests that an object is a Lua table.
    #    * @param o  the Object to test.
    #    * @return <code>true</code> if and only if the object is a Lua table.
    #    
    def isTable(self, o):
        """ generated source for method isTable """
        # static
        return isinstance(o, (LuaTable, ))

    # 
    #    * Tests that an object is a Lua thread.
    #    * @param o  the Object to test.
    #    * @return <code>true</code> if and only if the object is a Lua thread.
    #    
    @classmethod
    def isThread(cls, o):
        """ generated source for method isThread """
        return isinstance(o, (Lua, ))

    # 
    #    * Tests that an object is a Lua userdata.
    #    * @param o  the Object to test.
    #    * @return true if and only if the object is a Lua userdata.
    #    
    @classmethod
    def isUserdata(cls, o):
        """ generated source for method isUserdata """
        return isinstance(o, (LuaUserdata, ))

    # 
    #    * <p>
    #    * Tests that an object is a Lua value.  Returns <code>true</code> for
    #    * an argument that is a Jill representation of a Lua value,
    #    * <code>false</code> for Java references that are not Lua values.
    #    * For example <code>isValue(new LuaTable())</code> is
    #    * <code>true</code>, but <code>isValue(new Object[] { })</code> is
    #    * <code>false</code> because Java arrays are not a representation of
    #    * any Lua value.
    #    * </p>
    #    * <p>
    #    * PUC-Rio Lua provides no
    #    * counterpart for this method because in their implementation it is
    #    * impossible to get non Lua values on the stack, whereas in Jill it
    #    * is common to mix Lua values with ordinary, non Lua, Java objects.
    #    * </p>
    #    * @param o  the Object to test.
    #    * @return true if and if it represents a Lua value.
    #    
    @classmethod
    def isValue(cls, o):
        """ generated source for method isValue """
        return o == cls.NIL or isinstance(o, (bool, )) or isinstance(o, (str, )) or isinstance(o, (float, )) or isinstance(o, (LuaFunction, )) or isinstance(o, (LuaJavaCallback, )) or isinstance(o, (LuaTable, )) or isinstance(o, (LuaUserdata, ))

    # 
    #    * Compares two Lua values according to the semantics of Lua's
    #    * <code>&lt;</code> operator, so may call metamethods.
    #    * @param o1  the left-hand operand.
    #    * @param o2  the right-hand operand.
    #    * @return true when <code>o1 < o2</code>.
    #    
    def lessThan(self, o1, o2):
        """ generated source for method lessThan """
        a = Slot(o1)
        b = Slot(o2)
        return vmLessthan(a, b)

    # 
    #    * <p>
    #    * Loads a Lua chunk in binary or source form.
    #    * Comparable to C's lua_load.  If the chunk is determined to be
    #    * binary then it is loaded directly.  Otherwise the chunk is assumed
    #    * to be a Lua source chunk and compilation is required first; the
    #    * <code>InputStream</code> is used to create a <code>Reader</code>
    #    * using the UTF-8 encoding
    #    * (using a second argument of <code>"UTF-8"</code> to the
    #    * {@link java.io.InputStreamReader#InputStreamReader(java.io.InputStream,
    #    * java.lang.String)}
    #    * constructor) and the Lua source is compiled.
    #    * </p>
    #    * <p>
    #    * If successful, The compiled chunk, a Lua function, is pushed onto
    #    * the stack and a zero status code is returned.  Otherwise a non-zero
    #    * status code is returned to indicate an error and the error message
    #    * is pushed onto the stack.
    #    * </p>
    #    * @param in         The binary chunk as an InputStream, for example from
    #    *                   {@link Class#getResourceAsStream}.
    #    * @param chunkname  The name of the chunk.
    #    * @return           A status code.
    #    
    @overloaded
    def load(self, in_, chunkname):
        """ generated source for method load """
        push(LuaInternal(in_, chunkname))
        return pcall(0, 1, None)

    # 
    #    * Loads a Lua chunk in source form.
    #    * Comparable to C's lua_load.  This method takes a {@link
    #    * java.io.Reader} parameter,
    #    * and is normally used to load Lua chunks in source form.
    #    * However, it if the input looks like it is the output from Lua's
    #    * <code>string.dump</code> function then it will be processed as a
    #    * binary chunk.
    #    * In every other respect this method is just like {@link
    #    * #load(InputStream, String)}.
    #    * @param in         The source chunk as a Reader, for example from
    #    *                   <code>java.io.InputStreamReader(Class.getResourceAsStream())</code>.
    #    * @param chunkname  The name of the chunk.
    #    * @return           A status code.
    #    * @see java.io.InputStreamReader
    #    
    @load.register(object, Reader, str)
    def load_0(self, in_, chunkname):
        """ generated source for method load_0 """
        push(LuaInternal(in_, chunkname))
        return pcall(0, 1, None)

    # 
    #    * Slowly get the next key from a table.  Unlike most other functions
    #    * in the API this one uses the stack.  The top-of-stack is popped and
    #    * used to find the next key in the table at the position specified by
    #    * index.  If there is a next key then the key and its value are
    #    * pushed onto the stack and <code>true</code> is returned.
    #    * Otherwise (the end of the table has been reached)
    #    * <code>false</code> is returned.
    #    * @param idx  stack index of table.
    #    * @return  true if and only if there are more keys in the table.
    #    * @deprecated Use {@link #tableKeys} enumeration protocol instead.
    #    
    def next(self, idx):
        """ generated source for method next """
        o = value(idx)
        #  :todo: api check
        t = o
        key = value(-1)
        pop(1)
        e = t.keys()
        if key == self.NIL:
            if e.hasMoreElements():
                key = e.nextElement()
                push(key)
                push(t.getlua(key))
                return True
            return False
        while e.hasMoreElements():
            k = e.nextElement()
            if k == key:
                if e.hasMoreElements():
                    key = e.nextElement()
                    push(key)
                    push(t.getlua(key))
                    return True
                return False
        #  protocol error which we could potentially diagnose.
        return False

    # 
    #    * Creates a new empty table and returns it.
    #    * @return a fresh table.
    #    * @see #createTable
    #    
    def newTable(self):
        """ generated source for method newTable """
        return LuaTable()

    # 
    #    * Creates a new Lua thread and returns it.
    #    * @return a new Lua thread.
    #    
    def newThread(self):
        """ generated source for method newThread """
        return Lua(self)

    # 
    #    * Wraps an arbitrary Java reference in a Lua userdata and returns it.
    #    * @param ref  the Java reference to wrap.
    #    * @return the new LuaUserdata.
    #    
    def newUserdata(self, ref):
        """ generated source for method newUserdata """
        return LuaUserdata(ref)

    # 
    #    * Return the <em>length</em> of a Lua value.  For strings this is
    #    * the string length; for tables, this is result of the <code>#</code>
    #    * operator; for other values it is 0.
    #    * @param o  a Lua value.
    #    * @return its length.
    #    
    def objLen(self, o):
        """ generated source for method objLen """
        # static
        if isinstance(o, (str, )):
            s = str(o)
            return len(s)
        if isinstance(o, (LuaTable, )):
            t = o
            return t.getn()
        if isinstance(o, (float, )):
            return len(length)
        return 0

    # 
    #    * <p>
    #    * Protected {@link #call}.  <var>nargs</var> and
    #    * <var>nresults</var> have the same meaning as in {@link #call}.
    #    * If there are no errors during the call, this method behaves as
    #    * {@link #call}.  Any errors are caught, the error object (usually
    #    * a message) is pushed onto the stack, and a non-zero error code is
    #    * returned.
    #    * </p>
    #    * <p>
    #    * If <var>er</var> is <code>null</code> then the error object that is
    #    * on the stack is the original error object.  Otherwise
    #    * <var>ef</var> specifies an <em>error handling function</em> which
    #    * is called when the original error is generated; its return value
    #    * becomes the error object left on the stack by <code>pcall</code>.
    #    * </p>
    #    * @param nargs     number of arguments.
    #    * @param nresults  number of result required.
    #    * @param ef        error function to call in case of error.
    #    * @return 0 if successful, else a non-zero error code.
    #    
    def pcall(self, nargs, nresults, ef):
        """ generated source for method pcall """
        apiChecknelems(nargs + 1)
        restoreStack = self.stackSize - (nargs + 1)
        #  Most of this code comes from luaD_pcall
        restoreCi = len(self.civ)
        oldnCcalls = self.nCcalls
        old_errfunc = self.errfunc
        self.errfunc = ef
        old_allowhook = self.allowhook
        errorStatus = 0
        try:
            self.call(nargs, nresults)
        except LuaError as e:
            fClose(restoreStack)
            #  close eventual pending closures
            dSeterrorobj(e.errorStatus, restoreStack)
            self.nCcalls = oldnCcalls
            self.civ.setSize(restoreCi)
            ci = self.ci()
            self.base = self.ci.base()
            self.savedpc = self.ci.savedpc()
            self.allowhook = old_allowhook
            errorStatus = e.errorStatus
        except OutOfMemoryError as e:
            fClose(restoreStack)
            #  close eventual pending closures
            dSeterrorobj(self.ERRMEM, restoreStack)
            self.nCcalls = oldnCcalls
            self.civ.setSize(restoreCi)
            ci = self.ci()
            self.base = self.ci.base()
            self.savedpc = self.ci.savedpc()
            self.allowhook = old_allowhook
            errorStatus = self.ERRMEM
        self.errfunc = old_errfunc
        return errorStatus

    # 
    #    * Removes (and discards) the top-most <var>n</var> elements from the stack.
    #    * @param n  the number of elements to remove.
    #    
    def pop(self, n):
        """ generated source for method pop """
        if n < 0:
            raise IllegalArgumentException()
        stacksetsize(self.stackSize - n)

    # 
    #    * Pushes a value onto the stack in preparation for calling a
    #    * function (or returning from one).  See {@link #call} for
    #    * the protocol to be used for calling functions.  See {@link
    #    * #pushNumber} for pushing numbers, and {@link #pushValue} for
    #    * pushing a value that is already on the stack.
    #    * @param o  the Lua value to push.
    #    
    @overloaded
    def push(self, o):
        """ generated source for method push """
        #  see also a private overloaded version of this for Slot.
        stackAdd(o)

    # 
    #    * Push boolean onto the stack.
    #    * @param b  the boolean to push.
    #    
    def pushBoolean(self, b):
        """ generated source for method pushBoolean """
        self.push(valueOfBoolean(b))

    # 
    #    * Push literal string onto the stack.
    #    * @param s  the string to push.
    #    
    def pushLiteral(self, s):
        """ generated source for method pushLiteral """
        self.push(s)

    #  Push nil onto the stack. 
    def pushNil(self):
        """ generated source for method pushNil """
        self.push(self.NIL)

    # 
    #    * Pushes a number onto the stack.  See also {@link #push}.
    #    * @param d  the number to push.
    #    
    def pushNumber(self, d):
        """ generated source for method pushNumber """
        #  :todo: optimise to avoid creating Double instance
        self.push(float(d))

    # 
    #    * Push string onto the stack.
    #    * @param s  the string to push.
    #    
    def pushString(self, s):
        """ generated source for method pushString """
        self.push(s)

    # 
    #    * Copies a stack element onto the top of the stack.
    #    * Equivalent to <code>L.push(L.value(idx))</code>.
    #    * @param idx  stack index of value to push.
    #    
    def pushValue(self, idx):
        """ generated source for method pushValue """
        #  :todo: optimised to avoid creating Double instance
        self.push(value(idx))

    # 
    #    * Implements equality without metamethods.
    #    * @param o1  the first Lua value to compare.
    #    * @param o2  the other Lua value.
    #    * @return  true if and only if they compare equal.
    #    
    def rawEqual(self, o1, o2):
        """ generated source for method rawEqual """
        # static
        return oRawequal(o1, o2)

    # 
    #    * Gets an element from a table, without using metamethods.
    #    * @param t  The table to access.
    #    * @param k  The index (key) into the table.
    #    * @return The value at the specified index.
    #    
    def rawGet(self, t, k):
        """ generated source for method rawGet """
        # static
        table = t
        return table.getlua(k)

    # 
    #    * Gets an element from an array, without using metamethods.
    #    * @param t  the array (table).
    #    * @param i  the index of the element to retrieve.
    #    * @return  the value at the specified index.
    #    
    def rawGetI(self, t, i):
        """ generated source for method rawGetI """
        # static
        table = t
        return table.getnum(i)

    # 
    #    * Sets an element in a table, without using metamethods.
    #    * @param t  The table to modify.
    #    * @param k  The index into the table.
    #    * @param v  The new value to be stored at index <var>k</var>.
    #    
    def rawSet(self, t, k, v):
        """ generated source for method rawSet """
        table = t
        table.putlua(self, k, v)

    # 
    #    * Sets an element in an array, without using metamethods.
    #    * @param t  the array (table).
    #    * @param i  the index of the element to set.
    #    * @param v  the new value to be stored at index <var>i</var>.
    #    
    def rawSetI(self, t, i, v):
        """ generated source for method rawSetI """
        apiCheck(isinstance(t, (LuaTable, )))
        h = t
        h.putnum(i, v)

    # 
    #    * Register a {@link LuaJavaCallback} as the new value of the global
    #    * <var>name</var>.
    #    * @param name  the name of the global.
    #    * @param f     the LuaJavaCallback to register.
    #    
    @overloaded
    def register(self, name, f):
        """ generated source for method register """
        setGlobal(name, f)

    # 
    #    * Starts and resumes a Lua thread.  Threads can be created using
    #    * {@link #newThread}.  Once a thread has begun executing it will
    #    * run until it either completes (with error or normally) or has been
    #    * suspended by invoking {@link #yield}.
    #    * @param narg  Number of values to pass to thread.
    #    
    def resume(self, narg):
        """ generated source for method resume """
        if self.status != self.YIELD:
            if self.status != 0:
                return resume_error("cannot resume dead coroutine")
            elif len(self.civ) != 1:
                return resume_error("cannot resume non-suspended coroutine")
        #  assert errfunc == 0 && nCcalls == 0;
        errorStatus = 0
        try:
            #  This block is equivalent to resume from ldo.c
            firstArg = self.stackSize - narg
            if self.status == 0:
                #  start coroutine?
                #  assert len(civ) == 1 && firstArg > base);
                if vmPrecall(firstArg - 1, self.MULTRET) != PCRLUA:
                    break
            else:
                #  resuming from previous yield
                #  assert status == YIELD;
                self.status = 0
                if not isLua(self.ci()):
                    #  'common' yield
                    #  finish interrupted execution of 'OP_CALL'
                    #  assert ...
                    if vmPoscall(firstArg):
                        stacksetsize(self.ci().top())
                    #  and correct top
                else:
                    self.base = self.ci().base()
            vmExecute(len(self.civ) - 1)
        except LuaError as e:
            self.status = e.errorStatus
            #  mark thread as 'dead'
            dSeterrorobj(e.errorStatus, self.stackSize)
            self.ci().setTop(self.stackSize)
        return self.status

    # 
    #    * Set the environment for a function, thread, or userdata.
    #    * @param o      Object whose environment will be set.
    #    * @param table  Environment table to use.
    #    * @return true if the object had its environment set, false otherwise.
    #    
    def setFenv(self, o, table):
        """ generated source for method setFenv """
        #  :todo: consider implementing common env interface for
        #  LuaFunction, LuaJavaCallback, LuaUserdata, Lua.  One cast to an
        #  interface and an interface method call may be shorter
        #  than this mess.
        t = table
        if isinstance(o, (LuaFunction, )):
            f = o
            f.setEnv(t)
            return True
        if isinstance(o, (LuaJavaCallback, )):
            f = o
            #  :todo: implement this case.
            return False
        if isinstance(o, (LuaUserdata, )):
            u = o
            u.setEnv(t)
            return True
        if isinstance(o, (Lua, )):
            l = o
            l.global_ = t
            return True
        return False

    # 
    #    * Set a field in a Lua value.
    #    * @param t     Lua value of which to set a field.
    #    * @param name  Name of field to set.
    #    * @param v     new Lua value for field.
    #    
    def setField(self, t, name, v):
        """ generated source for method setField """
        s = Slot(name)
        vmSettable(t, s, v)

    # 
    #    * Sets the metatable for a Lua value.
    #    * @param o   Lua value of which to set metatable.
    #    * @param mt  The new metatable.
    #    
    def setMetatable(self, o, mt):
        """ generated source for method setMetatable """
        if self.isNil(mt):
            mt = None
        else:
            apiCheck(isinstance(mt, (LuaTable, )))
        mtt = mt
        if isinstance(o, (LuaTable, )):
            t = o
            t.setMetatable(mtt)
        elif isinstance(o, (LuaUserdata, )):
            u = o
            u.setMetatable(mtt)
        else:
            self.metatable[type_(o)] = mtt

    # 
    #    * Set a global variable.
    #    * @param name   name of the global variable to set.
    #    * @param value  desired new value for the variable.
    #    
    def setGlobal(self, name, value):
        """ generated source for method setGlobal """
        s = Slot(name)
        vmSettable(self.global_, s, value)

    # 
    #    * Does the equivalent of <code>t[k] = v</code>.
    #    * @param t  the table to modify.
    #    * @param k  the index to modify.
    #    * @param v  the new value at index <var>k</var>.
    #    
    def setTable(self, t, k, v):
        """ generated source for method setTable """
        s = Slot(k)
        vmSettable(t, s, v)

    # 
    #    * Set the stack top.
    #    * @param n  the desired size of the stack (in elements).
    #    
    def setTop(self, n):
        """ generated source for method setTop """
        if n < 0:
            raise IllegalArgumentException()
        stacksetsize(self.base + n)

    # 
    #    * Status of a Lua thread.
    #    
    def status(self):
        """ generated source for method status """
        return self.status

    # 
    #    * Returns an {@link java.util.Enumeration} for the keys of a table.
    #    * @param t  a Lua table.
    #    * @return an Enumeration object.
    #    
    def tableKeys(self, t):
        """ generated source for method tableKeys """
        if not (isinstance(t, (LuaTable, ))):
            self.error("table required")
            #  NOTREACHED
        return (t).keys()

    # 
    #    * Convert to boolean.
    #    * @param o  Lua value to convert.
    #    * @return  the resulting primitive boolean.
    #    
    def toBoolean(self, o):
        """ generated source for method toBoolean """
        return not (o == self.NIL or Boolean.FALSE == o)

    # 
    #    * Convert to integer and return it.  Returns 0 if cannot be
    #    * converted.
    #    * @param o  Lua value to convert.
    #    * @return  the resulting int.
    #    
    def toInteger(self, o):
        """ generated source for method toInteger """
        return int(toNumber(o))

    # 
    #    * Convert to number and return it.  Returns 0 if cannot be
    #    * converted.
    #    * @param o  Lua value to convert.
    #    * @return  The resulting number.
    #    
    def toNumber(self, o):
        """ generated source for method toNumber """
        self.SPARE_SLOT.setObject(o)
        if tonumber(self.SPARE_SLOT, NUMOP):
            return NUMOP[0]
        return 0

    # 
    #    * Convert to string and return it.  If value cannot be converted then
    #    * <code>null</code> is returned.  Note that unlike
    #    * <code>lua_tostring</code> this
    #    * does not modify the Lua value.
    #    * @param o  Lua value to convert.
    #    * @return  The resulting string.
    #    
    def __str__(self, o):
        """ generated source for method toString """
        return vmTostring(o)

    # 
    #    * Convert to Lua thread and return it or <code>null</code>.
    #    * @param o  Lua value to convert.
    #    * @return  The resulting Lua instance.
    #    
    def toThread(self, o):
        """ generated source for method toThread """
        if not (isinstance(o, (Lua, ))):
            return None
        return o

    # 
    #    * Convert to userdata or <code>null</code>.  If value is a {@link
    #    * LuaUserdata} then it is returned, otherwise, <code>null</code> is
    #    * returned.
    #    * @param o  Lua value.
    #    * @return  value as userdata or <code>null</code>.
    #    
    def toUserdata(self, o):
        """ generated source for method toUserdata """
        if isinstance(o, (LuaUserdata, )):
            return o
        return None

    # 
    #    * Type of the Lua value at the specified stack index.
    #    * @param idx  stack index to type.
    #    * @return  the type, or {@link #TNONE} if there is no value at <var>idx</var>
    #    
    @overloaded
    def type_(self, idx):
        """ generated source for method type_ """
        idx = absIndex(idx)
        if idx < 0:
            return self.TNONE
        return self.type_(self.stack[idx])

    @type_.register(object, Slot)
    def type__0(self, s):
        """ generated source for method type__0 """
        if s.r == self.NUMBER:
            return self.TNUMBER
        return self.type_(s.r)

    # 
    #    * Type of a Lua value.
    #    * @param o  the Lua value whose type to return.
    #    * @return  the Lua type from an enumeration.
    #    
    @classmethod
    @type_.register(object, object)
    def type__1(cls, o):
        """ generated source for method type__1 """
        if o == cls.NIL:
            return cls.TNIL
        elif isinstance(o, (float, )):
            return cls.TNUMBER
        elif isinstance(o, (bool, )):
            return cls.TBOOLEAN
        elif isinstance(o, (str, )):
            return cls.TSTRING
        elif isinstance(o, (LuaTable, )):
            return cls.TTABLE
        elif isinstance(o, (LuaFunction, )) or isinstance(o, (LuaJavaCallback, )):
            return cls.TFUNCTION
        elif isinstance(o, (LuaUserdata, )):
            return cls.TUSERDATA
        elif isinstance(o, (Lua, )):
            return cls.TTHREAD
        return cls.TNONE

    # 
    #    * Name of type.
    #    * @param type  a Lua type from, for example, {@link #type}.
    #    * @return  the type's name.
    #    
    @classmethod
    def typeName(cls, type_):
        """ generated source for method typeName """
        if cls.TNONE == type_:
            return "no value"
        return cls.TYPENAME[type_]

    # 
    #    * Gets a value from the stack.
    #    * If <var>idx</var> is positive and exceeds
    #    * the size of the stack, {@link #NIL} is returned.
    #    * @param idx  the stack index of the value to retrieve.
    #    * @return  the Lua value from the stack.
    #    
    def value(self, idx):
        """ generated source for method value """
        idx = absIndex(idx)
        if idx < 0:
            return self.NIL
        if self.D:
            System.err.println("value:" + idx)
        return self.stack[idx].asObject()

    @classmethod
    def valueOfBoolean(cls, b):
        """ generated source for method valueOfBoolean """
        if b:
            return Boolean.TRUE
        else:
            return Boolean.FALSE

    @classmethod
    def valueOfNumber(cls, d):
        """ generated source for method valueOfNumber """
        return float(d)

    def xmove(self, to, n):
        """ generated source for method xmove """
        if self == to:
            return
        apiChecknelems(n)
        i = 0
        while i < n:
            to.push(self.value(-n + i))
            i += 1
        self.pop(n)

    def yield_(self, nresults):
        """ generated source for method yield_ """
        if self.nCcalls > 0:
            gRunerror("attempt to yield across metamethod/Java-call boundary")
        self.base = self.stackSize - nresults
        self.status = self.YIELD
        return -1

    def absIndex(self, idx):
        """ generated source for method absIndex """
        s = self.stackSize
        if idx == 0:
            return -1
        if idx > 0:
            if idx + self.base > s:
                return -1
            return self.base + idx - 1
        if s + idx < self.base:
            return -1
        return s + idx

    def absIndexUnclamped(self, idx):
        """ generated source for method absIndexUnclamped """
        if idx == 0:
            return -1
        if idx > 0:
            return self.base + idx - 1
        return self.stackSize + idx

    def apiCheck(self, cond):
        """ generated source for method apiCheck """
        if not cond:
            raise IllegalArgumentException()

    def apiChecknelems(self, n):
        """ generated source for method apiChecknelems """
        self.apiCheck(n <= self.stackSize - self.base)

    def argCheck(self, cond, numarg, extramsg):
        """ generated source for method argCheck """
        if cond:
            return
        argError(numarg, extramsg)

    def argError(self, narg, extramsg):
        """ generated source for method argError """
        return self.error("bad argument " + narg + " (" + extramsg + ")")

    def callMeta(self, obj, event):
        """ generated source for method callMeta """
        o = self.value(obj)
        ev = getMetafield(o, event)
        if ev == self.NIL:
            return False
        self.push(ev)
        self.push(o)
        self.call(1, 1)
        return True

    def checkAny(self, narg):
        """ generated source for method checkAny """
        if self.type_(narg) == self.TNONE:
            self.argError(narg, "value expected")

    def checkInt(self, narg):
        """ generated source for method checkInt """
        return int(checkNumber(narg))

    def checkNumber(self, narg):
        """ generated source for method checkNumber """
        o = self.value(narg)
        d = self.toNumber(o)
        if d == 0 and not self.isNumber(o):
            tagError(narg, self.TNUMBER)
        return d

    def checkOption(self, narg, def_, lst):
        """ generated source for method checkOption """
        name = None
        if def_ == None:
            name = checkString(narg)
        else:
            name = optString(narg, def_)
        i = 0
        while len(lst):
            if lst[i] == name:
                return i
            i += 1
        return self.argError(narg, "invalid option '" + name + "'")

    def checkString(self, narg):
        """ generated source for method checkString """
        s = self.toString(self.value(narg))
        if s == None:
            tagError(narg, self.TSTRING)
        return s

    def checkType(self, narg, t):
        """ generated source for method checkType """
        if self.type_(narg) != t:
            tagError(narg, t)

    def doString(self, s):
        """ generated source for method doString """
        status = self.load(Lua.stringReader(s), s)
        if status == 0:
            status = self.pcall(0, self.MULTRET, None)
        return status

    def errfile(self, what, fname, e):
        """ generated source for method errfile """
        self.push("cannot " + what + " " + fname + ": " + e.__str__())
        return self.ERRFILE

    def findTable(self, t, fname, szhint):
        """ generated source for method findTable """
        e = 0
        i = 0
        while True:
            e = fname.indexOf('.', i)
            part = None
            if e < 0:
                part = fname.substring(i)
            else:
                part = fname.substring(i, e)
            v = self.rawGet(t, part)
            if self.isNil(v):
                v = self.createTable(0, 1 if (e >= 0) else szhint)
                self.setTable(t, part, v)
            elif not self.isTable(v):
                return part
            t = v
            i = e + 1
            if not ((e >= 0)):
                break
        self.push(t)
        return None

    def getMetafield(self, o, event):
        """ generated source for method getMetafield """
        mt = self.getMetatable(o)
        if mt == None:
            return self.NIL
        return mt.getlua(event)

    def isNoneOrNil(self, narg):
        """ generated source for method isNoneOrNil """
        return self.type_(narg) <= self.TNIL

    def loadFile(self, filename):
        """ generated source for method loadFile """
        if filename == None:
            raise NullPointerException()
        in_ = getClass().getResourceAsStream(filename)
        if in_ == None:
            return self.errfile("open", filename, IOError())
        status = 0
        try:
            in_.mark(1)
            c = in_.read()
            if c == '#':
            in_.reset()
            status = self.load(in_, "@" + filename)
        except IOError as e:
            return self.errfile("read", filename, e)
        return status

    def loadString(self, s, chunkname):
        """ generated source for method loadString """
        return self.load(stringReader(s), chunkname)

    def optInt(self, narg, def_):
        """ generated source for method optInt """
        if self.isNoneOrNil(narg):
            return def_
        return self.checkInt(narg)

    def optNumber(self, narg, def_):
        """ generated source for method optNumber """
        if self.isNoneOrNil(narg):
            return def_
        return self.checkNumber(narg)

    def optString(self, narg, def_):
        """ generated source for method optString """
        if self.isNoneOrNil(narg):
            return def_
        return self.checkString(narg)

    @register.register(object, str)
    def register_0(self, name):
        """ generated source for method register_0 """
        self.findTable(self.getRegistry(), self.LOADED, 1)
        loaded = self.value(-1)
        self.pop(1)
        t = self.getField(loaded, name)
        if not self.isTable(t):
            if self.findTable(self.getGlobals(), name, 0) != None:
                self.error("name conflict for module '" + name + "'")
            t = self.value(-1)
            self.pop(1)
            self.setField(loaded, name, t)
        return t

    def tagError(self, narg, tag):
        """ generated source for method tagError """
        typerror(narg, self.typeName(tag))

    def typeNameOfIndex(self, idx):
        """ generated source for method typeNameOfIndex """
        return self.TYPENAME[self.type_(idx)]

    def typerror(self, narg, tname):
        """ generated source for method typerror """
        self.argError(narg, tname + " expected, got " + self.typeNameOfIndex(narg))

    def where(self, level):
        """ generated source for method where """
        ar = getStack(level)
        if ar != None:
            getInfo("Sl", ar)
            if ar.currentline() > 0:
                return ar.shortsrc() + ":" + ar.currentline() + ": "
        return ""

    @classmethod
    def stringReader(cls, s):
        """ generated source for method stringReader """
        return StringReader(s)

    def getInfo(self, what, ar):
        """ generated source for method getInfo """
        f = None
        callinfo = None
        if ar.ici() > 0:
            callinfo = self.civ.elementAt(ar.ici())
            f = self.stack[callinfo.function_()].r
        status = auxgetinfo(what, ar, f, callinfo)
        if what.indexOf('f') >= 0:
            if f == None:
                self.push(self.NIL)
            else:
                self.push(f)
        return status

    def getStack(self, level):
        """ generated source for method getStack """
        ici = int()
        while level > 0 and ici > 0:
            ci = self.civ.elementAt(ici)
            level -= 1
            if isLua(self.ci):
                level -= self.ci.tailcalls()
            ici -= 1
        if level == 0 and ici > 0:
            return Debug(ici)
        elif level < 0:
            return Debug(0)
        return None

    def setHook(self, func, mask, count):
        """ generated source for method setHook """
        if func == None or mask == 0:
            mask = 0
            func = None
        self.hook = func
        self.basehookcount = count
        resethookcount()
        self.hookmask = mask

    def auxgetinfo(self, what, ar, f, ci):
        """ generated source for method auxgetinfo """
        status = True
        if f == None:
            return status
        i = 0
        while i < len(what):
            if what.charAt(i) == 'S':
                funcinfo(ar, f)
            elif what.charAt(i) == 'l':
                ar.setCurrentline(currentline(ci) if (ci != None) else -1)
            elif what.charAt(i) == 'f':
            else:
                status = False
            i += 1
        return status

    def currentline(self, ci):
        """ generated source for method currentline """
        pc = currentpc(ci)
        if pc < 0:
            return -1
        else:
            faso = self.stack[ci.function_()].r
            f = faso
            return f.proto().getline(pc)

    def currentpc(self, ci):
        """ generated source for method currentpc """
        if not isLua(ci):
            return -1
        if ci == ci():
            ci.setSavedpc(self.savedpc)
        return pcRel(ci.savedpc())

    def funcinfo(self, ar, cl):
        """ generated source for method funcinfo """
        if isinstance(cl, (LuaJavaCallback, )):
            ar.setSource("=[Java]")
            ar.setLinedefined(-1)
            ar.setLastlinedefined(-1)
            ar.setWhat("Java")
        else:
            p = (cl).proto()
            ar.setSource(p.source())
            ar.setLinedefined(p.linedefined())
            ar.setLastlinedefined(p.lastlinedefined())
            ar.setWhat("main" if ar.linedefined() == 0 else "Lua")

    def isLua(self, callinfo):
        """ generated source for method isLua """
        f = self.stack[callinfo.function_()].r
        return isinstance(f, (LuaFunction, ))

    @classmethod
    def pcRel(cls, pc):
        """ generated source for method pcRel """
        return pc - 1

    def dCallhook(self, event, line):
        """ generated source for method dCallhook """
        hook = self.hook
        if hook != None and self.allowhook:
            top = self.stackSize
            ci_top = self.ci().top()
            ici = len(self.civ) - 1
            if event == self.HOOKTAILRET:
                ici = 0
            ar = Debug(ici)
            ar.setEvent(event)
            ar.setCurrentline(line)
            self.ci().setTop(self.stackSize)
            self.allowhook = False
            hook.luaHook(self, ar)
            self.allowhook = True
            self.ci().setTop(ci_top)
            stacksetsize(top)

    MEMERRMSG = "not enough memory"

    def dSeterrorobj(self, errcode, oldtop):
        """ generated source for method dSeterrorobj """
        msg = objectAt(self.stackSize - 1)
        if self.stackSize == oldtop:
            stacksetsize(oldtop + 1)
        if errcode == self.ERRMEM:
            if self.D:
                System.err.println("dSeterrorobj:" + oldtop)
            self.stack[oldtop].r = self.MEMERRMSG
        elif errcode == self.ERRERR:
            if self.D:
                System.err.println("dSeterrorobj:" + oldtop)
            self.stack[oldtop].r = "error in error handling"
        elif errcode == self.ERRFILE:
            pass
        elif errcode == self.ERRRUN:
            pass
        elif errcode == self.ERRSYNTAX:
            setObjectAt(msg, oldtop)
        stacksetsize(oldtop + 1)

    def dThrow(self, status):
        """ generated source for method dThrow """
        raise LuaError(status)

    def fClose(self, level):
        """ generated source for method fClose """
        i = len(self.openupval)
        i -= 1
        while i >= 0:
            uv = self.openupval.elementAt(i)
            if uv.offset() < level:
                break
            uv.close()
        self.openupval.setSize(i + 1)
        return

    def fFindupval(self, idx):
        """ generated source for method fFindupval """
        i = len(self.openupval)
        i -= 1
        while i >= 0:
            uv = self.openupval.elementAt(i)
            if uv.offset() == idx:
                return uv
            if uv.offset() < idx:
                break
        uv = UpVal(idx, self.stack[idx])
        self.openupval.insertElementAt(uv, i + 1)
        return uv

    def gAritherror(self, p1, p2):
        """ generated source for method gAritherror """
        if not tonumber(p1, NUMOP):
            p2 = p1
        gTypeerror(p2, "perform arithmetic on")

    def gConcaterror(self, p1, p2):
        """ generated source for method gConcaterror """
        if isinstance(, (str, )):
            p1 = p2
        gTypeerror(self.stack[p1], "concatenate")

    def gCheckcode(self, p):
        """ generated source for method gCheckcode """
        return True

    def gErrormsg(self, message):
        """ generated source for method gErrormsg """
        self.push(message)
        if self.errfunc != None:
            if not self.isFunction(self.errfunc):
                self.dThrow(self.ERRERR)
            self.insert(self.errfunc, self.getTop())
            vmCall(self.stackSize - 2, 1)
        self.dThrow(self.ERRRUN)
        return 0

    def gOrdererror(self, p1, p2):
        """ generated source for method gOrdererror """
        t1 = self.typeName(self.type_(p1))
        t2 = self.typeName(self.type_(p2))
        if t1.charAt(2) == t2.charAt(2):
            gRunerror("attempt to compare two " + t1 + "values")
        else:
            gRunerror("attempt to compare " + t1 + " with " + t2)
        return False

    def gRunerror(self, s):
        """ generated source for method gRunerror """
        self.gErrormsg(s)

    @overloaded
    def gTypeerror(self, o, op):
        """ generated source for method gTypeerror """
        t = self.typeName(self.type_(o))
        self.gRunerror("attempt to " + op + " a " + t + " value")

    @gTypeerror.register(object, Slot, str)
    def gTypeerror_0(self, p, op):
        """ generated source for method gTypeerror_0 """
        self.gTypeerror(p.asObject(), op)

    IDSIZE = 60

    @classmethod
    def oChunkid(cls, source):
        """ generated source for method oChunkid """
        len = cls.IDSIZE
        if source.startsWith("="):
            if cls.IDSIZE + 1 < len(source):
                return source.substring(1)
            else:
                return source.substring(1, 1 + len)
        if source.startsWith("@"):
            source = source.substring(1)
            len -= len(length)
            l = len(source)
            if l > len:
                return "..." + source.substring(len - len(source), len(source))
            return source
        l = source.indexOf('\n')
        if l == -1:
            l = len(source)
        len -= len(length)
        if l > len:
            l = len
        buf = StringBuffer()
        buf.append("[string \"")
        buf.append(source.substring(0, l))
        if l > len(source):
            buf.append("...")
        buf.append("\"]")
        return buf.__str__()

    @classmethod
    def oFb2int(cls, x):
        """ generated source for method oFb2int """
        e = (bsr(x, 3)) & 31
        if e == 0:
            return x
        return ((x & 7) + 8) << (e - 1)

    @classmethod
    def oRawequal(cls, a, b):
        """ generated source for method oRawequal """
        if cls.NIL == a:
            return cls.NIL == b
        return a == b

    @classmethod
    def oStr2d(cls, s, out):
        """ generated source for method oStr2d """
        try:
            out[0] = Double.parseDouble(s)
            return True
        except NumberFormatException as e0_:
            try:
                s = s.trim().toUpperCase()
                if s.startsWith("0X"):
                    s = s.substring(2)
                elif s.startsWith("-0X"):
                    s = "-" + s.substring(3)
                else:
                    return False
                out[0] = Integer.parseInt(s, 16)
                return True
            except NumberFormatException as e1_:
                return False

    PCRLUA = 0
    PCRJ = 1
    PCRYIELD = 2
    NO_REG = 0xff

    @classmethod
    def OPCODE(cls, instruction):
        """ generated source for method OPCODE """
        return instruction & 0x3f

    @classmethod
    def SET_OPCODE(cls, i, op):
        """ generated source for method SET_OPCODE """
        return (i & ~0x3F) | (op & 0x3F)

    @classmethod
    def ARGA(cls, instruction):
        """ generated source for method ARGA """
        return (bsr(instruction, 6)) & 0xff

    @classmethod
    def SETARG_A(cls, i, u):
        """ generated source for method SETARG_A """
        return (i & ~(0xff << 6)) | ((u & 0xff) << 6)

    @classmethod
    def ARGB(cls, instruction):
        """ generated source for method ARGB """
        return (bsr(instruction, 23))

    @classmethod
    def SETARG_B(cls, i, b):
        """ generated source for method SETARG_B """
        return (i & ~(0x1ff << 23)) | ((b & 0x1ff) << 23)

    @classmethod
    def ARGC(cls, instruction):
        """ generated source for method ARGC """
        return (bsr(instruction, 14)) & 0x1ff

    @classmethod
    def SETARG_C(cls, i, c):
        """ generated source for method SETARG_C """
        return (i & ~(0x1ff << 14)) | ((c & 0x1ff) << 14)

    @classmethod
    def ARGBx(cls, instruction):
        """ generated source for method ARGBx """
        return (bsr(instruction, 14))

    @classmethod
    def SETARG_Bx(cls, i, bx):
        """ generated source for method SETARG_Bx """
        return (i & 0x3fff) | (bx << 14)

    @classmethod
    def ARGsBx(cls, instruction):
        """ generated source for method ARGsBx """
        return (bsr(instruction, 14)) - MAXARG_sBx

    @classmethod
    def SETARG_sBx(cls, i, bx):
        """ generated source for method SETARG_sBx """
        return (i & 0x3fff) | ((bx + MAXARG_sBx) << 14)

    @classmethod
    def ISK(cls, field):
        """ generated source for method ISK """
        return field >= 0x100

    @overloaded
    def RK(self, k, field):
        """ generated source for method RK """
        if self.ISK(field):
            if self.D:
                System.err.println("RK:" + field)
            return k[field & 0xff]
        if self.D:
            System.err.println("RK:" + (self.base + field))
        return self.stack[self.base + field]

    @RK.register(object, int)
    def RK_0(self, field):
        """ generated source for method RK_0 """
        function_ = self.stack[self.ci().function_()].r
        k = function_.proto().constant()
        return self.RK(k, field)

    @classmethod
    def CREATE_ABC(cls, o, a, b, c):
        """ generated source for method CREATE_ABC """
        return o | (a << 6) | (b << 23) | (c << 14)

    @classmethod
    def CREATE_ABx(cls, o, a, bc):
        """ generated source for method CREATE_ABx """
        return o | (a << 6) | (bc << 14)

    OP_MOVE = 0
    OP_LOADK = 1
    OP_LOADBOOL = 2
    OP_LOADNIL = 3
    OP_GETUPVAL = 4
    OP_GETGLOBAL = 5
    OP_GETTABLE = 6
    OP_SETGLOBAL = 7
    OP_SETUPVAL = 8
    OP_SETTABLE = 9
    OP_NEWTABLE = 10
    OP_SELF = 11
    OP_ADD = 12
    OP_SUB = 13
    OP_MUL = 14
    OP_DIV = 15
    OP_MOD = 16
    OP_POW = 17
    OP_UNM = 18
    OP_NOT = 19
    OP_LEN = 20
    OP_CONCAT = 21
    OP_JMP = 22
    OP_EQ = 23
    OP_LT = 24
    OP_LE = 25
    OP_TEST = 26
    OP_TESTSET = 27
    OP_CALL = 28
    OP_TAILCALL = 29
    OP_RETURN = 30
    OP_FORLOOP = 31
    OP_FORPREP = 32
    OP_TFORLOOP = 33
    OP_SETLIST = 34
    OP_CLOSE = 35
    OP_CLOSURE = 36
    OP_VARARG = 37
    SIZE_C = 9
    SIZE_B = 9
    SIZE_Bx = SIZE_C + SIZE_B
    SIZE_A = 8
    SIZE_OP = 6
    POS_OP = 0
    POS_A = POS_OP + SIZE_OP
    POS_C = POS_A + SIZE_A
    POS_B = POS_C + SIZE_C
    POS_Bx = POS_C
    MAXARG_Bx = (1 << SIZE_Bx) - 1
    MAXARG_sBx = MAXARG_Bx >> 1
    MAXARG_A = (1 << SIZE_A) - 1
    MAXARG_B = (1 << SIZE_B) - 1
    MAXARG_C = (1 << SIZE_C) - 1
    BITRK = 1 << (SIZE_B - 1)
    MAXINDEXRK = BITRK - 1

    def vmCall(self, func, r):
        """ generated source for method vmCall """
        self.nCcalls += 1
        if vmPrecall(func, r) == self.PCRLUA:
            vmExecute(1)
        self.nCcalls -= 1

    def vmConcat(self, total, last):
        """ generated source for method vmConcat """
        while True:
            top = self.base + last + 1
            n = 2
            if not tostring(top - 2) or not tostring(top - 1):
                if self.D:
                    System.err.println("vmConcat:" + (top - 2) + "," + (top - 1))
                if not call_binTM(self.stack[top - 2], self.stack[top - 1], self.stack[top - 2], "__concat"):
                    self.gConcaterror(top - 2, top - 1)
            elif 0 > len(length):
                tl = len(length)
                while n < total and tostring(top - n - 1):
                    tl += len(length)
                    if tl < 0:
                        self.gRunerror("string length overflow")
                    n += 1
                buffer_ = StringBuffer(tl)
                i = n
                while i > 0:
                    buffer_.append(self.stack[top - i].r)
                    i -= 1
                self.stack[top - n].r = buffer_.__str__()
            total -= n - 1
            last -= n - 1
            if not ((total > 1)):
                break

    def vmEqual(self, a, b):
        """ generated source for method vmEqual """
        if self.NUMBER == a.r:
            if self.NUMBER != b.r:
                return False
            return a.d == b.d
        return vmEqualRef(a.r, b.r)

    def vmEqualRef(self, a, b):
        """ generated source for method vmEqualRef """
        if a == b:
            return True
        if a.__class__ != b.__class__:
            return False
        if isinstance(a, (LuaJavaCallback, )) or isinstance(a, (LuaTable, )):
            tm = get_compTM(self.getMetatable(a), self.getMetatable(b), "__eq")
            if self.NIL == tm:
                return False
            s = Slot()
            callTMres(s, tm, a, b)
            return not isFalse(s.r)
        return False

    NUMOP = [None] * 2

    @classmethod
    def getOpcodeName(cls, code_):
        """ generated source for method getOpcodeName """
        name = ""
        if code_ == cls.OP_MOVE:
            name = "OP_MOVE"
        elif code_ == cls.OP_LOADK:
            name = "OP_LOADK"
        elif code_ == cls.OP_LOADBOOL:
            name = "OP_LOADBOOL"
        elif code_ == cls.OP_LOADNIL:
            name = "OP_LOADNIL"
        elif code_ == cls.OP_GETUPVAL:
            name = "OP_GETUPVAL"
        elif code_ == cls.OP_GETGLOBAL:
            name = "OP_GETGLOBAL"
        elif code_ == cls.OP_GETTABLE:
            name = "OP_GETTABLE"
        elif code_ == cls.OP_SETGLOBAL:
            name = "OP_SETGLOBAL"
        elif code_ == cls.OP_SETUPVAL:
            name = "OP_SETUPVAL"
        elif code_ == cls.OP_SETTABLE:
            name = "OP_SETTABLE"
        elif code_ == cls.OP_NEWTABLE:
            name = "OP_NEWTABLE"
        elif code_ == cls.OP_SELF:
            name = "OP_SELF"
        elif code_ == cls.OP_ADD:
            name = "OP_ADD"
        elif code_ == cls.OP_SUB:
            name = "OP_SUB"
        elif code_ == cls.OP_MUL:
            name = "OP_MUL"
        elif code_ == cls.OP_DIV:
            name = "OP_DIV"
        elif code_ == cls.OP_MOD:
            name = "OP_MOD"
        elif code_ == cls.OP_POW:
            name = "OP_POW"
        elif code_ == cls.OP_UNM:
            name = "OP_UNM"
        elif code_ == cls.OP_NOT:
            name = "OP_NOT"
        elif code_ == cls.OP_LEN:
            name = "OP_LEN"
        elif code_ == cls.OP_CONCAT:
            name = "OP_CONCAT"
        elif code_ == cls.OP_JMP:
            name = "OP_JMP"
        elif code_ == cls.OP_EQ:
            name = "OP_EQ"
        elif code_ == cls.OP_LT:
            name = "OP_LT"
        elif code_ == cls.OP_LE:
            name = "OP_LE"
        elif code_ == cls.OP_TEST:
            name = "OP_TEST"
        elif code_ == cls.OP_TESTSET:
            name = "OP_TESTSET"
        elif code_ == cls.OP_CALL:
            name = "OP_CALL"
        elif code_ == cls.OP_TAILCALL:
            name = "OP_TAILCALL"
        elif code_ == cls.OP_RETURN:
            name = "OP_RETURN"
        elif code_ == cls.OP_FORLOOP:
            name = "OP_FORLOOP"
        elif code_ == cls.OP_FORPREP:
            name = "OP_FORPREP"
        elif code_ == cls.OP_TFORLOOP:
            name = "OP_TFORLOOP"
        elif code_ == cls.OP_SETLIST:
            name = "OP_SETLIST"
        elif code_ == cls.OP_CLOSE:
            name = "OP_CLOSE"
        elif code_ == cls.OP_CLOSURE:
            name = "OP_CLOSURE"
        elif code_ == cls.OP_VARARG:
            name = "OP_VARARG"
        return name

    def vmExecute(self, nexeccalls):
        """ generated source for method vmExecute """
        __pc_2 = pc
        pc += 1
        hookcount -= 1
        __b_4 = b
        b -= 1
        nexeccalls -= 1
        __pc_6 = pc
        pc += 1
        __last_7 = last
        last -= 1
        while True:
            function_ = self.stack[self.ci().function_()].r
            proto = function_.proto()
            code_ = proto.code_()
            k = proto.constant()
            pc = self.savedpc
            if self.D:
                i_test = 0
                while len(code_):
                    name1 = self.getOpcodeName(self.OPCODE(code_[i_test]))
                    System.err.println(">>>OPCODE(code(" + (i_test + 1) + ")) == " + name1)
                    i_test += 1
            while True:
                i = code_[__pc_2]
                if (self.hookmask & self.MASKCOUNT) != 0 and hookcount == 0:
                    traceexec(pc)
                    if self.status == self.YIELD:
                        self.savedpc = pc - 1
                        return
                a = self.ARGA(i)
                rb = None
                rc = None
                if self.D:
                    name2 = self.getOpcodeName(self.OPCODE(i))
                    System.err.println(">>>pc == " + pc + ", name == " + name2)
                if self.OPCODE(i) == self.OP_MOVE:
                    self.stack[self.base + a].r = self.stack[self.base + self.ARGB(i)].r
                    self.stack[self.base + a].d = self.stack[self.base + self.ARGB(i)].d
                    continue 
                elif self.OPCODE(i) == self.OP_LOADK:
                    self.stack[self.base + a].r = k[self.ARGBx(i)].r
                    self.stack[self.base + a].d = k[self.ARGBx(i)].d
                    continue 
                elif self.OPCODE(i) == self.OP_LOADBOOL:
                    self.stack[self.base + a].r = self.valueOfBoolean(self.ARGB(i) != 0)
                    if self.ARGC(i) != 0:
                        pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_LOADNIL:
                    b = self.base + self.ARGB(i)
                    while True:
                        self.stack[__b_4].r = self.NIL
                        if not ((b >= self.base + a)):
                            break
                    continue 
                elif self.OPCODE(i) == self.OP_GETUPVAL:
                    b = self.ARGB(i)
                    setObjectAt(function_.upVal(b).getValue(), self.base + a)
                    continue 
                elif self.OPCODE(i) == self.OP_GETGLOBAL:
                    rb = k[self.ARGBx(i)]
                    self.savedpc = pc
                    vmGettable(function_.getEnv(), rb, self.stack[self.base + a])
                    continue 
                elif self.OPCODE(i) == self.OP_GETTABLE:
                    self.savedpc = pc
                    h = self.stack[self.base + self.ARGB(i)].asObject()
                    if self.D:
                        System.err.println(", h = " + len(length) + h)
                    vmGettable(h, self.RK(k, self.ARGC(i)), self.stack[self.base + a])
                    continue 
                elif self.OPCODE(i) == self.OP_SETUPVAL:
                    uv = function_.upVal(self.ARGB(i))
                    uv.setValue(objectAt(self.base + a))
                    continue 
                elif self.OPCODE(i) == self.OP_SETGLOBAL:
                    self.savedpc = pc
                    vmSettable(function_.getEnv(), k[self.ARGBx(i)], objectAt(self.base + a))
                    continue 
                elif self.OPCODE(i) == self.OP_SETTABLE:
                    self.savedpc = pc
                    t = self.stack[self.base + a].asObject()
                    vmSettable(t, self.RK(k, self.ARGB(i)), self.RK(k, self.ARGC(i)).asObject())
                    continue 
                elif self.OPCODE(i) == self.OP_NEWTABLE:
                    b = self.ARGB(i)
                    c = self.ARGC(i)
                    self.stack[self.base + a].r = LuaTable(self.oFb2int(b), self.oFb2int(c))
                    continue 
                elif self.OPCODE(i) == self.OP_SELF:
                    b = self.ARGB(i)
                    rb = self.stack[self.base + b]
                    self.stack[self.base + a + 1].r = rb.r
                    self.stack[self.base + a + 1].d = rb.d
                    self.savedpc = pc
                    vmGettable(rb.asObject(), self.RK(k, self.ARGC(i)), self.stack[self.base + a])
                    continue 
                elif self.OPCODE(i) == self.OP_ADD:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        sum = rb.d + rc.d
                        self.stack[self.base + a].d = sum
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        sum = self.NUMOP[0] + self.NUMOP[1]
                        self.stack[self.base + a].d = sum
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__add"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_SUB:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        difference = rb.d - rc.d
                        self.stack[self.base + a].d = difference
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        difference = self.NUMOP[0] - self.NUMOP[1]
                        self.stack[self.base + a].d = difference
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__sub"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_MUL:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        product = rb.d * rc.d
                        self.stack[self.base + a].d = product
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        product = self.NUMOP[0] * self.NUMOP[1]
                        self.stack[self.base + a].d = product
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__mul"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_DIV:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        quotient = rb.d / rc.d
                        self.stack[self.base + a].d = quotient
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        quotient = self.NUMOP[0] / self.NUMOP[1]
                        self.stack[self.base + a].d = quotient
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__div"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_MOD:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        modulus = modulus(rb.d, rc.d)
                        self.stack[self.base + a].d = modulus
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        modulus = modulus(self.NUMOP[0], self.NUMOP[1])
                        self.stack[self.base + a].d = modulus
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__mod"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_POW:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if rb.r == self.NUMBER and rc.r == self.NUMBER:
                        result = iNumpow(rb.d, rc.d)
                        self.stack[self.base + a].d = result
                        self.stack[self.base + a].r = self.NUMBER
                    elif toNumberPair(rb, rc, self.NUMOP):
                        result = iNumpow(self.NUMOP[0], self.NUMOP[1])
                        self.stack[self.base + a].d = result
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rc, self.stack[self.base + a], "__pow"):
                        self.gAritherror(rb, rc)
                    continue 
                elif self.OPCODE(i) == self.OP_UNM:
                    rb = self.stack[self.base + self.ARGB(i)]
                    if rb.r == self.NUMBER:
                        self.stack[self.base + a].d = -rb.d
                        self.stack[self.base + a].r = self.NUMBER
                    elif tonumber(rb, self.NUMOP):
                        self.stack[self.base + a].d = -self.NUMOP[0]
                        self.stack[self.base + a].r = self.NUMBER
                    elif not call_binTM(rb, rb, self.stack[self.base + a], "__unm"):
                        self.gAritherror(rb, rb)
                    continue 
                elif self.OPCODE(i) == self.OP_NOT:
                    ra = self.stack[self.base + self.ARGB(i)].r
                    self.stack[self.base + a].r = self.valueOfBoolean(isFalse(ra))
                    continue 
                elif self.OPCODE(i) == self.OP_LEN:
                    rb = self.stack[self.base + self.ARGB(i)]
                    if isinstance(, (LuaTable, )):
                        t = rb.r
                        self.stack[self.base + a].d = t.getn()
                        self.stack[self.base + a].r = self.NUMBER
                        continue 
                    elif isinstance(, (str, )):
                        s = str(rb.r)
                        self.stack[self.base + a].d = len(s)
                        self.stack[self.base + a].r = self.NUMBER
                        continue 
                    self.savedpc = pc
                    if not call_binTM(rb, rb, self.stack[self.base + a], "__len"):
                        self.gTypeerror(rb, "get length of")
                    continue 
                elif self.OPCODE(i) == self.OP_CONCAT:
                    b = self.ARGB(i)
                    c = self.ARGC(i)
                    self.savedpc = pc
                    self.vmConcat(c - b + 1, c)
                    self.stack[self.base + a].r = self.stack[self.base + b].r
                    self.stack[self.base + a].d = self.stack[self.base + b].d
                    continue 
                elif self.OPCODE(i) == self.OP_JMP:
                    pc += self.ARGsBx(i)
                    continue 
                elif self.OPCODE(i) == self.OP_EQ:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    if self.vmEqual(rb, rc) == (a != 0):
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_LT:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    self.savedpc = pc
                    if vmLessthan(rb, rc) == (a != 0):
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_LE:
                    rb = self.RK(k, self.ARGB(i))
                    rc = self.RK(k, self.ARGC(i))
                    self.savedpc = pc
                    if vmLessequal(rb, rc) == (a != 0):
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_TEST:
                    if isFalse(self.stack[self.base + a].r) != (self.ARGC(i) != 0):
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_TESTSET:
                    rb = self.stack[self.base + self.ARGB(i)]
                    if isFalse(rb.r) != (self.ARGC(i) != 0):
                        self.stack[self.base + a].r = rb.r
                        self.stack[self.base + a].d = rb.d
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_CALL:
                    b = self.ARGB(i)
                    nresults = self.ARGC(i) - 1
                    if b != 0:
                        stacksetsize(self.base + a + b)
                    self.savedpc = pc
                    if vmPrecall(self.base + a, nresults) == self.PCRLUA:
                        nexeccalls += 1
                        continue 
                    elif vmPrecall(self.base + a, nresults) == self.PCRJ:
                        if nresults >= 0:
                            stacksetsize(self.ci().top())
                        continue 
                    else:
                        return
                elif self.OPCODE(i) == self.OP_TAILCALL:
                    b = self.ARGB(i)
                    if b != 0:
                        stacksetsize(self.base + a + b)
                    self.savedpc = pc
                    if vmPrecall(self.base + a, self.MULTRET) == self.PCRLUA:
                        ci = self.civ.elementAt(len(self.civ) - 2)
                        func = self.ci.function_()
                        fci = self.ci()
                        pfunc = fci.function_()
                        self.fClose(self.ci.base())
                        self.base = func + (fci.base() - pfunc)
                        aux = int()
                        while pfunc + aux < self.stackSize:
                            self.stack[func + aux].r = self.stack[pfunc + aux].r
                            self.stack[func + aux].d = self.stack[pfunc + aux].d
                            aux += 1
                        stacksetsize(func + aux)
                        self.ci.tailcall(self.base, self.stackSize)
                        dec_ci()
                        continue 
                    elif vmPrecall(self.base + a, self.MULTRET) == self.PCRJ:
                        continue 
                    else:
                        return
                elif self.OPCODE(i) == self.OP_RETURN:
                    self.fClose(self.base)
                    b = self.ARGB(i)
                    if b != 0:
                        top = a + b - 1
                        stacksetsize(self.base + top)
                    self.savedpc = pc
                    adjust = vmPoscall(self.base + a)
                    if nexeccalls == 0:
                        return
                    if adjust:
                        stacksetsize(self.ci().top())
                    continue 
                elif self.OPCODE(i) == self.OP_FORLOOP:
                    step = self.stack[self.base + a + 2].d
                    idx = self.stack[self.base + a].d + step
                    limit = self.stack[self.base + a + 1].d
                    if (0 < step and idx <= limit) or (step <= 0 and limit <= idx):
                        pc += self.ARGsBx(i)
                        self.stack[self.base + a].d = idx
                        self.stack[self.base + a].r = self.NUMBER
                        self.stack[self.base + a + 3].d = idx
                        self.stack[self.base + a + 3].r = self.NUMBER
                    continue 
                elif self.OPCODE(i) == self.OP_FORPREP:
                    init = self.base + a
                    plimit = self.base + a + 1
                    pstep = self.base + a + 2
                    self.savedpc = pc
                    if not tonumber(init):
                        self.gRunerror("'for' initial value must be a number")
                    elif not tonumber(plimit):
                        self.gRunerror("'for' limit must be a number")
                    elif not tonumber(pstep):
                        self.gRunerror("'for' step must be a number")
                    step = self.stack[pstep].d
                    idx = self.stack[init].d - step
                    self.stack[init].d = idx
                    self.stack[init].r = self.NUMBER
                    pc += self.ARGsBx(i)
                    continue 
                elif self.OPCODE(i) == self.OP_TFORLOOP:
                    cb = self.base + a + 3
                    self.stack[cb + 2].r = self.stack[self.base + a + 2].r
                    self.stack[cb + 2].d = self.stack[self.base + a + 2].d
                    self.stack[cb + 1].r = self.stack[self.base + a + 1].r
                    self.stack[cb + 1].d = self.stack[self.base + a + 1].d
                    self.stack[cb].r = self.stack[self.base + a].r
                    self.stack[cb].d = self.stack[self.base + a].d
                    stacksetsize(cb + 3)
                    self.savedpc = pc
                    self.vmCall(cb, self.ARGC(i))
                    stacksetsize(self.ci().top())
                    if self.NIL != self.stack[cb].r:
                        self.stack[cb - 1].r = self.stack[cb].r
                        self.stack[cb - 1].d = self.stack[cb].d
                        pc += self.ARGsBx(code_[pc])
                    pc += 1
                    continue 
                elif self.OPCODE(i) == self.OP_SETLIST:
                    n = self.ARGB(i)
                    c = self.ARGC(i)
                    setstack = False
                    if 0 == n:
                        n = (self.stackSize - (self.base + a)) - 1
                        setstack = True
                    if 0 == c:
                        c = code_[__pc_6]
                    t = self.stack[self.base + a].r
                    last = ((c - 1) * self.LFIELDS_PER_FLUSH) + n
                    while n > 0:
                        val = objectAt(self.base + a + n)
                        t.putnum(__last_7, val)
                        n -= 1
                    if setstack:
                        stacksetsize(self.ci().top())
                    continue 
                elif self.OPCODE(i) == self.OP_CLOSE:
                    self.fClose(self.base + a)
                    continue 
                elif self.OPCODE(i) == self.OP_CLOSURE:
                    p = function_.proto().proto()[self.ARGBx(i)]
                    nup = p.nups()
                    up = [None] * nup
                    j = 0
                    while j < nup:
                        in_ = code_[pc]
                        if self.OPCODE(in_) == self.OP_GETUPVAL:
                            up[j] = function_.upVal(self.ARGB(in_))
                        else:
                            up[j] = self.fFindupval(self.base + self.ARGB(in_))
                        pc += 1
                    nf = LuaFunction(p, up, function_.getEnv())
                    self.stack[self.base + a].r = nf
                    continue 
                elif self.OPCODE(i) == self.OP_VARARG:
                    b = self.ARGB(i) - 1
                    n = (self.base - self.ci().function_()) - function_.proto().numparams() - 1
                    if b == self.MULTRET:
                        b = n
                        stacksetsize(self.base + a + n)
                    j = 0
                    while j < b:
                        if j < n:
                            src = self.stack[self.base - n + j]
                            self.stack[self.base + a + j].r = src.r
                            self.stack[self.base + a + j].d = src.d
                        else:
                            self.stack[self.base + a + j].r = self.NIL
                        j += 1
                    continue 

    @classmethod
    def iNumpow(cls, a, b):
        """ generated source for method iNumpow """
        invert = b < 0.0
        if invert:
            b = -b
        if a == 0.0:
            return Double.NaN if invert else a
        result = 1.0
        ipow = int(b)
        b -= ipow
        t = a
        while ipow > 0:
            if (ipow & 1) != 0:
                result *= t
            ipow >>= 1
            t = t * t
        if b != 0.0:
            if a < 0.0:
                return Double.NaN
            t = sqrt(a)
            half = 0.5
            while b > 0.0:
                if b >= half:
                    result = result * t
                    b -= half
                b = b + b
                t = sqrt(t)
                if t == 1.0:
                    break
        return 1.0 / result if invert else result

    def vmGettable(self, t, key, val):
        """ generated source for method vmGettable """
        tm = None
        loop = 0
        while loop < self.MAXTAGLOOP:
            if isinstance(t, (LuaTable, )):
                h = t
                h.getlua(key, self.SPARE_SLOT)
                if self.SPARE_SLOT.r != self.NIL:
                    val.r = self.SPARE_SLOT.r
                    val.d = self.SPARE_SLOT.d
                    return
                tm = tagmethod(h, "__index")
                if tm == self.NIL:
                    val.r = self.NIL
                    return
            else:
                tm = tagmethod(t, "__index")
                if tm == self.NIL:
                    self.gTypeerror(t, "index")
            if self.isFunction(tm):
                self.SPARE_SLOT.setObject(t)
                callTMres(val, tm, self.SPARE_SLOT, key)
                return
            t = tm
            loop += 1
        self.gRunerror("loop in gettable")

    def vmLessthan(self, l, r):
        """ generated source for method vmLessthan """
        if l.r.__class__ != r.r.__class__:
            self.gOrdererror(l, r)
        elif l.r == self.NUMBER:
            return l.d < r.d
        elif isinstance(, (str, )):
            return (str(l.r)).compareTo(str(r.r)) < 0
        res = call_orderTM(l, r, "__lt")
        if res >= 0:
            return res != 0
        return self.gOrdererror(l, r)

    def vmLessequal(self, l, r):
        """ generated source for method vmLessequal """
        if l.r.__class__ != r.r.__class__:
            self.gOrdererror(l, r)
        elif l.r == self.NUMBER:
            return l.d <= r.d
        elif isinstance(, (str, )):
            return (str(l.r)).compareTo(str(r.r)) <= 0
        res = call_orderTM(l, r, "__le")
        if res >= 0:
            return res != 0
        res = call_orderTM(r, l, "__lt")
        if res >= 0:
            return res == 0
        return self.gOrdererror(l, r)

    def vmPoscall(self, firstResult):
        """ generated source for method vmPoscall """
        lci = None
        lci = dec_ci()
        res = lci.res()
        wanted = lci.nresults()
        cci = self.ci()
        self.base = cci.base()
        self.savedpc = cci.savedpc()
        i = wanted
        top = self.stackSize
        while i != 0 and firstResult < top:
            if self.D:
                System.err.println("vmPoscall:" + res)
            self.stack[res].r = self.stack[firstResult].r
            self.stack[res].d = self.stack[firstResult].d
            res += 1
            firstResult += 1
            i -= 1
        if i > 0:
            stacksetsize(res + i)
        __i_8 = i
        i -= 1
        __res_9 = res
        res += 1
        while __i_8 > 0:
            self.stack[__res_9].r = self.NIL
        stacksetsize(res)
        return wanted != self.MULTRET

    def vmPrecall(self, func, r):
        """ generated source for method vmPrecall """
        faso = None
        if self.D:
            System.err.println("vmPrecall:" + func)
        faso = self.stack[func].r
        if not self.isFunction(faso):
            faso = tryfuncTM(func)
        self.ci().setSavedpc(self.savedpc)
        if isinstance(faso, (LuaFunction, )):
            f = faso
            p = f.proto()
            if not p.isVararg():
                self.base = func + 1
                if self.stackSize > self.base + p.numparams():
                    stacksetsize(self.base + p.numparams())
            else:
                nargs = (self.stackSize - func) - 1
                self.base = adjust_varargs(p, nargs)
            top = self.base + p.maxstacksize()
            inc_ci(func, self.base, top, r)
            self.savedpc = 0
            stacksetsize(top)
            return self.PCRLUA
        elif isinstance(faso, (LuaJavaCallback, )):
            fj = faso
            self.base = func + 1
            inc_ci(func, self.base, self.stackSize + self.MINSTACK, r)
            n = 99
            try:
                n = fj.luaFunction(self)
            except LuaError as e:
                raise e
            except RuntimeException as e:
                e.printStackTrace()
                self.yield_(0)
                raise e
            if n < 0:
                return self.PCRYIELD
            else:
                self.vmPoscall(self.stackSize - n)
                return self.PCRJ
        raise IllegalArgumentException()

    def vmSettable(self, t, key, val):
        """ generated source for method vmSettable """
        loop = 0
        while loop < self.MAXTAGLOOP:
            tm = None
            if isinstance(t, (LuaTable, )):
                h = t
                h.getlua(key, self.SPARE_SLOT)
                if self.SPARE_SLOT.r != self.NIL:
                    h.putlua(self, key, val)
                    return
                tm = tagmethod(h, "__newindex")
                if tm == self.NIL:
                    h.putlua(self, key, val)
                    return
            else:
                tm = tagmethod(t, "__newindex")
                if tm == self.NIL:
                    self.gTypeerror(t, "index")
            if self.isFunction(tm):
                callTM(tm, t, key, val)
                return
            t = tm
            loop += 1
        self.gRunerror("loop in settable")

    NUMBER_FMT = ".14g"

    @classmethod
    def vmTostring(cls, o):
        """ generated source for method vmTostring """
        if isinstance(o, (str, )):
            return str(o)
        if not (isinstance(o, (float, ))):
            return None
        f = FormatItem(None, cls.NUMBER_FMT)
        b = StringBuffer()
        d = float(o)
        f.formatFloat(b, d.doubleValue())
        return b.__str__()

    def adjust_varargs(self, p, actual):
        """ generated source for method adjust_varargs """
        nfixargs = p.numparams()
        while actual < nfixargs:
            stackAdd(self.NIL)
            actual += 1
        fixed = self.stackSize - actual
        newbase = self.stackSize
        i = 0
        while i < nfixargs:
            self.push(self.stack[fixed + i])
            self.stack[fixed + i].r = self.NIL
            i += 1
        return newbase

    def call_binTM(self, p1, p2, res, event):
        """ generated source for method call_binTM """
        tm = tagmethod(p1.asObject(), event)
        if self.isNil(tm):
            tm = tagmethod(p2.asObject(), event)
        if not self.isFunction(tm):
            return False
        callTMres(res, tm, p1, p2)
        return True

    def call_orderTM(self, p1, p2, event):
        """ generated source for method call_orderTM """
        tm1 = tagmethod(p1.asObject(), event)
        if tm1 == self.NIL:
            return -1
        tm2 = tagmethod(p2.asObject(), event)
        if not self.oRawequal(tm1, tm2):
            return -1
        s = Slot()
        callTMres(s, tm1, p1, p2)
        return 0 if isFalse(s.r) else 1

    def callTM(self, f, p1, p2, p3):
        """ generated source for method callTM """
        self.push(f)
        self.push(p1)
        self.push(p2)
        self.push(p3)
        self.vmCall(self.stackSize - 4, 0)

    @overloaded
    def callTMres(self, res, f, p1, p2):
        """ generated source for method callTMres """
        self.push(f)
        self.push(p1)
        self.push(p2)
        self.vmCall(self.stackSize - 3, 1)
        if self.D:
            System.err.println("callTMres:" + (self.stackSize - 1))
        res.r = self.stack[self.stackSize - 1].r
        res.d = self.stack[self.stackSize - 1].d
        self.pop(1)

    @callTMres.register(object, Slot, object, object, object)
    def callTMres_0(self, res, f, p1, p2):
        """ generated source for method callTMres_0 """
        self.push(f)
        self.push(p1)
        self.push(p2)
        self.vmCall(self.stackSize - 3, 1)
        if self.D:
            System.err.println("callTMres" + (self.stackSize - 1))
        res.r = self.stack[self.stackSize - 1].r
        res.d = self.stack[self.stackSize - 1].d
        self.pop(1)

    def get_compTM(self, mt1, mt2, event):
        """ generated source for method get_compTM """
        if mt1 == None:
            return self.NIL
        tm1 = mt1.getlua(event)
        if self.isNil(tm1):
            return self.NIL
        if mt1 == mt2:
            return tm1
        if mt2 == None:
            return self.NIL
        tm2 = mt2.getlua(event)
        if self.isNil(tm2):
            return self.NIL
        if self.oRawequal(tm1, tm2):
            return tm1
        return self.NIL

    @overloaded
    def tagmethod(self, o, event):
        """ generated source for method tagmethod """
        return self.getMetafield(o, event)

    @tagmethod.register(object, Slot, str)
    def tagmethod_0(self, o, event):
        """ generated source for method tagmethod_0 """
        raise IllegalArgumentException("tagmethod called")

    @classmethod
    def modulus(cls, x, y):
        """ generated source for method modulus """
        return x - floor(x / y) * y

    def stacksetsize(self, n):
        """ generated source for method stacksetsize """
        if n == 3:
            if self.D:
                System.err.println("stacksetsize:" + n)
        if n == 7:
            if self.D:
                System.err.println(">>>stacksetsize:" + n)
        old = self.stackSize
        if len(stack):
            newLength = max(n, len(stack))
            newStack = [None] * newLength
            toCopy = int()
            System.arraycopy(self.stack, 0, newStack, 0, toCopy)
            self.stack = newStack
        self.stackSize = n
        if n <= old:
            i = n
            while i < old:
                self.stack[i].r = self.NIL
                i += 1
        if n > self.stackhighwater:
            i = self.stackhighwater
            while i < n:
                self.stack[i] = Slot()
                self.stack[i].r = self.NIL
                i += 1
            self.stackhighwater = n

    def stackAdd(self, o):
        """ generated source for method stackAdd """
        i = self.stackSize
        self.stacksetsize(i + 1)
        if self.D:
            System.err.println("stackAdd:" + i)
        self.stack[i].setObject(o)

    @push.register(object, Slot)
    def push_0(self, p):
        """ generated source for method push_0 """
        i = self.stackSize
        self.stacksetsize(i + 1)
        if self.D:
            System.err.println("push:" + i)
        self.stack[i].r = p.r
        self.stack[i].d = p.d

    def stackInsertAt(self, o, i):
        """ generated source for method stackInsertAt """
        n = self.stackSize - i
        self.stacksetsize(self.stackSize + 1)
        j = n
        while j >= 1:
            if self.D:
                System.err.println("stackInsertAt:" + (i + j))
            self.stack[i + j].r = self.stack[i + j - 1].r
            self.stack[i + j].d = self.stack[i + j - 1].d
            j -= 1
        self.stack[i].setObject(o)

    def resethookcount(self):
        """ generated source for method resethookcount """
        self.hookcount = self.basehookcount

    def traceexec(self, pc):
        """ generated source for method traceexec """
        mask = self.hookmask
        oldpc = self.savedpc
        self.savedpc = pc
        if mask > self.MASKLINE:
            if self.hookcount == 0:
                self.resethookcount()
                self.dCallhook(self.HOOKCOUNT, -1)

    @classmethod
    @overloaded
    def tonumber(cls, o, out):
        """ generated source for method tonumber """
        if o.r == cls.NUMBER:
            out[0] = o.d
            return True
        if not (isinstance(, (str, ))):
            return False
        if cls.oStr2d(str(o.r), out):
            return True
        return False

    @tonumber.register(object, int)
    def tonumber_0(self, idx):
        """ generated source for method tonumber_0 """
        if self.tonumber(self.stack[idx], self.NUMOP):
            if self.D:
                System.err.println("tonumber:" + idx)
            self.stack[idx].d = self.NUMOP[0]
            self.stack[idx].r = self.NUMBER
            return True
        return False

    @classmethod
    def toNumberPair(cls, x, y, out):
        """ generated source for method toNumberPair """
        if cls.tonumber(y, out):
            out[1] = out[0]
            if cls.tonumber(x, out):
                return True
        return False

    def tostring(self, idx):
        """ generated source for method tostring """
        o = objectAt(idx)
        s = self.vmTostring(o)
        if s == None:
            return False
        if self.D:
            System.err.println("tostring:" + idx)
        self.stack[idx].r = s
        return True

    def tryfuncTM(self, func):
        """ generated source for method tryfuncTM """
        if self.D:
            System.err.println("tryfuncTM:" + func)
        tm = self.tagmethod(self.stack[func].asObject(), "__call")
        if not self.isFunction(tm):
            self.gTypeerror(self.stack[func], "call")
        self.stackInsertAt(tm, func)
        return tm

    @overloaded
    def isFalse(self, o):
        """ generated source for method isFalse """
        return o == self.NIL or o == Boolean.FALSE

    @isFalse.register(object, Slot)
    def isFalse_0(self, o):
        """ generated source for method isFalse_0 """
        raise IllegalArgumentException("isFalse called")

    def inc_ci(self, func, baseArg, top, nresults):
        """ generated source for method inc_ci """
        ci = CallInfo(func, baseArg, top, nresults)
        self.civ.addElement(ci)
        return ci

    def dec_ci(self):
        """ generated source for method dec_ci """
        ci = self.civ.pop()
        return ci

    def resume_error(self, msg):
        """ generated source for method resume_error """
        self.stacksetsize(self.ci().base())
        self.stackAdd(msg)
        return self.ERRRUN

    def objectAt(self, idx):
        """ generated source for method objectAt """
        r = self.stack[idx].r
        if r != self.NUMBER:
            return r
        return float(self.stack[idx].d)

    def setObjectAt(self, o, idx):
        """ generated source for method setObjectAt """
        if isinstance(o, (float, )):
            if self.D:
                System.err.println("setObjectAt" + idx)
            self.stack[idx].r = self.NUMBER
            self.stack[idx].d = (float(o)).doubleValue()
            return
        self.stack[idx].r = o

    @classmethod
    def uDump(cls, f, writer, strip):
        """ generated source for method uDump """
        d = DumpState(DataOutputStream(writer), strip)
        d.DumpHeader()
        d.DumpFunction(f, None)
        d.writer.flush()
        return 0


class DumpState(object):
    """ generated source for class DumpState """
    writer = None
    strip = bool()

    def __init__(self, writer, strip):
        """ generated source for method __init__ """
        self.writer = writer
        self.strip = strip

    def DumpHeader(self):
        """ generated source for method DumpHeader """
        Loader.HEADER[6] = 0
        self.writer.write(Loader.HEADER)

    def DumpInt(self, i):
        """ generated source for method DumpInt """
        self.writer.writeInt(i)

    def DumpNumber(self, d):
        """ generated source for method DumpNumber """
        self.writer.writeDouble(d)

    def DumpFunction(self, f, p):
        """ generated source for method DumpFunction """
        DumpString(None if (f.source == p or self.strip) else f.source)
        self.DumpInt(f.linedefined)
        self.DumpInt(f.lastlinedefined)
        self.writer.writeByte(f.nups)
        self.writer.writeByte(f.numparams)
        self.writer.writeBoolean(f.isVararg())
        self.writer.writeByte(f.maxstacksize)
        DumpCode(f)
        DumpConstants(f)
        DumpDebug(f)

    def DumpCode(self, f):
        """ generated source for method DumpCode """
        n = f.sizecode
        code_ = f.code_
        self.DumpInt(n)
        i = 0
        while i < n:
            self.DumpInt(code_[i])
            i += 1

    def DumpConstants(self, f):
        """ generated source for method DumpConstants """
        n = f.sizek
        k = f.k
        self.DumpInt(n)
        i = 0
        while i < n:
            o = k[i].r
            if o == Lua.NIL:
                self.writer.writeByte(Lua.TNIL)
            elif isinstance(o, (bool, )):
                self.writer.writeByte(Lua.TBOOLEAN)
                self.writer.writeBoolean((bool(o)).booleanValue())
            elif o == Lua.NUMBER:
                self.writer.writeByte(Lua.TNUMBER)
                self.DumpNumber(k[i].d)
            elif isinstance(o, (str, )):
                self.writer.writeByte(Lua.TSTRING)
                DumpString(str(o))
            else:
                pass
            i += 1
        n = f.sizep
        self.DumpInt(n)
        i = 0
        while i < n:
            subfunc = f.p[i]
            self.DumpFunction(subfunc, f.source)
            i += 1

    def DumpString(self, s):
        """ generated source for method DumpString """
        if s == None:
            self.DumpInt(0)
        else:
            contents = s.getBytes("UTF-8")
            size = int()
            self.DumpInt(size + 1)
            self.writer.write(contents, 0, size)
            self.writer.writeByte(0)

    def DumpDebug(self, f):
        """ generated source for method DumpDebug """
        if self.strip:
            self.DumpInt(0)
            self.DumpInt(0)
            self.DumpInt(0)
            return
        n = f.sizelineinfo
        self.DumpInt(n)
        i = 0
        while i < n:
            self.DumpInt(f.lineinfo[i])
            i += 1
        n = f.sizelocvars
        self.DumpInt(n)
        i = 0
        while i < n:
            locvar = f.locvars[i]
            self.DumpString(locvar.varname)
            self.DumpInt(locvar.startpc)
            self.DumpInt(locvar.endpc)
            i += 1
        n = f.sizeupvalues
        self.DumpInt(n)
        i = 0
        while i < n:
            self.DumpString(f.upvalues[i])
            i += 1


class Slot(object):
    """ generated source for class Slot """
    r = None
    d = float()

    @overloaded
    def __init__(self):
        """ generated source for method __init__ """

    @__init__.register(object, Slot)
    def __init___0(self, s):
        """ generated source for method __init___0 """
        self.r = s.r
        self.d = s.d

    @__init__.register(object, object)
    def __init___1(self, o):
        """ generated source for method __init___1 """
        self.setObject(o)

    def asObject(self):
        """ generated source for method asObject """
        if self.r == Lua.NUMBER:
            return float(self.d)
        return self.r

    def setObject(self, o):
        """ generated source for method setObject """
        self.r = o
        if isinstance(o, (float, )):
            self.r = Lua.NUMBER
            self.d = (float(o)).doubleValue()
            if Lua.D:
                System.err.println("Slot.setObject:" + self.d)

Lua.COPYRIGHT = "Copyright (C) 1994-2008 Lua.org, PUC-Rio (Copyright (C) 2006 Nokia Corporation and/or its subsidiary(-ies))"

Lua.#    * functipn then this is the element indexed by Lua.value(1).

Lua.#    * changing global variables from within Lua.

Lua.#    * @return Lua.YIELD, 0, or an error code.

Lua.#    * @return 0, an error code, or Lua.YIELD.

