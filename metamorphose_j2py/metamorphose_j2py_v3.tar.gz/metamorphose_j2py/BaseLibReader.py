#!/usr/bin/env python
""" generated source for module BaseLibReader """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/BaseLibReader.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Extends {@link java.io.Reader} to create a Reader from a Lua
#  * function.  So that the <code>load</code> function from Lua's base
#  * library can be implemented.
#  
class BaseLibReader(java, io, Reader):
    """ generated source for class BaseLibReader """
    s = ""
    i = int()

    #  = 0;
    mark = -1
    L = None
    f = None

    def __init__(self, L, f):
        """ generated source for method __init__ """
        super(BaseLibReader, self).__init__()
        self.L = L
        self.f = f

    def close(self):
        """ generated source for method close """
        self.f = None

    def mark(self, l):
        """ generated source for method mark """
        if l > 1:
            raise IOError("Readahead must be <= 1")
        self.mark = self.i

    def markSupported(self):
        """ generated source for method markSupported """
        return True

    @overloaded
    def read(self):
        """ generated source for method read """
        if self.i >= len(s):
            self.L.push(self.f)
            self.L.call(0, 1)
            if self.L.isNil(self.L.value(-1)):
                return -1
            elif self.L.isString(self.L.value(-1)):
                self.s = self.L.toString(self.L.value(-1))
                if 0 == len(s):
                    return -1
                if self.mark == self.i:
                    self.mark = 0
                else:
                    self.mark = -1
                self.i = 0
            else:
                self.L.error("reader function must return a string")
        __i_0 = i
        i += 1
        __i_1 = i
        i += 1
        return self.s.charAt(__i_1)

    @read.register(object, str, int, int)
    def read_0(self, cbuf, off, len):
        """ generated source for method read_0 """
        j = 0
        #  loop index required after loop
        while j < len:
            c = self.read()
            if c == -1:
                if j == 0:
                    return -1
                else:
                    return j
            cbuf[off + j] = str(c)
            j += 1
        return j

    def reset(self):
        """ generated source for method reset """
        if self.mark < 0:
            raise IOError("reset() not supported now")
        self.i = self.mark

