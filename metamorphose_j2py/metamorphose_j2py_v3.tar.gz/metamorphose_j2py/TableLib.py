#!/usr/bin/env python
""" generated source for module TableLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/TableLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Contains Lua's table library.
#  * The library can be opened using the {@link #open} method.
#  
class TableLib(LuaJavaCallback):
    """ generated source for class TableLib """
    #  Each function in the table library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    CONCAT = 1
    INSERT = 2
    MAXN = 3
    REMOVE = 4
    SORT = 5
    GETN = 6

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    #  Constructs instance, filling in the 'which' member. 
    def __init__(self, which):
        """ generated source for method __init__ """
        super(TableLib, self).__init__()
        self.which = which

    # 
    #    * Implements all of the functions in the Lua table library.  Do not
    #    * call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.CONCAT:
            return concat(L)
        elif self.which == self.INSERT:
            return insert(L)
        elif self.which == self.MAXN:
            return maxn(L)
        elif self.which == self.REMOVE:
            return remove(L)
        elif self.which == self.SORT:
            return sort(L)
        elif self.which == self.GETN:
            return getn(L)
        return 0

    # 
    #    * Opens the string library into the given Lua state.  This registers
    #    * the symbols of the string library in a newly created table called
    #    * "string".
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        L.register("table")
        r(L, "concat", cls.CONCAT)
        r(L, "insert", cls.INSERT)
        r(L, "getn", cls.GETN)
        # FIXME: added
        r(L, "maxn", cls.MAXN)
        r(L, "remove", cls.REMOVE)
        r(L, "sort", cls.SORT)

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = TableLib(which)
        lib = L.getGlobal("table")
        L.setField(lib, name, f)

    #  Implements table.concat. 
    @classmethod
    def concat(cls, L):
        """ generated source for method concat """
        sep = L.optString(2, "")
        L.checkType(1, Lua.TTABLE)
        i = L.optInt(3, 1)
        last = L.optInt(4, L.objLen(L.value(1)))
        b = StringBuffer()
        t = L.value(1)
        while i <= last:
            v = L.rawGetI(t, i)
            L.argCheck(L.isString(v), 1, "table contains non-strings")
            b.append(L.toString(v))
            if i != last:
                b.append(L.toString(sep))
            i += 1
        L.pushString(b.__str__())
        return 1

    #  Implements table.insert. 
    @classmethod
    def insert(cls, L):
        """ generated source for method insert """
        e = aux_getn(L, 1) + 1
        #  first empty element
        pos = int()
        #  where to insert new element
        t = L.value(1)
        if L.getTop() == 2:
            #  called with only 2 arguments
            pos = e
            #  insert new element at the end
        elif L.getTop() == 3:
            i = int()
            pos = L.checkInt(2)
            #  2nd argument is the position
            if pos > e:
                e = pos
            #  grow array if necessary
            while i > pos:
                #  move up elements
                #  t[i] = t[i-1]
                L.rawSetI(t, i, L.rawGetI(t, i - 1))
                i -= 1
        else:
            return L.error("wrong number of arguments to 'insert'")
        L.rawSetI(t, pos, L.value(-1))
        #  t[pos] = v
        return 0

    #  Implements table.maxn. 
    @classmethod
    def maxn(cls, L):
        """ generated source for method maxn """
        max = 0
        L.checkType(1, Lua.TTABLE)
        t = L.value(1)
        e = t.keys()
        while e.hasMoreElements():
            o = e.nextElement()
            if Lua.type_(o) == Lua.TNUMBER:
                v = L.toNumber(o)
                if v > max:
                    max = v
        L.pushNumber(max)
        return 1

    #  Implements table.remove. 
    @classmethod
    def remove(cls, L):
        """ generated source for method remove """
        e = aux_getn(L, 1)
        pos = L.optInt(2, e)
        if e == 0:
            return 0
        #  table is 'empty'
        t = L.value(1)
        o = L.rawGetI(t, pos)
        #  result = t[pos]
        while pos < e:
            L.rawSetI(t, pos, L.rawGetI(t, pos + 1))
            #  t[pos] = t[pos+1]
            pos += 1
        L.rawSetI(t, e, Lua.NIL)
        #  t[e] = nil
        L.push(o)
        return 1

    #  Implements table.sort. 
    @classmethod
    def sort(cls, L):
        """ generated source for method sort """
        n = aux_getn(L, 1)
        if not L.isNoneOrNil(2):
            L.checkType(2, Lua.TFUNCTION)
        L.setTop(2)
        #  make sure there is two arguments
        auxsort(L, 1, n)
        return 0

    @classmethod
    def auxsort(cls, L, l, u):
        """ generated source for method auxsort """
        t = L.value(1)
        i += 1
        j -= 1
        while l < u:
            #  for tail recursion
            i = int()
            j = int()
            #  sort elements a[l], a[l+u/2], and a[u]
            o1 = L.rawGetI(t, l)
            o2 = L.rawGetI(t, u)
            if sort_comp(L, o2, o1):
                #  a[u] < a[l]?
                L.rawSetI(t, l, o2)
                L.rawSetI(t, u, o1)
            if u - l == 1:
                break
            #  only 2 elements
            i = (l + u) / 2
            o1 = L.rawGetI(t, i)
            o2 = L.rawGetI(t, l)
            if sort_comp(L, o1, o2):
                #  a[i]<a[l]?
                L.rawSetI(t, i, o2)
                L.rawSetI(t, l, o1)
            else:
                o2 = L.rawGetI(t, u)
                if sort_comp(L, o2, o1):
                    #  a[u]<a[i]?
                    L.rawSetI(t, i, o2)
                    L.rawSetI(t, u, o1)
            if u - l == 2:
                break
            #  only 3 elements
            p = L.rawGetI(t, i)
            #  Pivot
            o2 = L.rawGetI(t, u - 1)
            L.rawSetI(t, i, o2)
            L.rawSetI(t, u - 1, p)
            #  a[l] <= P == a[u-1] <= a[u], only need to sort from l+1 to u-2
            i = l
            j = u - 1
            #  NB: Pivot P is in p
            while True:
                #  invariant: a[l..i] <= P <= a[j..u]
                #  repeat ++i until a[i] >= P
                while True:
                    o1 = L.rawGetI(t, i)
                    if not sort_comp(L, o1, p):
                        break
                    if i > u:
                        L.error("invalid order function for sorting")
                #  repreat --j until a[j] <= P
                while True:
                    o2 = L.rawGetI(t, j)
                    if not sort_comp(L, p, o2):
                        break
                    if j < l:
                        L.error("invalid order function for sorting")
                if j < i:
                    break
                L.rawSetI(t, i, o2)
                L.rawSetI(t, j, o1)
            o1 = L.rawGetI(t, u - 1)
            o2 = L.rawGetI(t, i)
            L.rawSetI(t, u - 1, o2)
            L.rawSetI(t, i, o1)
            #  swap pivot (a[u-1]) with a[i]
            #  a[l..i-1 <= a[i] == P <= a[i+1..u]
            #  adjust so that smaller half is in [j..i] and larger one in [l..u]
            if i - l < u - i:
                j = l
                i = i - 1
                l = i + 2
            else:
                j = i + 1
                i = u
                u = j - 2
            cls.auxsort(L, j, i)
            #  call recursively the smaller one
        #  repeat the routine for the larger one

    @classmethod
    def sort_comp(cls, L, a, b):
        """ generated source for method sort_comp """
        if not L.isNil(L.value(2)):
            #  function?
            L.pushValue(2)
            L.push(a)
            L.push(b)
            L.call(2, 1)
            res = L.toBoolean(L.value(-1))
            L.pop(1)
            return res
        else:
            #  a < b?
            return L.lessThan(a, b)

    @classmethod
    def aux_getn(cls, L, n):
        """ generated source for method aux_getn """
        L.checkType(n, Lua.TTABLE)
        t = L.value(n)
        return t.getn()

    # FIXME: added
    @classmethod
    def getn(cls, L):
        """ generated source for method getn """
        L.pushNumber(cls.aux_getn(L, 1))
        return 1

