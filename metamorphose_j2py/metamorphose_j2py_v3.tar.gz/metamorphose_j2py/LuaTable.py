#!/usr/bin/env python
""" generated source for module LuaTable """
from __future__ import print_function
def bsr(value, bits):
    """ bsr(value, bits) -> value shifted right by bits

    This function is here because an expression in the original java
    source contained the token '>>>' and/or '>>>=' (bit shift right
    and/or bit shift right assign).  In place of these, the python
    source code below contains calls to this function.

    Copyright 2003 Jeffrey Clement.  See pyrijnadel.py for license and
    original source.
    """
    minint = -2147483648
    if bits == 0:
        return value
    elif bits == 31:
        if value & minint:
            return 1
        else:
            return 0
    elif bits < 0 or bits > 31:
        raise ValueError('bad shift count')
    tmp = (value & 0x7FFFFFFE) // 2**bits
    if (value & minint):
        return (tmp | (0x40000000 // 2**(bits-1)))
    else:
        return tmp

#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/LuaTable.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Class that models Lua's tables.  Each Lua table is an instance of
#  * this class.  Whilst you can clearly see that this class extends
#  * {@link java.util.Hashtable} you should in no way rely upon that.
#  * Calling any methods that are not defined in this class (but are
#  * defined in a super class) is extremely deprecated.
#  
class LuaTable(java, util, Hashtable):
    """ generated source for class LuaTable """
    MAXBITS = 26
    MAXASIZE = 1 << MAXBITS
    metatable = None

    #  = null;
    ZERO = [None] * 0

    # 
    #    * Array used so that tables accessed like arrays are more efficient.
    #    * All elements stored at an integer index, <var>i</var>, in the
    #    * range [1,sizeArray] are stored at <code>array[i-1]</code>.
    #    * This speed and space usage for array-like access.
    #    * When the table is rehashed the array's size is chosen to be the
    #    * largest power of 2 such that at least half the entries are
    #    * occupied.  Default access granted for {@link Enum} class, do not
    #    * abuse.
    #    
    array = ZERO

    # 
    #    * Equal to <code>array.length</code>.  Default access granted for
    #    * {@link Enum} class, do not abuse.
    #    
    sizeArray = int()

    #  = 0;
    # 
    #    * <code>true</code> whenever we are in the {@link #rehash}
    #    * method.  Avoids infinite rehash loops.
    #    
    inrehash = bool()

    #  = false;
    @overloaded
    def __init__(self):
        """ generated source for method __init__ """
        super(LuaTable, self).__init__(1)

    # 
    #    * Fresh LuaTable with hints for preallocating to size.
    #    * @param narray  number of array slots to preallocate.
    #    * @param nhash   number of hash slots to preallocate.
    #    
    @__init__.register(object, int, int)
    def __init___0(self, narray, nhash):
        """ generated source for method __init___0 """
        #  :todo: super(nhash) isn't clearly correct as adding nhash hash
        #  table entries will causes a rehash with the usual implementation
        #  (which rehashes when ratio of entries to capacity exceeds the
        #  load factor of 0.75).  Perhaps ideally we would size the hash
        #  tables such that adding nhash entries will not cause a rehash.
        super(LuaTable, self).__init__(nhash)
        self.array = [None] * narray
        i = 0
        while i < narray:
            self.array[i] = Lua.NIL
            i += 1
        self.sizeArray = narray

    # 
    #    * Implements discriminating equality.  <code>o1 == o2 == (o1 ==
    #    * o2) </code>.  This method is not necessary in CLDC, it's only
    #    * necessary in J2SE because java.util.Hashtable overrides equals.
    #    * @param o  the reference to compare with.
    #    * @return true when equal.
    #    
    def equals(self, o):
        """ generated source for method equals """
        return self == o

    # 
    #    * Provided to avoid Checkstyle warning.  This method is not necessary
    #    * for correctness (in neither JME nor JSE), it's only provided to
    #    * remove a Checkstyle warning.
    #    * Since {@link #equals} implements the most discriminating
    #    * equality possible, this method can have any implementation.
    #    * @return an int.
    #    
    def hashCode(self):
        """ generated source for method hashCode """
        return System.identityHashCode(self)

    @classmethod
    def arrayindex(cls, key):
        """ generated source for method arrayindex """
        if isinstance(key, (float, )):
            d = (float(key)).doubleValue()
            k = int(d)
            if k == d:
                return k
        return -1
        #  'key' did not match some condition

    @classmethod
    def computesizes(cls, nums, narray):
        """ generated source for method computesizes """
        t = narray[0]
        a = 0
        #  number of elements smaller than 2^i
        na = 0
        #  number of elements to go to array part
        n = 0
        #  optimal size for array part
        twotoi = 1
        #  2^i
        i = 0
        while twotoi / 2 < t:
            if nums[i] > 0:
                a += nums[i]
                if a > twotoi / 2:
                    #  more than half elements present?
                    n = twotoi
                    #  optimal size (till now)
                    na = a
                    #  all elements smaller than n will go to array part
            if a == t:
                #  all elements already counted
                break
            twotoi *= 2
            i += 1
        narray[0] = n
        # # assert narray[0]/2 <= na && na <= narray[0]
        return na

    def countint(self, key, nums):
        """ generated source for method countint """
        k = self.arrayindex(key)
        if 0 < k and k <= self.MAXASIZE:
            #  is 'key' an appropriate array index?
            nums[ceillog2(k)] += 1
            #  count as such
            return 1
        return 0

    def numusearray(self, nums):
        """ generated source for method numusearray """
        ause = 0
        #  summation of 'nums'
        i = 1
        #  count to traverse all array keys
        ttlg = 1
        #  2^lg
        lg = 0
        while lg <= self.MAXBITS:
            #  for each slice
            lc = 0
            #  counter
            lim = ttlg
            if lim > self.sizeArray:
                lim = self.sizeArray
                #  adjust upper limit
                if i > lim:
                    break
                    #  no more elements to count
            #  count elements in range (2^(lg-1), 2^lg]
            while i <= lim:
                if self.array[i - 1] != Lua.NIL:
                    lc += 1
                i += 1
            nums[lg] += lc
            ause += lc
            ttlg *= 2
            lg += 1
        return ause

    def numusehash(self, nums, pnasize):
        """ generated source for method numusehash """
        totaluse = 0
        #  total number of elements
        ause = 0
        #  summation of nums
        e = None
        e = super(LuaTable, self).keys()
        while e.hasMoreElements():
            o = e.nextElement()
            ause += self.countint(o, nums)
            totaluse += 1
        pnasize[0] += ause
        return totaluse

    # 
    #    * @param nasize  (new) size of array part
    #    
    def resize(self, nasize):
        """ generated source for method resize """
        if nasize == self.sizeArray:
            return
        newarray = [None] * nasize
        if nasize > self.sizeArray:
            #  array part must grow?
            #  The new array slots, from sizeArray to nasize-1, must
            #  be filled with their values from the hash part.
            #  There are two strategies:
            #  Iterate over the new array slots, and look up each index in the
            #  hash part to see if it has a value; or,
            #  Iterate over the hash part and see if each key belongs in the
            #  array part.
            #  For now we choose the first algorithm.
            #  :todo: consider using second algorithm, possibly dynamically.
            System.arraycopy(self.array, 0, newarray, 0, )
            i = int()
            while i < nasize:
                key = float(i + 1)
                v = super(LuaTable, self).remove(key)
                if v == None:
                    v = Lua.NIL
                newarray[i] = v
                i += 1
        if nasize < self.sizeArray:
            #  array part must shrink?
            #  move elements from array slots nasize to sizeArray-1 to the
            #  hash part.
            i = nasize
            while i < self.sizeArray:
                if self.array[i] != Lua.NIL:
                    key = float(i + 1)
                    super(LuaTable, self).put(key, self.array[i])
                i += 1
            System.arraycopy(self.array, 0, newarray, 0, )
        self.array = newarray
        len(array)

    def rehash(self):
        """ generated source for method rehash """
        oldinrehash = self.inrehash
        self.inrehash = True
        if not oldinrehash:
            nasize = [None] * 1
            nums = [None] * MAXBITS + 1
            nasize[0] = self.numusearray(nums)
            #  count keys in array part
            totaluse = nasize[0]
            totaluse += self.numusehash(nums, nasize)
            na = self.computesizes(nums, nasize)
            self.resize(nasize[0])
        super(LuaTable, self).rehash()
        self.inrehash = oldinrehash

    # 
    #    * Getter for metatable member.
    #    * @return  The metatable.
    #    
    def getMetatable(self):
        """ generated source for method getMetatable """
        return self.metatable

    # 
    #    * Setter for metatable member.
    #    * @param metatable  The metatable.
    #    
    #  :todo: Support metatable's __gc and __mode keys appropriately.
    #         This involves detecting when those keys are present in the
    #         metatable, and changing all the entries in the Hashtable
    #         to be instance of java.lang.Ref as appropriate.
    def setMetatable(self, metatable):
        """ generated source for method setMetatable """
        self.metatable = metatable
        return

    # 
    #    * Supports Lua's length (#) operator.  More or less equivalent to
    #    * luaH_getn and unbound_search in ltable.c.
    #    
    def getn(self):
        """ generated source for method getn """
        j = self.sizeArray
        if j > 0 and self.array[j - 1] == Lua.NIL:
            #  there is a boundary in the array part: (binary) search for it
            i = 0
            while j - i > 1:
                m = (i + j) / 2
                if self.array[m - 1] == Lua.NIL:
                    j = m
                else:
                    i = m
            return i
        #  unbound_search
        i = 0
        j = 1
        #  Find 'i' and 'j' such that i is present and j is not.
        while self.getnum(j) != Lua.NIL:
            i = j
            j *= 2
            if j < 0:
                #  overflow
                #  Pathological case.  Linear search.
                i = 1
                while self.getnum(i) != Lua.NIL:
                    i += 1
                return i - 1
        #  binary search between i and j
        while j - i > 1:
            m = (i + j) / 2
            if self.getnum(m) == Lua.NIL:
                j = m
            else:
                i = m
        return i

    # 
    #    * Like {@link java.util.Hashtable#get}.  Ensures that indexes
    #    * with no value return {@link Lua#NIL}.  In order to get the correct
    #    * behaviour for <code>t[nil]</code>, this code assumes that Lua.NIL
    #    * is non-<code>null</code>.
    #    
    @overloaded
    def getlua(self, key):
        """ generated source for method getlua """
        if isinstance(key, (float, )):
            d = (float(key)).doubleValue()
            if d <= self.sizeArray and d >= 1:
                i = int(d)
                if i == d:
                    return self.array[i - 1]
        r = super(LuaTable, self).get(key)
        if r == None:
            r = Lua.NIL
        return r

    # 
    #    * Like {@link #getlua(Object)} but the result is written into
    #    * the <var>value</var> {@link Slot}.
    #    
    @getlua.register(object, Slot, Slot)
    def getlua_0(self, key, value):
        """ generated source for method getlua_0 """
        if key.r == Lua.NUMBER:
            d = key.d
            if d <= self.sizeArray and d >= 1:
                i = int(d)
                if i == d:
                    value.setObject(self.array[i - 1])
                    return
        r = super(LuaTable, self).get(key.asObject())
        if r == None:
            r = Lua.NIL
        value.setObject(r)

    #  Like get for numeric (integer) keys. 
    def getnum(self, k):
        """ generated source for method getnum """
        if k <= self.sizeArray and k >= 1:
            return self.array[k - 1]
        r = super(LuaTable, self).get(float(k))
        if r == None:
            return Lua.NIL
        return r

    # 
    #    * Like {@link java.util.Hashtable#put} but enables Lua's semantics
    #    * for <code>nil</code>;
    #    * In particular that <code>x = nil</nil>
    #    * deletes <code>x</code>.
    #    * And also that <code>t[nil]</code> raises an error.
    #    * Generally, users of Jill should be using
    #    * {@link Lua#setTable} instead of this.
    #    * @param key key.
    #    * @param value value.
    #    
    @overloaded
    def putlua(self, L, key, value):
        """ generated source for method putlua """
        d = 0.0
        i = Integer.MAX_VALUE
        if key == Lua.NIL:
            L.gRunerror("table index is nil")
        if isinstance(key, (float, )):
            d = (float(key)).doubleValue()
            j = int(d)
            if j == d and j >= 1:
                i = j
                #  will cause additional check for array part later if
                #  the array part check fails now.
                if i <= self.sizeArray:
                    self.array[i - 1] = value
                    return
            if Double.isNaN(d):
                L.gRunerror("table index is NaN")
        #  :todo: Consider checking key for NaN (PUC-Rio does)
        if value == Lua.NIL:
            remove(key)
            return
        super(LuaTable, self).put(key, value)
        #  This check is necessary because sometimes the call to super.put
        #  can rehash and the new (k,v) pair should be in the array part
        #  after the rehash, but is still in the hash part.
        if i <= self.sizeArray:
            remove(key)
            self.array[i - 1] = value

    @putlua.register(object, Lua, Slot, object)
    def putlua_0(self, L, key, value):
        """ generated source for method putlua_0 """
        i = Integer.MAX_VALUE
        if key.r == Lua.NUMBER:
            j = int(key.d)
            if j == key.d and j >= 1:
                i = j
                if i <= self.sizeArray:
                    self.array[i - 1] = value
                    return
            if Double.isNaN(key.d):
                L.gRunerror("table index is NaN")
        k = key.asObject()
        #  :todo: consider some sort of tail merge with the other putlua
        if value == Lua.NIL:
            remove(k)
            return
        super(LuaTable, self).put(k, value)
        if i <= self.sizeArray:
            remove(k)
            self.array[i - 1] = value

    # 
    #    * Like put for numeric (integer) keys.
    #    
    def putnum(self, k, v):
        """ generated source for method putnum """
        if k <= self.sizeArray and k >= 1:
            self.array[k - 1] = v
            return
        #  The key can never be NIL so putlua will never notice that its L
        #  argument is null.
        #  :todo: optimisation to avoid putlua checking for array part again
        self.putlua(None, float(k), v)

    # 
    #    * Do not use, implementation exists only to generate deprecated
    #    * warning.
    #    * @deprecated Use getlua instead.
    #    
    def get(self, key):
        """ generated source for method get """
        raise IllegalArgumentException()

    def keys(self):
        """ generated source for method keys """
        return Enum(self, super(LuaTable, self).keys())

    # 
    #    * Do not use, implementation exists only to generate deprecated
    #    * warning.
    #    * @deprecated Use putlua instead.
    #    
    def put(self, key, value):
        """ generated source for method put """
        raise IllegalArgumentException()

    # 
    #    * Used by oLog2.  DO NOT MODIFY.
    #    
    LOG2 = [None] * 

    # 
    #    * Equivalent to luaO_log2.
    #    
    @classmethod
    def oLog2(cls, x):
        """ generated source for method oLog2 """
        # # assert x >= 0
        l = -1
        while x >= 256:
            l += 8
            x = bsr(x, 8)
        return l + cls.LOG2[x]

    @classmethod
    def ceillog2(cls, x):
        """ generated source for method ceillog2 """
        return cls.oLog2(x - 1) + 1


class Enum(Enumeration):
    """ generated source for class Enum """
    t = None
    i = int()

    #  = 0
    e = None

    def __init__(self, t, e):
        """ generated source for method __init__ """
        super(Enum, self).__init__()
        self.t = t
        self.e = e
        inci()

    # 
    #    * Increments {@link #i} until it either exceeds
    #    * <code>t.sizeArray</code> or indexes a non-nil element.
    #    
    def inci(self):
        """ generated source for method inci """
        while self.i < self.t.sizeArray and self.t.array[self.i] == Lua.NIL:
            self.i += 1

    def hasMoreElements(self):
        """ generated source for method hasMoreElements """
        if self.i < self.t.sizeArray:
            return True
        return self.e.hasMoreElements()

    def nextElement(self):
        """ generated source for method nextElement """
        r = None
        if self.i < self.t.sizeArray:
            self.i += 1
            #  array index i corresponds to key i+1
            r = float(self.i)
            self.inci()
        else:
            r = self.e.nextElement()
        return r

