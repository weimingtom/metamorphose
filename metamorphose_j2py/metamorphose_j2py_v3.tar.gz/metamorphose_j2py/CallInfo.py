#!/usr/bin/env python
""" generated source for module CallInfo """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/CallInfo.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
class CallInfo(object):
    """ generated source for class CallInfo """
    savedpc = int()
    func = int()
    base = int()
    top = int()
    nresults = int()
    tailcalls = int()

    #  Only used to create the first instance. 
    @overloaded
    def __init__(self):
        """ generated source for method __init__ """

    # 
    #    * @param func  stack index of function
    #    * @param base  stack base for this frame
    #    * @param top   top-of-stack for this frame
    #    * @param nresults  number of results expected by caller
    #    
    @__init__.register(object, int, int, int, int)
    def __init___0(self, func, base, top, nresults):
        """ generated source for method __init___0 """
        self.func = func
        self.base = base
        self.top = top
        self.nresults = nresults

    #  Setter for savedpc. 
    def setSavedpc(self, pc):
        """ generated source for method setSavedpc """
        self.savedpc = pc

    #  Getter for savedpc. 
    def savedpc(self):
        """ generated source for method savedpc """
        return self.savedpc

    # 
    #    * Get the stack index for the function object for this record.
    #    
    def function_(self):
        """ generated source for method function_ """
        return self.func

    # 
    #    * Get stack index where results should end up.  This is an absolute
    #    * stack index, not relative to L.base.
    #    
    def res(self):
        """ generated source for method res """
        #  Same location as function.
        return self.func

    # 
    #    * Get stack base for this record.
    #    
    def base(self):
        """ generated source for method base """
        return self.base

    # 
    #    * Get top-of-stack for this record.  This is the number of elements
    #    * in the stack (or will be when the function is resumed).
    #    
    def top(self):
        """ generated source for method top """
        return self.top

    # 
    #    * Setter for top.
    #    
    def setTop(self, top):
        """ generated source for method setTop """
        self.top = top

    # 
    #    * Get number of results expected by the caller of this function.
    #    * Used to adjust the returned results to the correct number.
    #    
    def nresults(self):
        """ generated source for method nresults """
        return self.nresults

    # 
    #    * Get number of tailcalls
    #    
    def tailcalls(self):
        """ generated source for method tailcalls """
        return self.tailcalls

    # 
    #    * Used during tailcall to set the base and top members.
    #    
    def tailcall(self, baseArg, topArg):
        """ generated source for method tailcall """
        self.base = baseArg
        self.top = topArg
        self.tailcalls += 1

