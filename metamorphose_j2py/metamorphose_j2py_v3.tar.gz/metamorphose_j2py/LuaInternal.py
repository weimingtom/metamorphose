#!/usr/bin/env python
""" generated source for module LuaInternal """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/LuaInternal.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Class used to implement internal callbacks.  Currently there is only
#  * one callback used, one that parses or loads a Lua chunk into binary
#  * form.
#  
class LuaInternal(LuaJavaCallback):
    """ generated source for class LuaInternal """
    stream = None
    reader = None
    chunkname = None

    @overloaded
    def __init__(self, in_, chunkname):
        """ generated source for method __init__ """
        super(LuaInternal, self).__init__()
        self.stream = in_
        self.chunkname = chunkname

    @__init__.register(object, Reader, str)
    def __init___0(self, in_, chunkname):
        """ generated source for method __init___0 """
        super(LuaInternal, self).__init__()
        self.reader = in_
        self.chunkname = chunkname

    def luaFunction(self, L):
        """ generated source for method luaFunction """
        try:
            p = None
            #  In either the stream or the reader case there is a way of
            #  converting the input to the other type.
            if self.stream != None:
                self.stream.mark(1)
                c = self.stream.read()
                self.stream.reset()
                #  Convert to Reader if looks like source code instead of
                #  binary.
                if c == Loader.HEADER[0]:
                    l = Loader(self.stream, self.chunkname)
                    p = l.undump()
                else:
                    self.reader = InputStreamReader(self.stream, "UTF-8")
                    p = Syntax.parser(L, self.reader, self.chunkname)
            else:
                #  Convert to Stream if looks like binary (dumped via
                #  string.dump) instead of source code.
                if self.reader.markSupported():
                    self.reader.mark(1)
                    c = self.reader.read()
                    self.reader.reset()
                    if c == Loader.HEADER[0]:
                        self.stream = FromReader(self.reader)
                        l = Loader(self.stream, self.chunkname)
                        p = l.undump()
                    else:
                        p = Syntax.parser(L, self.reader, self.chunkname)
                else:
                    p = Syntax.parser(L, self.reader, self.chunkname)
            L.push(LuaFunction(p, [None] * 0, L.getGlobals()))
            return 1
        except IOError as e:
            L.push("cannot read " + self.chunkname + ": " + e.__str__())
            L.dThrow(Lua.ERRFILE)
            return 0

