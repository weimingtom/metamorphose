#!/usr/bin/env python
""" generated source for module OSLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/OSLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
#  REFERENCES
#  [C1990] "ISO Standard: Programming languages - C"; ISO 9899:1990;
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * The OS Library.  Can be opened into a {@link Lua} state by invoking
#  * the {@link #open} method.
#  
class OSLib(LuaJavaCallback):
    """ generated source for class OSLib """
    #  Each function in the library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    CLOCK = 1
    DATE = 2
    DIFFTIME = 3

    #  EXECUTE = 4;
    #  EXIT = 5;
    GETENV = 6

    # FIXME:added
    #  REMOVE = 7;
    #  RENAME = 8;
    SETLOCALE = 9
    TIME = 10

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    #  Constructs instance, filling in the 'which' member. 
    def __init__(self, which):
        """ generated source for method __init__ """
        super(OSLib, self).__init__()
        self.which = which

    # 
    #    * Implements all of the functions in the Lua os library (that are
    #    * provided).  Do not call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.CLOCK:
            return clock(L)
        elif self.which == self.DATE:
            return date(L)
        elif self.which == self.DIFFTIME:
            return difftime(L)
        elif self.which == self.GETENV:
            # FIXME:
            return getenv(L)
        elif self.which == self.SETLOCALE:
            return setlocale(L)
        elif self.which == self.TIME:
            return time(L)
        return 0

    # 
    #    * Opens the library into the given Lua state.  This registers
    #    * the symbols of the library in the table "os".
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        L.register("os")
        r(L, "clock", cls.CLOCK)
        r(L, "date", cls.DATE)
        r(L, "difftime", cls.DIFFTIME)
        r(L, "getenv", cls.GETENV)
        # FIXME:added
        r(L, "setlocale", cls.SETLOCALE)
        r(L, "time", cls.TIME)

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = OSLib(which)
        lib = L.getGlobal("os")
        L.setField(lib, name, f)

    T0 = System.currentTimeMillis()

    #  Implements clock.  Java provides no way to get CPU time, so we
    #    * return the amount of wall clock time since this class was loaded.
    #    
    @classmethod
    def clock(cls, L):
        """ generated source for method clock """
        d = float(System.currentTimeMillis())
        d = d - cls.T0
        d /= 1000
        L.pushNumber(d)
        return 1

    #  Implements date. 
    @classmethod
    def date(cls, L):
        """ generated source for method date """
        t = long()
        if L.isNoneOrNil(2):
            t = System.currentTimeMillis()
        else:
            t = long(L.checkNumber(2))
        s = L.optString(1, "%c")
        tz = TimeZone.getDefault()
        if s.startsWith("!"):
            tz = TimeZone.getTimeZone("GMT")
            s = s.substring(1)
        c = Calendar.getInstance(tz)
        c.setTime(Date(t))
        if s == "*t":
            L.push(L.createTable(0, 8))
            #  8 = number of fields
            setfield(L, "sec", c.get(Calendar.SECOND))
            setfield(L, "min", c.get(Calendar.MINUTE))
            setfield(L, "hour", c.get(Calendar.HOUR))
            setfield(L, "day", c.get(Calendar.DAY_OF_MONTH))
            setfield(L, "month", canonicalmonth(c.get(Calendar.MONTH)))
            setfield(L, "year", c.get(Calendar.YEAR))
            setfield(L, "wday", canonicalweekday(c.get(Calendar.DAY_OF_WEEK)))
            #  yday is not supported because CLDC 1.1 does not provide it.
            #  setfield(L, "yday", c.get("???"));
            if tz.useDaylightTime():
                #  CLDC 1.1 does not provide any way to determine isdst, so we set
                #  it to -1 (which in C means that the information is not
                #  available).
                setfield(L, "isdst", -1)
            else:
                #  On the other hand if the timezone does not do DST then it
                #  can't be in effect.
                setfield(L, "isdst", 0)
        else:
            b = StringBuffer()
            i = 0
            l = len(s)
            while i < l:
                ch = s.charAt(i)
                i += 1
                if ch != '%':
                    b.append(ch)
                    continue 
                if i >= l:
                    break
                ch = s.charAt(i)
                i += 1
                #  Generally in order to save space, the abbreviated forms are
                #  identical to the long forms.
                #  The specifiers are from [C1990].
                if ch == 'a':
                    pass
                elif ch == 'A':
                    b.append(weekdayname(c))
                elif ch == 'b':
                    pass
                elif ch == 'B':
                    b.append(monthname(c))
                elif ch == 'c':
                    b.append(c.getTime().__str__())
                    # FIXME:should be this
                    # b.append(String.format("%tc", c));
                elif ch == 'd':
                    b.append(format(c.get(Calendar.DAY_OF_MONTH), 2))
                elif ch == 'H':
                    b.append(format(c.get(Calendar.HOUR), 2))
                elif ch == 'I':
                    h = c.get(Calendar.HOUR)
                    h = (h + 11) % 12 + 1
                    #  force into range 1-12
                    b.append(format(h, 2))
                elif ch == 'j':
                    pass
                elif ch == 'U':
                    pass
                elif ch == 'W':
                    #  Not supported because CLDC 1.1 doesn't provide it.
                    b.append('%')
                    b.append(ch)
                elif ch == 'm':
                    m = canonicalmonth(c.get(Calendar.MONTH))
                    b.append(format(m, 2))
                elif ch == 'M':
                    b.append(format(c.get(Calendar.MINUTE), 2))
                elif ch == 'p':
                    h = c.get(Calendar.HOUR)
                    b.append("am" if h < 12 else "pm")
                elif ch == 'S':
                    b.append(format(c.get(Calendar.SECOND), 2))
                elif ch == 'w':
                    b.append(canonicalweekday(c.get(Calendar.DAY_OF_WEEK)))
                elif ch == 'x':
                    u = c.getTime().__str__()
                    #  We extract fields from the result of Date.toString.
                    #  The output of which is of the form:
                    #  dow mon dd hh:mm:ss zzz yyyy
                    #  except that zzz is optional.
                    b.append(u.substring(0, 11))
                    b.append(c.get(Calendar.YEAR))
                elif ch == 'X':
                    u = c.getTime().__str__()
                    b.append(u.substring(11, 5 - len(u)))
                elif ch == 'y':
                    b.append(format(c.get(Calendar.YEAR) % 100, 2))
                elif ch == 'Y':
                    b.append(c.get(Calendar.YEAR))
                elif ch == 'Z':
                    b.append(tz.getID())
                elif ch == '%':
                    b.append('%')
            #  while 
            L.pushString(b.__str__())
        return 1

    #  Implements difftime. 
    @classmethod
    def difftime(cls, L):
        """ generated source for method difftime """
        L.pushNumber((L.checkNumber(1) - L.optNumber(2, 0)) / 1000)
        return 1

    #  Incredibly, the spec doesn't give a numeric value and range for
    #  Calendar.JANUARY through to Calendar.DECEMBER.
    # 
    #    * Converts from 0-11 to required Calendar value.  DO NOT MODIFY THIS
    #    * ARRAY.
    #    
    MONTH = [Calendar.JANUARY, Calendar.FEBRUARY, Calendar.MARCH, Calendar.APRIL, Calendar.MAY, Calendar.JUNE, Calendar.JULY, Calendar.AUGUST, Calendar.SEPTEMBER, Calendar.OCTOBER, Calendar.NOVEMBER, Calendar.DECEMBER]

    #  Implements setlocale. 
    @classmethod
    def setlocale(cls, L):
        """ generated source for method setlocale """
        if L.isNoneOrNil(1):
            L.pushString("")
        else:
            L.pushNil()
        return 1

    #  Implements time. 
    @classmethod
    def time(cls, L):
        """ generated source for method time """
        if L.isNoneOrNil(1):
            #  called without args?
            L.pushNumber(System.currentTimeMillis())
            return 1
        L.checkType(1, Lua.TTABLE)
        L.setTop(1)
        #  make sure table is at the top
        c = Calendar.getInstance()
        c.set(Calendar.SECOND, getfield(L, "sec", 0))
        c.set(Calendar.MINUTE, getfield(L, "min", 0))
        c.set(Calendar.HOUR, getfield(L, "hour", 12))
        c.set(Calendar.DAY_OF_MONTH, getfield(L, "day", -1))
        c.set(Calendar.MONTH, cls.MONTH[getfield(L, "month", -1) - 1])
        c.set(Calendar.YEAR, getfield(L, "year", -1))
        #  ignore isdst field
        L.pushNumber(c.getTime().getTime())
        return 1

    @classmethod
    def getfield(cls, L, key, d):
        """ generated source for method getfield """
        o = L.getField(L.value(-1), key)
        if L.isNumber(o):
            return int(L.toNumber(o))
        if d < 0:
            return L.error("field '" + key + "' missing in date table")
        return d

    @classmethod
    def setfield(cls, L, key, value):
        """ generated source for method setfield """
        L.setField(L.value(-1), key, Lua.valueOfNumber(value))

    #  Format a positive integer in a 0-filled field of width
    #    * <var>w</var>.
    #    
    @classmethod
    def format(cls, i, w):
        """ generated source for method format """
        b = StringBuffer()
        b.append(i)
        while w < len(b):
            b.insert(0, '0')
        return b.__str__()

    @classmethod
    def weekdayname(cls, c):
        """ generated source for method weekdayname """
        s = c.getTime().__str__()
        return s.substring(0, 3)

    @classmethod
    def monthname(cls, c):
        """ generated source for method monthname """
        s = c.getTime().__str__()
        return s.substring(4, 7)

    # 
    #    * (almost) inverts the conversion provided by {@link #MONTH}.  Converts
    #    * from a {@link Calendar} value to a month in the range 1-12.
    #    * @param m  a value from the enum Calendar.JANUARY, Calendar.FEBRUARY, etc
    #    * @return a month in the range 1-12, or the original value.
    #    
    @classmethod
    def canonicalmonth(cls, m):
        """ generated source for method canonicalmonth """
        i = 0
        while len(MONTH):
            if m == cls.MONTH[i]:
                return i + 1
            i += 1
        return m

    #  DO NOT MODIFY ARRAY
    WEEKDAY = [Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY]

    # 
    #    * Converts from a {@link Calendar} value to a weekday in the range
    #    * 0-6 where 0 is Sunday (as per the convention used in [C1990]).
    #    * @param w  a value from the enum Calendar.SUNDAY, Calendar.MONDAY, etc
    #    * @return a weekday in the range 0-6, or the original value.
    #    
    @classmethod
    def canonicalweekday(cls, w):
        """ generated source for method canonicalweekday """
        i = 0
        while len(WEEKDAY):
            if w == cls.WEEKDAY[i]:
                return i
            i += 1
        return w

    # FIXME:added
    @classmethod
    def getenv(cls, L):
        """ generated source for method getenv """
        name = L.checkString(1)
        value = System.getenv(name)
        if value == None:
            L.pushNil()
        else:
            L.pushString(value)
        return 1

