#!/usr/bin/env python
""" generated source for module Expdesc """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/Expdesc.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
#  Equivalent to struct expdesc. 
class Expdesc(object):
    """ generated source for class Expdesc """
    VVOID = 0

    #  no value
    VNIL = 1
    VTRUE = 2
    VFALSE = 3
    VK = 4

    #  info = index into 'k'
    VKNUM = 5

    #  nval = numerical value
    VLOCAL = 6

    #  info = local register
    VUPVAL = 7

    #  info = index into 'upvalues'
    VGLOBAL = 8

    #  info = index of table;
    #  aux = index of global name in 'k'
    VINDEXED = 9

    #  info = table register
    #  aux = index register (or 'k')
    VJMP = 10

    #  info = instruction pc
    VRELOCABLE = 11

    #  info = instruction pc
    VNONRELOC = 12

    #  info = result register
    VCALL = 13

    #  info = instruction pc
    VVARARG = 14

    #  info = instruction pc
    k = int()

    #  one of V* enums above
    info = int()
    aux = int()
    nval = float()
    t = int()
    f = int()

    @overloaded
    def __init__(self):
        """ generated source for method __init__ """

    @__init__.register(object, int, int)
    def __init___0(self, k, i):
        """ generated source for method __init___0 """
        init(k, i)

    #  Equivalent to init_exp from lparser.c 
    @overloaded
    def init(self, kind, i):
        """ generated source for method init """
        self.t = FuncState.NO_JUMP
        self.f = FuncState.NO_JUMP
        self.k = kind
        self.info = i

    @init.register(object, Expdesc)
    def init_0(self, e):
        """ generated source for method init_0 """
        #  Must initialise all members of this.
        self.k = e.k
        self.info = e.info
        self.aux = e.aux
        self.nval = e.nval
        self.t = e.t
        self.f = e.f

    def kind(self):
        """ generated source for method kind """
        return self.k

    def setKind(self, kind):
        """ generated source for method setKind """
        self.k = kind

    def info(self):
        """ generated source for method info """
        return self.info

    def setInfo(self, i):
        """ generated source for method setInfo """
        self.info = i

    def aux(self):
        """ generated source for method aux """
        return self.aux

    def nval(self):
        """ generated source for method nval """
        return self.nval

    def setNval(self, d):
        """ generated source for method setNval """
        self.nval = d

    #  Equivalent to hasmultret from lparser.c 
    def hasmultret(self):
        """ generated source for method hasmultret """
        return self.k == self.VCALL or self.k == self.VVARARG

    #  Equivalent to hasjumps from lcode.c. 
    def hasjumps(self):
        """ generated source for method hasjumps """
        return self.t != self.f

    def nonreloc(self, i):
        """ generated source for method nonreloc """
        self.k = self.VNONRELOC
        self.info = i

    def reloc(self, i):
        """ generated source for method reloc """
        self.k = self.VRELOCABLE
        self.info = i

    def upval(self, i):
        """ generated source for method upval """
        self.k = self.VUPVAL
        self.info = i

