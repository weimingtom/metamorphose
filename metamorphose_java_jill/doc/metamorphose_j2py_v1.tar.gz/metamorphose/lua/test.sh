for file_a in ./*.java; do
temp_file=`basename $file_a .java`
echo $file_a,$temp_file
j2py $file_a ../$temp_file.py
done

