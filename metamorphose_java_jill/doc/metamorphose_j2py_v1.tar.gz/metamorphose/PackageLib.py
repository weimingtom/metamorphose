#!/usr/bin/env python
""" generated source for module PackageLib """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/PackageLib.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
# 
#  * Contains Lua's package library.
#  * The library
#  * can be opened using the {@link #open} method.
#  
class PackageLib(LuaJavaCallback):
    """ generated source for class PackageLib """
    #  Each function in the library corresponds to an instance of
    #  this class which is associated (the 'which' member) with an integer
    #  which is unique within this class.  They are taken from the following
    #  set.
    MODULE = 1
    REQUIRE = 2
    SEEALL = 3
    LOADER_PRELOAD = 4
    LOADER_LUA = 5

    # 
    #    * Which library function this object represents.  This value should
    #    * be one of the "enums" defined in the class.
    #    
    which = int()

    # 
    #    * Module Environment; a reference to the package table so that
    #    * package functions can access it without using the global table.
    #    * In PUC-Rio this reference is stored in the function's environment.
    #    * Not all instances (Lua Java functions) require this member, but
    #    * another subclass would be too wasteful.
    #    
    me = None

    #  Constructs instance, filling in the 'which' member. 
    @overloaded
    def __init__(self, which):
        """ generated source for method __init__ """
        super(PackageLib, self).__init__()
        self.which = which

    @__init__.register(object, int, LuaTable)
    def __init___0(self, which, me):
        """ generated source for method __init___0 """
        super(PackageLib, self).__init__()
        self.which = which
        self.me = me

    # 
    #    * Implements all of the functions in the Lua package library.  Do not
    #    * call directly.
    #    * @param L  the Lua state in which to execute.
    #    * @return number of returned parameters, as per convention.
    #    
    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.MODULE:
            return module_(L)
        elif self.which == self.REQUIRE:
            return require(L)
        elif self.which == self.SEEALL:
            return seeall(L)
        elif self.which == self.LOADER_LUA:
            return loaderLua(L)
        elif self.which == self.LOADER_PRELOAD:
            return loaderPreload(L)
        return 0

    # 
    #    * Opens the library into the given Lua state.  This registers
    #    * the symbols of the library in the global table.
    #    * @param L  The Lua state into which to open.
    #    
    @classmethod
    def open(cls, L):
        """ generated source for method open """
        t = L.register("package")
        g(L, t, "module", cls.MODULE)
        g(L, t, "require", cls.REQUIRE)
        r(L, "seeall", cls.SEEALL)
        L.setField(t, "loaders", L.newTable())
        p(L, t, cls.LOADER_PRELOAD)
        p(L, t, cls.LOADER_LUA)
        setpath(L, t, "path", PATH_DEFAULT)
        #  set field 'path'
        #  set field 'loaded'
        L.findTable(L.getRegistry(), Lua.LOADED, 1)
        L.setField(t, "loaded", L.value(-1))
        L.pop(1)
        L.setField(t, "preload", L.newTable())

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = PackageLib(which)
        L.setField(L.getGlobal("package"), name, f)

    #  Register a function in the global table. 
    @classmethod
    def g(cls, L, t, name, which):
        """ generated source for method g """
        f = PackageLib(which, t)
        L.setGlobal(name, f)

    #  Register a loader in package.loaders. 
    @classmethod
    def p(cls, L, t, which):
        """ generated source for method p """
        f = PackageLib(which, t)
        loaders = L.getField(t, "loaders")
        L.rawSetI(loaders, L.objLen(loaders) + 1, f)

    DIRSEP = "/"
    PATHSEP = ';'
    PATH_MARK = "?"
    PATH_DEFAULT = "?.lua;?/init.lua"
    SENTINEL = object()

    # 
    #    * Implements the preload loader.  This is conventionally stored
    #    * first in the package.loaders table.
    #    
    def loaderPreload(self, L):
        """ generated source for method loaderPreload """
        name = L.checkString(1)
        preload = L.getField(self.me, "preload")
        if not L.isTable(preload):
            L.error("'package.preload' must be a table")
        loader = L.getField(preload, name)
        if L.isNil(loader):
            L.pushString("\n\tno field package.preload['" + name + "']")
        L.push(loader)
        return 1

    # 
    #    * Implements the lua loader.  This is conventionally stored second in
    #    * the package.loaders table.
    #    
    def loaderLua(self, L):
        """ generated source for method loaderLua """
        name = L.checkString(1)
        filename = findfile(L, name, "path")
        if filename == None:
            return 1
        #  library not found in this path
        if L.loadFile(filename) != 0:
            loaderror(L, filename)
        return 1
        #  library loaded successfully

    #  Implements module. 
    def module_(self, L):
        """ generated source for method module_ """
        modname = L.checkString(1)
        loaded = L.getField(self.me, "loaded")
        module_ = L.getField(loaded, modname)
        if not L.isTable(module_):
            #  not found?
            #  try global variable (and create one if it does not exist)
            if L.findTable(L.getGlobals(), modname, 1) != None:
                return L.error("name conflict for module '" + modname + "'")
            module_ = L.value(-1)
            L.pop(1)
            #  package.loaded = new table
            L.setField(loaded, modname, module_)
        #  check whether table already has a _NAME field
        if L.isNil(L.getField(module_, "_NAME")):
            modinit(L, module_, modname)
        setfenv(L, module_)
        dooptions(L, module_, L.getTop())
        return 0

    #  Implements require. 
    def require(self, L):
        """ generated source for method require """
        name = L.checkString(1)
        L.setTop(1)
        #  PUC-Rio's use of lua_getfield(L, LUA_REGISTRYINDEX, "_LOADED");
        #  (package.loaded is kept in the registry in PUC-Rio) is translated
        #  into this:
        loaded = L.getField(self.me, "loaded")
        module_ = L.getField(loaded, name)
        if L.toBoolean(module_):
            #  is it there?
            if module_ == self.SENTINEL:
                L.error("loop or previous error loading module '" + name + "'")
            L.push(module_)
            return 1
        #  else must load it; iterate over available loaders.
        loaders = L.getField(self.me, "loaders")
        if not L.isTable(loaders):
            L.error("'package.loaders' must be a table")
        L.pushString("")
        #  error message accumulator
        i = 1
        while True:
            loader = L.rawGetI(loaders, i)
            #  get a loader
            if L.isNil(loader):
                L.error("module '" + name + "' not found:" + L.toString(L.value(-1)))
            L.push(loader)
            L.pushString(name)
            L.call(1, 1)
            #  call it
            if L.isFunction(L.value(-1)):
                #  did it find module?
                break
            elif L.isString(L.value(-1)):
                L.concat(2)
            else:
                L.pop(1)
            i += 1
        L.setField(loaded, name, self.SENTINEL)
        #  package.loaded[name] = sentinel
        L.pushString(name)
        #  pass name as argument to module
        L.call(1, 1)
        #  run loaded module
        if not L.isNil(L.value(-1)):
            #  non-nil return?
            #  package.loaded[name] = returned value
            L.setField(loaded, name, L.value(-1))
        module_ = L.getField(loaded, name)
        if module_ == self.SENTINEL:
            #  module did not set a value?
            module_ = Lua.valueOfBoolean(True)
            #  use true as result
            L.setField(loaded, name, module_)
            #  package.loaded[name] = true
        L.push(module_)
        return 1

    #  Implements package.seeall. 
    @classmethod
    def seeall(cls, L):
        """ generated source for method seeall """
        L.checkType(1, Lua.TTABLE)
        mt = L.getMetatable(L.value(1))
        if mt == None:
            mt = L.createTable(0, 1)
            L.setMetatable(L.value(1), mt)
        L.setField(mt, "__index", L.getGlobals())
        return 0

    # 
    #    * Helper for module.  <var>module</var> parameter replaces PUC-Rio
    #    * use of passing it on the stack.
    #    
    @classmethod
    def setfenv(cls, L, module_):
        """ generated source for method setfenv """
        ar = L.getStack(1)
        L.getInfo("f", ar)
        L.setFenv(L.value(-1), module_)
        L.pop(1)

    # 
    #    * Helper for module.  <var>module</var> parameter replaces PUC-Rio
    #    * use of passing it on the stack.
    #    
    @classmethod
    def dooptions(cls, L, module_, n):
        """ generated source for method dooptions """
        i = 2
        while i <= n:
            L.pushValue(i)
            #  get option (a function)
            L.push(module_)
            L.call(1, 0)
            i += 1

    # 
    #    * Helper for module.  <var>module</var> parameter replaces PUC-Rio
    #    * use of passing it on the stack.
    #    
    @classmethod
    def modinit(cls, L, module_, modname):
        """ generated source for method modinit """
        L.setField(module_, "_M", module_)
        #  module._M = module
        L.setField(module_, "_NAME", modname)
        dot = modname.lastIndexOf('.')
        #  look for last dot in module name
        #  Surprisingly, ++dot works when '.' was found and when it wasn't.
        dot += 1
        #  set _PACKAGE as package name (full module name minus last part)
        L.setField(module_, "_PACKAGE", modname.substring(0, dot))

    @classmethod
    def loaderror(cls, L, filename):
        """ generated source for method loaderror """
        L.error("error loading module '" + L.toString(L.value(1)) + "' from file '" + filename + "':\n\t" + L.toString(L.value(-1)))

    @classmethod
    def readable(cls, filename):
        """ generated source for method readable """
        f = PackageLib.__class__.getResourceAsStream(filename)
        if f == None:
            return False
        try:
            f.close()
        except IOError as e_:
            pass
        return True

    @classmethod
    def pushnexttemplate(cls, L, path):
        """ generated source for method pushnexttemplate """
        i = 0
        #  skip seperators
        while i < len(path) and path.charAt(i) == cls.PATHSEP:
        if i == len(path):
            return None
        #  no more templates
        l = path.indexOf(cls.PATHSEP, i)
        if l < 0:
            l = len(path)
        L.pushString(path.substring(i, l))
        #  template
        return path.substring(l)

    def findfile(self, L, name, pname):
        """ generated source for method findfile """
        name = gsub(name, ".", self.DIRSEP)
        path = L.toString(L.getField(self.me, pname))
        if path == None:
            L.error("'package." + pname + "' must be a string")
        L.pushString("")
        #  error accumulator
        while True:
            path = self.pushnexttemplate(L, path)
            if path == None:
                break
            filename = gsub(L.toString(L.value(-1)), self.PATH_MARK, name)
            if self.readable(filename):
                #  does file exist and is readable?
                return filename
            #  return that file name
            L.pop(1)
            #  remove path template
            L.pushString("\n\tno file '" + filename + "'")
            L.concat(2)
        return None
        #  not found

    #  Almost equivalent to luaL_gsub. 
    @classmethod
    def gsub(cls, s, p, r):
        """ generated source for method gsub """
        b = StringBuffer()
        #  instead of incrementing the char *s, we use the index i
        i = 0
        l = len(p)
        while True:
            wild = s.indexOf(p, i)
            if wild < 0:
                break
            b.append(s.substring(i, wild))
            #  add prefix
            b.append(r)
            #  add replacement in place of pattern
            i = wild + l
            #  continue after 'p'
        b.append(s.substring(i))
        return b.__str__()

    @classmethod
    def setpath(cls, L, t, fieldname, def_):
        """ generated source for method setpath """
        #  :todo: consider implementing a user-specified path via
        #  javax.microedition.midlet.MIDlet.getAppProperty or similar.
        #  Currently we just use a default path defined by Jill.
        L.setField(t, fieldname, def_)

