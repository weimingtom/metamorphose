#!/usr/bin/env python
""" generated source for module IOLib """
from __future__ import print_function
# 
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
class IOLib(LuaJavaCallback):
    """ generated source for class IOLib """
    WRITE = 1
    which = int()

    def __init__(self, which):
        """ generated source for method __init__ """
        super(IOLib, self).__init__()
        self.which = which

    def luaFunction(self, L):
        """ generated source for method luaFunction """
        if self.which == self.WRITE:
            return write(L)
        return 0

    @classmethod
    def open(cls, L):
        """ generated source for method open """
        # LuaTable t = 
        L.register("io")
        r(L, "write", cls.WRITE)

    #  Register a function. 
    @classmethod
    def r(cls, L, name, which):
        """ generated source for method r """
        f = IOLib(which)
        L.setField(L.getGlobal("io"), name, f)

    @classmethod
    def write(cls, L):
        """ generated source for method write """
        return g_write(L, System.out, 1)

    NUMBER_FMT = ".14g"

    # FIXME:
    @classmethod
    def g_write(cls, L, stream, arg):
        """ generated source for method g_write """
        # FIXME:
        nargs = L.getTop()
        # FIXME:notice here, original code is 'lua_gettop(L) - 1' (something pushed before?)
        status = 1
        while nargs != 0:
            nargs -= 1
            if L.type_(arg) == Lua.TNUMBER:
                if status != 0:
                    try:
                        # stream.print(String.format("%s", L.toNumber(L.value(arg))));
                        # @see http://stackoverflow.com/questions/703396/how-to-nicely-format-floating-numbers-to-string-without-unnecessary-decimal-0
                        # stream.print(new DecimalFormat("#.##########").format(L.value(arg)));
                        # @see Lua#vmToString
                        f = FormatItem(None, cls.NUMBER_FMT)
                        b = StringBuffer()
                        d = float(L.toNumber(L.value(arg)))
                        f.formatFloat(b, d.doubleValue())
                        stream.print_(b.__str__())
                    except Throwable as e:
                        status = 0
            else:
                s = L.checkString(arg)
                if status != 0:
                    try:
                        stream.print_(s)
                    except Throwable as e:
                        status = 0
            arg += 1
        return pushresult(L, status, None)

    errno = 0

    # FIXME: not implemented
    @classmethod
    def pushresult(cls, L, i, filename):
        """ generated source for method pushresult """
        en = cls.errno
        #  calls to Lua API may change this value 
        if i != 0:
            L.pushBoolean(True)
            return 1
        else:
            L.pushNil()
            if filename != None:
                # FIXME: not implemented
                # L.pushString(String.format("%s: %s", filename, "io error"/*strerror(en)*/));
                L.pushString("" + filename + ": " + "io error")# strerror(en)
            else:
                # FIXME: not implemented
                # L.pushString(String.format("%s", "io error"/*strerror(en)*/));
                L.pushString("" + "io error")# strerror(en)
            L.pushNumber(en)
            return 3

