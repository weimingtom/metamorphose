#!/usr/bin/env python
""" generated source for module StringReader """
from __future__ import print_function
#   $Header: //info.ravenbrook.com/project/jili/version/1.1/code/mnj/lua/StringReader.java#1 $
#  * Copyright (c) 2006 Nokia Corporation and/or its subsidiary(-ies).
#  * All rights reserved.
#  * 
#  * Permission is hereby granted, free of charge, to any person obtaining
#  * a copy of this software and associated documentation files (the
#  * "Software"), to deal in the Software without restriction, including
#  * without limitation the rights to use, copy, modify, merge, publish,
#  * distribute, sublicense, and/or sell copies of the Software, and to
#  * permit persons to whom the Software is furnished to do so, subject
#  * to the following conditions:
#  * 
#  * The above copyright notice and this permission notice shall be
#  * included in all copies or substantial portions of the Software.
#  * 
#  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#  * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
#  * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
#  * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
#  * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
#  * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
#  * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#  
# package: com.iteye.weimingtom.metamorphose.lua
#  Ersatz replacement for {@link java.io.StringReader} from JSE. 
class StringReader(java, io, Reader):
    """ generated source for class StringReader """
    s = None

    #  Index of the current read position.  -1 if closed. 
    current = int()

    #  = 0
    # 
    #    * Index of the current mark (set with {@link #mark}).
    #    
    mark = int()

    #  = 0;
    def __init__(self, s):
        """ generated source for method __init__ """
        super(StringReader, self).__init__()
        self.s = s

    def close(self):
        """ generated source for method close """
        self.current = -1

    def mark(self, limit):
        """ generated source for method mark """
        self.mark = self.current

    def markSupported(self):
        """ generated source for method markSupported """
        return True

    @overloaded
    def read(self):
        """ generated source for method read """
        if self.current < 0:
            raise IOError()
        if self.current >= len(s):
            return -1
        __current_0 = current
        current += 1
        __current_1 = current
        current += 1
        return self.s.charAt(__current_1)

    @read.register(object, str, int, int)
    def read_0(self, cbuf, off, len):
        """ generated source for method read_0 """
        if self.current < 0 or len < 0:
            raise IOError()
        if self.current >= len(s):
            return 0
        if self.current + len > len(s):
            len = self.current - len(s)
        i = 0
        while i < len:
            cbuf[off + i] = self.s.charAt(self.current + i)
            i += 1
        self.current += len
        return len

    def reset(self):
        """ generated source for method reset """
        self.current = self.mark

