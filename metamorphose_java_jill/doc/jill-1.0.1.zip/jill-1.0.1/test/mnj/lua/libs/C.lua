package.loaded[...] = 25; require'C'NAME = 'C.lua'
REQUIRED = ...
return AA