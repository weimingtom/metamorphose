NAME = 'A.lua'
REQUIRED = ...
return AA