assert(...=='B');require 'A'NAME = 'B.lua'
REQUIRED = ...
return AA