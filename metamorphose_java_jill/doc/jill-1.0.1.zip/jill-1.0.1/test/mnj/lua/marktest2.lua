local function blah (a)
  local function blong (b) 
    local function krungle (c)
      return a+b+c end ;
    return krungle ;
  end ;
end;

